#!/usr/bin/env python3
"""
Pyrogram-based refactor of the Telegram -> MyJDownloader bot with integrated GoFile downloader.
FIXED VERSION: Fixed freezing issues, blocking operations, and signal handling.
IMPROVED VERSION: Fixed thumbnail upload issues and optimized upload speeds.
COMPLETE FIX: Added proper async file operations, timeout handling, and signal management.
PROGRESS FIX: Made progress callbacks synchronous and schedule async updates via run_coroutine_threadsafe.
THUMBNAIL FIX: Never pass thumb=None to send_document.
CANCEL BUTTON FIX: Preserve reply_markup in progress updates for uploads AND JDownloader monitoring.
JD CANCEL FIX: Use direct local JDownloader API (deprecated API) to stop, remove, and DELETE FILES.
SUFFIX FILTER: Added suffix stripping feature for downloaded files AND FOLDERS (with retries, logging, manual command, and trailing space removal).
SUFFIX AUTO-RENAME FIX: Increased retry delays and added configurable wait times to avoid file locking issues.
TORRENT REMOVAL: After successful download, torrent is removed from qBittorrent while keeping the downloaded files.
FILE SIGNING: Added optional file/folder signing after suffix stripping (adds custom sign with space, top-level only).
FIX: File signing now ONLY applied to top-level downloaded folder or file, not to children.
FIX: Signing process now always receives a path - works whether suffix filter is enabled/disabled or modifies the path.
AUTOMATOR: Added toggleable automator mode that compresses downloaded files/folders into 2GB split 7z parts
          and uploads each part as it becomes ready, then deletes the original downloaded item.
FIX: Automator cancel button now removed from uploaded part messages after upload finishes.
AUTOMATOR QUEUE: Added concurrency control and queue for automator tasks to prevent resource exhaustion.
                 Commands: /set_automator_concurrency <num>, /automator_concurrency
FIX: Automator part detection - replaced glob with safe iterdir + regex to handle special characters in filenames.
FIX: Automator upload cancel button - use short safe IDs to avoid BUTTON_DATA_INVALID error.
AUTOMATOR FULL SEQUENTIAL: Added global processing queue and workers to ensure that when automator is enabled,
                           each link is fully processed (download, suffix, sign, compress, upload) before the next link is even added.
                           With concurrency = 1, tasks run completely sequentially.
FIX: Automator worker now catches asyncio.CancelledError and continues, preventing worker death and queue freeze.
FIX: Automator mode now shows cancel buttons on download progress messages (JDownloader, GoFile, and qBittorrent).
FIX: Automator upload cancel button now cancels the entire job (compression + all remaining uploads).
FIX: Automator uploads now happen sequentially (one part at a time) using a queue + worker.
FIX: Automator parts are uploaded in strict numerical order (001, 002, ...) even if files appear out-of-order.
FIX: Automator queue freeze when cancelling a job during upload – part_queue.join() no longer blocks permanently.
FIX: Cancel job now immediately updates progress message and releases queue worker for next job.
FLOOD PROTECTION: Added global rate limiter that spaces send operations (new messages, documents) by dynamic interval:
                  - 0.5 seconds when automator disabled
                  - configurable seconds when automator enabled (default 10s, set via AUTOMATOR_SEND_INTERVAL)
                  Edits are NOT throttled but have FloodWait retry handling with dynamic backoff.
FIX: Single-file torrents now correctly apply suffix filter and signing, and trigger automator.
FIX: Signing only applies to top-level downloaded folder or single file – no signing of children.
FLOODWAIT HANDLING: All send and edit operations now automatically retry on FloodWait with the required sleep.
FLOODWAIT BACKOFF: After a FloodWait, a temporary cooldown is applied to prevent repeated hits.
ASYNC SUFFIX/SIGNING FIX: Converted suffix filter and signing functions to async with asyncio.sleep,
                         eliminating blocking calls that froze the event loop.
WATCHDOG: Added task watchdog to detect and clean up frozen operations (>5 minutes).
ASYNCIO DEBUG: Optional debug mode (ASYNCIO_DEBUG=true) logs blocking calls and slow callbacks.
NETWORK FIX: Added upload_with_retry() to handle WinError 64 and network disconnections,
             with timeout and automatic client reconnection.
MAGNET FIX: Replaced Path(link).is_file() with os.path.isfile() to avoid "File name too long" error on Linux.
"""

import os
import re
import logging
from dotenv import load_dotenv
import asyncio
import shutil
import time
from pathlib import Path
from typing import List, Tuple, Optional, Any, Iterator, NoReturn, TextIO, Callable, Dict
import aiohttp
import urllib.parse
import math
import uuid
import json
from datetime import datetime, timedelta
import zipfile
import subprocess
import html
from html.parser import HTMLParser
import socket

from myjdapi.myjdapi import Myjdapi

from pyrogram import Client, filters, idle
from pyrogram.types import Message
from pyrogram.handlers import MessageHandler
from pyrogram.errors import FloodWait

from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from pyrogram.handlers import CallbackQueryHandler
from pyrogram.enums import ParseMode

from os import getcwd, getenv, listdir, makedirs, name, path, rmdir
from sys import argv, exit, stdout, stderr
import sys
from types import FrameType
from itertools import count
from concurrent.futures import ThreadPoolExecutor
from threading import Event as ThreadEvent
from hashlib import sha256
from shutil import move
from signal import signal, SIGINT, SIG_IGN
from time import perf_counter, time as _time
import signal as signal_module

# Try to import PIL for thumbnail validation
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    logging.warning("PIL (Pillow) not available. Thumbnail validation will be limited.")

# Try to import psutil for speed monitoring
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

NEW_LINE: str = "\n" if name != "nt" else "\r\n"

load_dotenv()

# Constants for timeout handling
COMMAND_TIMEOUT = 30  # 30 seconds timeout for commands
CONNECTION_RETRY_DELAY = 2  # seconds to wait before retrying after connection loss
FILE_OPERATION_TIMEOUT = 15  # timeout for file operations
UPLOAD_TIMEOUT = 3600  # 1 hour per upload part
UPLOAD_RETRY_DELAY = 5

# Upload optimization constants
DEFAULT_CHUNK_SIZE = 1024 * 1024 * 32  # 32MB chunks for faster uploads
MAX_CONCURRENT_UPLOADS = int(os.getenv("PYRO_MAX_CONCURRENT_TRANSMISSIONS", "32"))
WORKER_COUNT = int(os.getenv("PYRO_WORKERS", "32"))
FORCE_BOT_UPLOADS = os.getenv("FORCE_BOT_UPLOADS", "False").lower() == "true"
FORCE_USER_UPLOADS = os.getenv("FORCE_USER_UPLOADS", "False").lower() == "true"   # NEW
LARGE_FILE_THRESHOLD = 50 * 1024 * 1024  # 50MB threshold for using bot API

# Suffix filter retry configuration (can be overridden in .env)
SUFFIX_RETRY_DELAY = float(os.getenv("SUFFIX_RETRY_DELAY", "2.0"))   # seconds between retries
SUFFIX_RETRY_COUNT = int(os.getenv("SUFFIX_RETRY_COUNT", "8"))       # number of retry attempts
SUFFIX_POST_DOWNLOAD_WAIT = float(os.getenv("SUFFIX_POST_DOWNLOAD_WAIT", "3.0"))  # initial wait after download finishes

# File signing globals
FILE_SIGNING_ENABLED: bool = False
FILE_SIGN: str = ""          # e.g. "[Team]" or "signed"

# Automator globals
AUTOMATOR_ENABLED: bool = False
# Automator concurrency control
AUTOMATOR_CONCURRENCY: int = 1          # default concurrency limit
AUTOMATOR_SEMAPHORE: Optional[asyncio.Semaphore] = None
AUTOMATOR_ACTIVE_COUNT: int = 0
_AUTOMATOR_COUNT_LOCK: Optional[asyncio.Lock] = None
AUTOMATOR_UPLOADS: dict = {}  # short_id -> {"part_path": Path, "upload_task": asyncio.Task, "progress_msg": Message, "job_id": str}
AUTOMATOR_JOBS: dict = {}     # job_id -> {"cancel_event": asyncio.Event, "proc": subprocess, "pending_tasks": list, "progress_msg": Message, "original_path": Path, "chat_id": int}

# New global variables for automator processing queue
PROCESSING_QUEUE: Optional[asyncio.Queue] = None
PROCESSING_SEMAPHORE: Optional[asyncio.Semaphore] = None
PROCESSING_WORKERS: List[asyncio.Task] = []

# ---- Flood protection: global rate limiter (only for sends, not edits) ----
_SEND_LOCK = asyncio.Lock()
_LAST_SEND_TIME = 0.0
_SEND_MIN_INTERVAL_NORMAL = 0.5      # seconds when automator disabled
_SEND_MIN_INTERVAL_AUTOMATOR = float(os.getenv("AUTOMATOR_SEND_INTERVAL", "10.0"))   # increased to 10s default

# ---- Dynamic backoff after flood wait ----
_LAST_FLOODWAIT_END = 0.0
_TEMPORARY_INTERVAL = None
_TEMPORARY_END_TIME = 0.0

async def _throttle_send():
    """Ensure at least the current interval since the last send operation."""
    global _LAST_SEND_TIME, AUTOMATOR_ENABLED, _TEMPORARY_INTERVAL, _TEMPORARY_END_TIME
    async with _SEND_LOCK:
        # Determine interval: temporary (post-flood) overrides permanent
        now = time.time()
        if _TEMPORARY_INTERVAL and now < _TEMPORARY_END_TIME:
            interval = _TEMPORARY_INTERVAL
        else:
            interval = _SEND_MIN_INTERVAL_AUTOMATOR if AUTOMATOR_ENABLED else _SEND_MIN_INTERVAL_NORMAL
        elapsed = now - _LAST_SEND_TIME
        if elapsed < interval:
            await asyncio.sleep(interval - elapsed)
        _LAST_SEND_TIME = time.time()

async def _send_with_retry(coro, retries=5):
    """Execute a send coroutine, retrying on FloodWait with the required sleep and dynamic backoff."""
    global _LAST_FLOODWAIT_END, _TEMPORARY_INTERVAL, _TEMPORARY_END_TIME, _SEND_MIN_INTERVAL_AUTOMATOR
    for attempt in range(retries):
        try:
            return await coro
        except FloodWait as e:
            wait = e.value  # seconds Telegram requires
            if wait > 0:
                logging.warning(f"FloodWait: need to wait {wait}s before retrying send (attempt {attempt+1}/{retries})")
                # Set dynamic backoff
                _LAST_FLOODWAIT_END = time.time() + wait
                _TEMPORARY_INTERVAL = max(wait / 5, 10.0)   # temporary interval = 1/5 of wait, min 10s
                _TEMPORARY_END_TIME = time.time() + wait
                # Also raise base automator interval if automator enabled
                if AUTOMATOR_ENABLED:
                    _SEND_MIN_INTERVAL_AUTOMATOR = max(_SEND_MIN_INTERVAL_AUTOMATOR, wait / 10)
                await asyncio.sleep(wait)
            else:
                # Some old versions may not have .value; fallback to parsing
                match = re.search(r'(\d+)', str(e))
                if match:
                    wait = int(match.group(1))
                    logging.warning(f"FloodWait: need to wait {wait}s (parsed) before retrying send")
                    _LAST_FLOODWAIT_END = time.time() + wait
                    _TEMPORARY_INTERVAL = max(wait / 5, 10.0)
                    _TEMPORARY_END_TIME = time.time() + wait
                    if AUTOMATOR_ENABLED:
                        _SEND_MIN_INTERVAL_AUTOMATOR = max(_SEND_MIN_INTERVAL_AUTOMATOR, wait / 10)
                    await asyncio.sleep(wait)
                else:
                    # Unknown wait, default to exponential backoff
                    await asyncio.sleep(2 ** attempt)
        except Exception:
            # Non-flood error – re-raise immediately
            raise
    raise Exception("Max retries exceeded due to repeated FloodWait")

async def throttled_send(coro):
    """
    Execute a send coroutine after applying the rate limit.
    Also handles FloodWait by retrying with the required sleep and dynamic backoff.
    """
    await _throttle_send()
    return await _send_with_retry(coro)

async def edit_with_retry(edit_coro, retries=5):
    """
    Execute an edit coroutine (e.g., message.edit_text) with FloodWait retries.
    Edits are NOT throttled by the global send interval, but still need FloodWait handling.
    """
    for attempt in range(retries):
        try:
            return await edit_coro
        except FloodWait as e:
            wait = e.value
            if wait > 0:
                logging.warning(f"FloodWait (edit): need to wait {wait}s before retrying edit (attempt {attempt+1}/{retries})")
                await asyncio.sleep(wait)
            else:
                match = re.search(r'(\d+)', str(e))
                if match:
                    wait = int(match.group(1))
                    logging.warning(f"FloodWait (edit): need to wait {wait}s (parsed)")
                    await asyncio.sleep(wait)
                else:
                    await asyncio.sleep(2 ** attempt)
        except Exception:
            raise
    raise Exception("Max retries exceeded for edit")

def has_ansi_support() -> bool:
    import os as _os
    import sys as _sys
    if not _sys.stdout.isatty():
        return False
    if _os.name == "nt":
        return _sys.getwindowsversion().major >= 10
    return True

TERMINAL_CLEAR_LINE: str = f"\r{' ' * 100} \r" if not has_ansi_support() else "\033[2K\r"

def _print(msg: str, error: bool = False) -> None:
    output: TextIO = stderr if error else stdout
    output.write(msg)
    output.flush()

def die(msg: str) -> NoReturn:
    _print(f"{msg}{NEW_LINE}", True)
    exit(-1)

def generate_website_token(user_agent: str, account_token: str) -> str:
    time_slot = int(_time()) // 14400
    raw = f"{user_agent}::en-US::{account_token}::{time_slot}::gf2026x"
    return sha256(raw.encode()).hexdigest()

def validate_and_fix_thumbnail(thumb_path: Path) -> Optional[Path]:
    """Validate and fix thumbnail for Telegram compatibility"""
    if not thumb_path.exists():
        return None
    
    try:
        if PIL_AVAILABLE:
            with Image.open(thumb_path) as img:
                # Convert to RGB if necessary (RGBA, P, etc.)
                if img.mode not in ('RGB', 'L'):
                    rgb_img = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'RGBA':
                        rgb_img.paste(img, mask=img.split()[3] if len(img.split()) > 3 else None)
                    else:
                        rgb_img.paste(img)
                    img = rgb_img
                
                # Resize if too large (max 320x320)
                max_size = 320
                if img.width > max_size or img.height > max_size:
                    img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
                
                # Save as JPEG with compression
                fixed_path = thumb_path.with_suffix('.jpg')
                img.save(fixed_path, 'JPEG', quality=85, optimize=True)
                
                # Check file size (Telegram limit ~200KB)
                if fixed_path.stat().st_size > 200 * 1024:
                    # Compress more
                    img.save(fixed_path, 'JPEG', quality=60, optimize=True)
                
                return fixed_path
        else:
            # Without PIL, just ensure it's a .jpg
            if thumb_path.suffix.lower() not in ('.jpg', '.jpeg'):
                logging.warning("Thumbnail is not a JPEG. PIL not available to convert.")
            return thumb_path
    except Exception as e:
        logging.error(f"Failed to validate thumbnail: {e}")
        return None

# OptimizedProgress with synchronous __call__ and thread-safe async scheduling
class OptimizedProgress:
    def __init__(self, name: str, total_size: Optional[int], progress_msg: Message,
                 start_time: float, update_interval: float = 5.0,
                 reply_markup: Optional[InlineKeyboardMarkup] = None):
        self.name = name
        self.total_size = total_size
        self.progress_msg = progress_msg
        self.start_time = start_time
        self.update_interval = update_interval
        self.reply_markup = reply_markup
        self.last_update = 0.0
        self.last_progress = 0
        self.speed_samples = []
        try:
            self.loop = asyncio.get_running_loop()
        except RuntimeError:
            self.loop = None

    def __call__(self, current: int, total: int):
        """Synchronous entry point – schedules the async update in the main loop."""
        if self.loop is None or self.loop.is_closed():
            return
        asyncio.run_coroutine_threadsafe(self._do_update(current, total), self.loop)

    async def _do_update(self, current: int, total: int):
        try:
            now = time.time()
            if now - self.last_update < self.update_interval:
                return
            self.last_update = now
            elapsed = now - self.start_time

            if elapsed > 0:
                current_speed = current / elapsed
                self.speed_samples.append(current_speed)
                if len(self.speed_samples) > 5:
                    self.speed_samples.pop(0)
                avg_speed = sum(self.speed_samples) / len(self.speed_samples)
            else:
                avg_speed = 0

            remaining = total - current
            eta = remaining / avg_speed if avg_speed > 0 else None

            text = build_progress_text(self.name, total, current, elapsed, eta, speed=int(avg_speed))
            if avg_speed > 0:
                speed_mbps = (avg_speed * 8) / (1024 * 1024)
                text += f"\n<i>Speed: {speed_mbps:.2f} Mbps</i>"

            # Preserve the cancel button, use edit_with_retry to handle FloodWait
            await edit_with_retry(self.progress_msg.edit(
                _scrub_text_for_user(text),
                reply_markup=self.reply_markup
            ))
        except Exception:
            pass

# AsyncDownloader (unchanged except removal of per-file signing)
class AsyncDownloader:
    def __init__(
        self,
        root_dir: str,
        interactive: bool,
        max_workers: int,
        number_retries,
        timeout: float,
        chunk_size: int,
        stop_event: asyncio.Event,   # changed to asyncio.Event
        url: str,
        password: str | None = None,
        progress_callback: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._files_info: dict[str, dict[str, str]] = {}
        self._max_workers: int = max_workers
        self._number_retries: int = number_retries
        self._timeout: float = timeout
        self._interactive: bool = interactive
        self._chunk_size: int = chunk_size
        self._password: str | None = password
        self._stop_event: asyncio.Event = stop_event
        self._root_dir: str = root_dir
        self._url: str = url
        self._progress_callback = progress_callback
        self._session: Optional[aiohttp.ClientSession] = None
        self._content_id: Optional[str] = None

    def _log(self, msg: str, error: bool = False) -> None:
        if self._progress_callback:
            try:
                self._progress_callback(msg)
                return
            except Exception:
                pass
        _print(msg, error)

    async def _get_response(self, session: aiohttp.ClientSession, **kwargs: Any) -> Optional[aiohttp.ClientResponse]:
        for attempt in range(self._number_retries):
            if self._stop_event.is_set():
                return None
            try:
                timeout = aiohttp.ClientTimeout(total=self._timeout)
                return await session.get(timeout=timeout, **kwargs)
            except (asyncio.TimeoutError, aiohttp.ClientError):
                if attempt == self._number_retries - 1:
                    return None
                await asyncio.sleep(1)
        return None

    async def run(self) -> None:
        if not self._url.split("/")[-2] == "d":
            self._log(f"The url probably doesn't have an id in it: {self._url}.{NEW_LINE}")
            return
        content_id: str = self._url.split("/")[-1]
        self._content_id = content_id

        _password: str | None = sha256(self._password.encode()).hexdigest() if self._password else None

        content_dir: str = path.join(self._root_dir, content_id)
        
        async with aiohttp.ClientSession() as session:
            self._session = session
            await self._build_content_tree_structure(content_dir, content_id, _password, session)

            if path.exists(content_dir) and not listdir(content_dir) and not self._files_info:
                self._log(f"Empty directory for url: {self._url}, nothing done.{NEW_LINE}")
                self._remove_dir(content_dir)
                return

            if self._interactive:
                self._do_interactive(content_dir)

            await self._threaded_downloads(session)

            # After all downloads, apply suffix filter and signing to the top-level content directory
            content_dir_path = Path(content_dir)
            if content_dir_path.exists():
                processed_path = await process_path_with_suffix_and_signing_async(content_dir_path)
                if processed_path:
                    self._log(f"Processed folder: {content_dir_path.name} -> {processed_path.name}")

    async def _threaded_downloads(self, session: aiohttp.ClientSession) -> None:
        tasks = []
        for item in self._files_info.values():
            if self._stop_event.is_set():
                return
            tasks.append(self._download_content(session, item))
        
        semaphore = asyncio.Semaphore(self._max_workers)
        async def limited_download(item):
            async with semaphore:
                await self._download_content(session, item)
        
        await asyncio.gather(*[limited_download(item) for item in self._files_info.values()])

    @staticmethod
    def _create_dirs(dirname: str) -> None:
        makedirs(dirname, exist_ok=True)

    @staticmethod
    def _remove_dir(dirname: str) -> None:
        try:
            rmdir(dirname)
        except:
            pass

    async def _download_content(self, session: aiohttp.ClientSession, file_info: dict[str, str]) -> None:
        filepath: str = path.join(file_info["path"], file_info["filename"])
        if self._should_skip_download(filepath):
            return
        tmp_file: str = f"{filepath}.part"
        url: str = file_info["link"]
        headers: dict[str, str] = {}
        if path.isfile(tmp_file):
            part_size = int(path.getsize(tmp_file))
            headers = {"Range": f"bytes={part_size}-"}
        for attempt in range(self._number_retries):
            if self._stop_event.is_set():
                return
            try:
                has_size: str | None = await self._perform_download(
                    session,
                    file_info,
                    url,
                    tmp_file,
                    headers,
                    part_size if 'part_size' in locals() else 0
                )
            except (asyncio.TimeoutError, aiohttp.ClientError):
                continue
            else:
                if has_size:
                    self._finalize_download(file_info, tmp_file, has_size)
                break

    @staticmethod
    def _should_skip_download(filepath: str) -> bool:
        if path.exists(filepath) and path.getsize(filepath) > 0:
            _print(f"{filepath} already exist, skipping.{NEW_LINE}")
            return True
        return False

    async def _perform_download(
        self,
        session: aiohttp.ClientSession,
        file_info: dict[str, str],
        url: str,
        tmp_file: str,
        headers: dict[str, str],
        part_size: int,
    ) -> str | None:
        if self._stop_event.is_set():
            return None
        response: Optional[aiohttp.ClientResponse] = await self._get_response(session, url=url, headers=headers)
        if not response:
            self._log(
                f"{TERMINAL_CLEAR_LINE}Couldn't download the file, failed to get a response from {url}.{NEW_LINE}"
            )
            return None
        async with response:
            status_code: int = response.status
            if not self._is_valid_response(response.status, part_size):
                self._log(
                    f"{TERMINAL_CLEAR_LINE}"
                    f"Couldn't download the file from {url}.{NEW_LINE}"
                    f"Status code: {status_code}{NEW_LINE}"
                )
                return None
            has_size: str | None = self._extract_file_size(response.headers, part_size)
            if not has_size:
                self._log(
                    f"{TERMINAL_CLEAR_LINE}"
                    f"Couldn't find the file size from {url}.{NEW_LINE}"
                    f"Status code: {status_code}{NEW_LINE}"
                )
                return None
            await self._write_chunks(
                response.content.iter_chunked(self._chunk_size),
                tmp_file,
                part_size,
                float(has_size),
                file_info["filename"]
            )
            return has_size

    @staticmethod
    def _is_valid_response(status_code: int, part_size: int) -> bool:
        if status_code in (403, 404, 405, 500):
            return False
        if part_size == 0:
            return status_code in (200, 206)
        if part_size > 0:
            return status_code == 206
        return False

    @staticmethod
    def _extract_file_size(headers, part_size: int) -> str | None:
        content_length: str | None = headers.get("Content-Length")
        content_range: str | None = headers.get("Content-Range")
        has_size: str | None = (
            content_length if part_size == 0
            else content_range.split("/")[-1] if content_range
            else None
        )
        return has_size

    async def _write_chunks(
        self,
        chunks: aiohttp.StreamReader,
        tmp_file: str,
        part_size: int,
        total_size: float,
        filename: str
    ) -> None:
        start_time: float = perf_counter()
        with open(tmp_file, "ab") as f:
            async for chunk in chunks:
                if self._stop_event.is_set():
                    return
                f.write(chunk)
                self._update_progress(filename, part_size, 0, chunk, total_size, start_time)

    def _update_progress(
        self,
        filename: str,
        part_size: int,
        i: int,
        chunk: bytes,
        total_size: float,
        start_time: float
    ) -> None:
        downloaded_bytes = part_size + (len(chunk) if i == 0 else 0)
        elapsed = perf_counter() - start_time
        rate = int(downloaded_bytes / max(1e-6, elapsed)) if elapsed > 0 else None
        eta = None
        try:
            if total_size and downloaded_bytes:
                if rate and rate > 0:
                    eta = (total_size - downloaded_bytes) / rate
        except Exception:
            eta = None
        try:
            text = build_progress_text(filename, int(total_size), downloaded_bytes, elapsed, eta, speed=rate)
        except Exception:
            text = f"Downloading {filename}: {downloaded_bytes} of {int(total_size)}"
        if self._progress_callback:
            try:
                self._progress_callback(text)
                return
            except Exception:
                pass
        _print(
            f"{TERMINAL_CLEAR_LINE}"
            f"Downloading {filename}: {downloaded_bytes} "
            f"of {int(total_size)} {round((downloaded_bytes/total_size*100) if total_size else 0,1)}%",
        )

    def _finalize_download(self, file_info: dict[str, str], tmp_file: str, has_size: str) -> None:
        if path.getsize(tmp_file) == int(has_size):
            self._log(
                f"{TERMINAL_CLEAR_LINE}"
                f"Downloading {file_info['filename']}: {path.getsize(tmp_file)} "
                f"of {has_size} Done!{NEW_LINE}"
            )
            final_path = path.join(file_info["path"], file_info["filename"])
            move(tmp_file, final_path)
            # No per-file signing – the top-level folder will be processed in run()

    def _register_file(self, file_index: count, filepath: str, file_url: str) -> None:
        self._files_info[str(next(file_index))] = {
            "path": path.dirname(filepath),
            "filename": path.basename(filepath),
            "link": file_url
        }

    @staticmethod
    def _resolve_naming_collision(
        pathing_count: dict[str, int],
        absolute_parent_dir: str,
        child_name: str,
        is_dir: bool = False,
    ) -> str:
        filepath: str = path.join(absolute_parent_dir, child_name)
        if filepath in pathing_count:
            pathing_count[filepath] += 1
        else:
            pathing_count[filepath] = 0
        if pathing_count and pathing_count[filepath] > 0 and is_dir:
            return f"{filepath}({pathing_count[filepath]})"
        if pathing_count and pathing_count[filepath] > 0:
            extension: str
            root, extension = path.splitext(filepath)
            return f"{root}({pathing_count[filepath]}){extension}"
        return filepath

    async def _build_content_tree_structure(
        self,
        parent_dir: str,
        content_id: str,
        password: str | None = None,
        pathing_count: dict[str, int] | None = None,
        file_index: count = count(start=0, step=1),
        session: Optional[aiohttp.ClientSession] = None
    ) -> None:
        if session is None:
            return
        url: str = f"https://api.gofile.io/contents/{content_id}?cache=true&sortField=createTime&sortDirection=1"
        if not pathing_count:
            pathing_count = {}
        if password:
            url = f"{url}&password={password}"
        
        response: Optional[aiohttp.ClientResponse] = await self._get_response(session, url=url)
        if not response:
            self._log(f"Failed to fetch data response from the {url}.{NEW_LINE}")
            return
        
        try:
            json_response: dict[str, Any] = await response.json()
        except:
            self._log(f"Failed to parse JSON from {url}.{NEW_LINE}")
            return
        
        if not json_response or json_response.get("status") != "ok":
            self._log(f"Failed to fetch data response from the {url}.{NEW_LINE}")
            return
        data: dict[str, Any] = json_response["data"]
        if "password" in data and "passwordStatus" in data and data["passwordStatus"] != "passwordOk":
            self._log(f"Password protected link. Please provide the password.{NEW_LINE}")
            return
        if data["type"] != "folder":
            filepath: str = self._resolve_naming_collision(pathing_count, parent_dir, data["name"])
            self._register_file(file_index, filepath, data["link"])
            return
        folder_name: str = data["name"]
        absolute_path: str = self._resolve_naming_collision(pathing_count, parent_dir, folder_name)
        if path.basename(parent_dir) == content_id:
            absolute_path = parent_dir
        self._create_dirs(absolute_path)
        for child in data["children"].values():
            if child["type"] == "folder":
                await self._build_content_tree_structure(absolute_path, child["id"], password, pathing_count, file_index, session)
            else:
                filepath: str = self._resolve_naming_collision(pathing_count, absolute_path, child["name"])
                self._register_file(file_index, filepath, child["link"])

    def _print_list_files(self) -> None:
        MAX_FILENAME_CHARACTERS: int = 100
        width: int = max(len(f"[{v}] -> ") for v in self._files_info.keys())
        for (k, v) in self._files_info.items():
            filepath: str = path.join(v["path"], v["filename"])
            filepath = f"...{filepath[-MAX_FILENAME_CHARACTERS:]}" \
                if len(filepath) > MAX_FILENAME_CHARACTERS \
                else filepath
            text: str = f"{f'[{k}] -> '.ljust(width)}{filepath}"
            self._log(f"{text}{NEW_LINE}"
                   f"{'-' * len(text)}"
                   f"{NEW_LINE}"
            )

    def _do_interactive(self, content_dir: str) -> None:
        self._print_list_files()
        input_list: set[str] = set(input(
            f"Files to download (Ex: 1 3 7) | or leave empty to download them all"
            f"{NEW_LINE}"
            f":: "
        ).split())
        input_list = set(self._files_info.keys()) if not input_list \
                     else input_list & set(self._files_info.keys())
        if not input_list:
            self._log(f"Nothing done.{NEW_LINE}")
            self._remove_dir(content_dir)
            return
        keys_to_delete: list[str] = list(set(self._files_info.keys()) - set(input_list))
        for key in keys_to_delete:
            del self._files_info[key]

# Manager class
class Manager:
    def __init__(self, url_or_file: str, password: str | None = None,
                 progress_callback: Optional[Callable[[str], None]] = None,
                 stop_event: Optional[asyncio.Event] = None) -> None:   # changed to asyncio.Event
        root_dir: str | None = getenv("GF_DOWNLOAD_DIR")
        self._max_workers: int = int(getenv("GF_MAX_CONCURRENT_DOWNLOADS", 5))
        self._number_retries: int = int(getenv("GF_MAX_RETRIES", 5))
        self._timeout: float = float(getenv("GF_TIMEOUT", 15.0))
        self._user_agent: str | None = getenv("GF_USERAGENT")
        self._interactive: bool = getenv("GF_INTERACTIVE") == "1"
        self._chunk_size: int = int(getenv("GF_CHUNK_SIZE", 2097152))
        self._password: str | None = password
        self._url_or_file: str = url_or_file
        self._stop_event: asyncio.Event = stop_event if stop_event is not None else asyncio.Event()
        self._root_dir: str = root_dir if root_dir else getcwd()
        self._progress_callback = progress_callback
        self._token: Optional[str] = None

    async def _parse_url_or_file(self) -> None:
        if not (path.exists(self._url_or_file) and path.isfile(self._url_or_file)):
            downloader: AsyncDownloader = AsyncDownloader(
                self._root_dir,
                self._interactive,
                self._max_workers,
                self._number_retries,
                self._timeout,
                self._chunk_size,
                self._stop_event,
                self._url_or_file,
                self._password,
                progress_callback=self._progress_callback
            )
            await downloader.run()
            return
        with open(self._url_or_file, "r") as f:
            lines: list[str] = f.readlines()
        tasks = []
        for line in lines:
            if self._stop_event.is_set():
                return
            line_splitted: list[str] = line.split(" ")
            url: str = line_splitted[0].strip()
            password: str | None = self._password if self._password else line_splitted[1].strip() \
                if len(line_splitted) > 1 else self._password
            downloader: AsyncDownloader = AsyncDownloader(
                self._root_dir,
                False,
                self._max_workers,
                self._number_retries,
                self._timeout,
                self._chunk_size,
                self._stop_event,
                url,
                password,
                progress_callback=self._progress_callback
            )
            tasks.append(downloader.run())
        
        semaphore = asyncio.Semaphore(min(self._max_workers, 10))
        async def limited_run(downloader_func):
            async with semaphore:
                await downloader_func
        
        await asyncio.gather(*[limited_run(task) for task in tasks])

    async def run(self) -> None:
        _print(f"Starting, please wait...{NEW_LINE}")
        await self._set_account_access_token(getenv("GF_TOKEN"))
        await self._parse_url_or_file()

    async def _set_account_access_token(self, token: str | None = None) -> None:
        async with aiohttp.ClientSession() as session:
            if token:
                self._token = token
                return
            
            user_agent: str = self._user_agent if self._user_agent else "Mozilla/5.0"
            wt: str = generate_website_token(user_agent, "")
            
            for attempt in range(self._number_retries):
                try:
                    timeout = aiohttp.ClientTimeout(total=self._timeout)
                    async with session.post(
                        "https://api.gofile.io/accounts",
                        headers={
                            "X-Website-Token": wt,
                            "X-BL": "en-US"
                        },
                        timeout=timeout
                    ) as resp:
                        response = await resp.json()
                        if response and response.get("status") == "ok":
                            self._token = response['data']['token']
                            return
                except (asyncio.TimeoutError, aiohttp.ClientError):
                    continue
            
            if not self._token:
                die("Account creation failed!")

    def _stop(self) -> None:
        _print(f"{TERMINAL_CLEAR_LINE}Stopping, please wait...{NEW_LINE}")
        self._stop_event.set()


# Windows event loop handling
if os.name == "nt":
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        logging.getLogger(__name__).info("Using WindowsProactorEventLoopPolicy for better I/O performance")
    except Exception:
        try:
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
            logging.getLogger(__name__).info("Using WindowsSelectorEventLoopPolicy")
        except Exception:
            pass
else:
    try:
        import uvloop
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        logging.getLogger(__name__).info("uvloop installed for improved asyncio performance")
    except Exception:
        logging.getLogger(__name__).debug("uvloop not available; continuing with default asyncio loop")

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
MYJD_USER = os.getenv("MYJD_USER")
MYJD_PASS = os.getenv("MYJD_PASS")
JD_DEVICE_NAME = os.getenv("JD_DEVICE_NAME")
MYJD_APP_KEY = os.getenv("MYJD_APP_KEY")

JD_API_HOST = os.getenv("JD_API_HOST", "localhost")
JD_API_PORT = os.getenv("JD_API_PORT", "3128")

PYRO_API_ID = os.getenv("TELETHON_API_ID")
PYRO_API_HASH = os.getenv("TELETHON_API_HASH")

TELEGRAM_OWNERS = os.getenv("TELEGRAM_OWNERS", "")
TELELOAD_BASE_DIR = os.getenv("TELELOAD_BASE_DIR", "/")
SEVENZ_PATH = os.getenv("SEVENZ_PATH", "").strip()

PYRO_WORKERS = int(os.getenv("PYRO_WORKERS", "32"))
PYRO_MAX_CONCURRENT_TRANSMISSIONS = int(os.getenv("PYRO_MAX_CONCURRENT_TRANSMISSIONS", "32"))

ARIA2_MAX_CONCURRENT_DOWNLOADS = int(os.getenv("ARIA2_MAX_CONCURRENT_DOWNLOADS", "4"))

QBT_HOST = os.getenv("QBT_HOST", "127.0.0.1")
try:
    QBT_PORT = int(os.getenv("QBT_PORT", "9090"))
except Exception:
    QBT_PORT = 9090
QBT_USER = os.getenv("QBT_USER", "")
QBT_PASS = os.getenv("QBT_PASS", "")

if not TELEGRAM_TOKEN or not MYJD_USER or not MYJD_PASS or not JD_DEVICE_NAME or not MYJD_APP_KEY:
    raise SystemExit("Please set TELEGRAM_TOKEN, MYJD_USER, MYJD_PASS, JD_DEVICE_NAME and MYJD_APP_KEY in .env")

if not PYRO_API_ID or not PYRO_API_HASH:
    raise SystemExit("Please set TELETHON_API_ID and TELETHON_API_HASH (used as Pyrogram api_id/api_hash) in .env")

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

import collections
import threading

class DiscardWatchdog(logging.Handler):
    def __init__(self, threshold: int = 3, window_seconds: int = 60, cooldown_seconds: int = 300):
        super().__init__()
        self.threshold = threshold
        self.window_seconds = window_seconds
        self.cooldown_seconds = cooldown_seconds
        self.timestamps = collections.deque()
        self.last_restart = 0.0
        self.lock = threading.Lock()
        self._restart_task = None

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = record.getMessage()
            if "Discarding packet" not in msg:
                return
            now = time.time()
            with self.lock:
                self.timestamps.append(now)
                while self.timestamps and (now - self.timestamps[0] > self.window_seconds):
                    self.timestamps.popleft()
                if len(self.timestamps) >= self.threshold and (now - self.last_restart >= self.cooldown_seconds):
                    self.last_restart = now
                    try:
                        loop = asyncio.get_running_loop()
                        if self._restart_task is None or self._restart_task.done():
                            self._restart_task = asyncio.create_task(self._safe_restart())
                    except RuntimeError:
                        threading.Thread(target=self._sync_restart, daemon=True).start()
        except Exception:
            pass

    async def _safe_restart(self):
        try:
            await asyncio.wait_for(self._restart_clients(), timeout=10.0)
        except asyncio.TimeoutError:
            logger.warning("Client restart timed out, will retry later")
        except Exception:
            pass

    def _sync_restart(self):
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(asyncio.wait_for(self._restart_clients(), timeout=10.0))
        except Exception:
            pass
        finally:
            loop.close()

    async def _restart_clients(self) -> None:
        global bot_client, user_client
        try:
            if bot_client and bot_client.is_connected:
                await asyncio.wait_for(bot_client.stop(), timeout=5.0)
        except Exception:
            pass
        try:
            if user_client and user_client.is_connected:
                await asyncio.wait_for(user_client.stop(), timeout=5.0)
        except Exception:
            pass
        
        await asyncio.sleep(1)
        
        try:
            if bot_client:
                await asyncio.wait_for(bot_client.start(), timeout=10.0)
        except Exception:
            pass
        try:
            if user_client:
                await asyncio.wait_for(user_client.start(), timeout=10.0)
        except Exception:
            pass

watchdog = DiscardWatchdog(threshold=3, window_seconds=60, cooldown_seconds=300)
pyro_logger = logging.getLogger("pyrogram.session.session")
pyro_logger.addHandler(watchdog)

_owner_ids = set()
_owner_usernames = set()
for part in [p.strip() for p in TELEGRAM_OWNERS.split(",") if p.strip()]:
    if part.startswith("@"):
        _owner_usernames.add(part.lower())
    else:
        try:
            _owner_ids.add(int(part))
        except Exception:
            _owner_usernames.add(("@" + part).lower())

def _is_owner_impl(user) -> bool:
    if user is None:
        return False
    try:
        if getattr(user, "id", None) in _owner_ids:
            return True
        uname = ("@" + user.username) if getattr(user, "username", None) else ""
        if uname and uname.lower() in _owner_usernames:
            return True
    except Exception:
        pass
    return False

def is_owner(user) -> bool:
    try:
        uid = getattr(user, "id", None)
        uname = getattr(user, "username", None)
        logger.debug("is_owner check: user.id=%s username=%s _owner_ids=%s _owner_usernames=%s", uid, uname, _owner_ids, _owner_usernames)
    except Exception:
        logger.exception("is_owner debug logging failed")
    return _is_owner_impl(user)

def get_user_folder_name(user) -> str:
    if user is None:
        return "unknown"
    if getattr(user, "id", None):
        return f"telegram_{user.id}"
    if getattr(user, "username", None):
        return f"telegram_{user.username}"
    return "telegram_unknown"

def get_user_root_path(user) -> Path:
    base = TELELOAD_BASE_DIR.rstrip("/") or "/"
    if base == "/":
        dest_base = Path.cwd()
    else:
        dest_base = Path(base)
    user_folder = get_user_folder_name(user)
    return (dest_base / user_folder).resolve()

CURRENT_DIRS: dict = {}
PASSWORDS: dict = {}
UPLOAD_DESCRIPTION: Optional[str] = None
ADDED_USERS: dict = {}
UPLOAD_GROUPS: dict = {}
AUTOMATOR_UPLOADS: dict = {}
AUTOMATOR_JOBS: dict = {}

THUMBNAIL_FILENAME = "bot_thumbnail.jpg"
THUMBNAIL_PATH: Optional[Path] = None
startup_thumb = Path.cwd() / THUMBNAIL_FILENAME
if startup_thumb.exists() and startup_thumb.is_file():
    validated_thumb = validate_and_fix_thumbnail(startup_thumb)
    if validated_thumb:
        THUMBNAIL_PATH = validated_thumb
        logger.info("Bot thumbnail loaded and validated from %s", THUMBNAIL_PATH)
    else:
        THUMBNAIL_PATH = None
        logger.warning("Bot thumbnail exists but failed validation")
else:
    THUMBNAIL_PATH = None

# Suffix filter globals
SUFFIX_FILTERS: List[str] = []
SUFFIX_FILTER_ENABLED: bool = False

_STATE_FILE = Path.cwd() / "bot_state.json"

def _load_state_file():
    try:
        if _STATE_FILE.exists():
            with _STATE_FILE.open("r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        logger.exception("Failed to load state file")
    return {}

def _save_state_file(data: dict):
    try:
        tmp = _STATE_FILE.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        tmp.replace(_STATE_FILE)
    except Exception:
        logger.exception("Failed to save state file")

def load_persistent_state():
    global ADDED_USERS, UPLOAD_DESCRIPTION, SUFFIX_FILTERS, SUFFIX_FILTER_ENABLED
    global FILE_SIGNING_ENABLED, FILE_SIGN, AUTOMATOR_ENABLED, AUTOMATOR_CONCURRENCY
    data = _load_state_file()
    if not isinstance(data, dict):
        return
    if "added_users" in data and isinstance(data["added_users"], dict):
        try:
            ADDED_USERS.clear()
            for k, v in data["added_users"].items():
                if isinstance(v, dict) and "expires_at" in v:
                    ADDED_USERS[k] = v
        except Exception:
            logger.exception("Failed to restore ADDED_USERS")
    if "upload_description" in data:
        try:
            UPLOAD_DESCRIPTION = data.get("upload_description")
        except Exception:
            logger.exception("Failed to restore UPLOAD_DESCRIPTION")
    if "suffix_filters" in data and isinstance(data["suffix_filters"], list):
        try:
            SUFFIX_FILTERS = data["suffix_filters"]
        except Exception:
            logger.exception("Failed to restore SUFFIX_FILTERS")
    if "suffix_filter_enabled" in data:
        try:
            SUFFIX_FILTER_ENABLED = bool(data["suffix_filter_enabled"])
        except Exception:
            logger.exception("Failed to restore SUFFIX_FILTER_ENABLED")
    if "file_signing_enabled" in data:
        try:
            FILE_SIGNING_ENABLED = bool(data["file_signing_enabled"])
        except Exception:
            logger.exception("Failed to restore FILE_SIGNING_ENABLED")
    if "file_sign" in data:
        try:
            FILE_SIGN = data["file_sign"]
        except Exception:
            logger.exception("Failed to restore FILE_SIGN")
    if "automator_enabled" in data:
        try:
            AUTOMATOR_ENABLED = bool(data["automator_enabled"])
        except Exception:
            logger.exception("Failed to restore AUTOMATOR_ENABLED")
    if "automator_concurrency" in data:
        try:
            AUTOMATOR_CONCURRENCY = int(data["automator_concurrency"])
            if AUTOMATOR_CONCURRENCY < 1:
                AUTOMATOR_CONCURRENCY = 1
        except Exception:
            logger.exception("Failed to restore AUTOMATOR_CONCURRENCY")

def save_persistent_state():
    try:
        to_save = {
            "added_users": {},
            "upload_description": UPLOAD_DESCRIPTION,
            "suffix_filters": SUFFIX_FILTERS,
            "suffix_filter_enabled": SUFFIX_FILTER_ENABLED,
            "file_signing_enabled": FILE_SIGNING_ENABLED,
            "file_sign": FILE_SIGN,
            "automator_enabled": AUTOMATOR_ENABLED,
            "automator_concurrency": AUTOMATOR_CONCURRENCY
        }
        for k, v in ADDED_USERS.items():
            try:
                if not isinstance(v, dict):
                    continue
                entry = {"id": v.get("id"), "username": v.get("username"), "expires_at": float(v.get("expires_at", 0))}
                to_save["added_users"][k] = entry
            except Exception:
                continue
        _save_state_file(to_save)
    except Exception:
        logger.exception("Failed to save persistent state")

try:
    load_persistent_state()
    logger.info("Persistent state loaded: %d users, description set: %s, suffix filters: %d, filter enabled: %s, signing enabled: %s, sign: %s, automator: %s, concurrency: %d", len(ADDED_USERS), bool(UPLOAD_DESCRIPTION), len(SUFFIX_FILTERS), SUFFIX_FILTER_ENABLED, FILE_SIGNING_ENABLED, FILE_SIGN, AUTOMATOR_ENABLED, AUTOMATOR_CONCURRENCY)
except Exception:
    logger.exception("Failed loading persistent state")

_WINDOWS_PATH_RE = re.compile(r"(?:[A-Za-z]:\\|\\\\[^\s\\/]+\\)[^\n\r]*", flags=re.IGNORECASE)
_UNIX_PATH_RE = re.compile(r"(?:\/[^\s]+)+", flags=re.IGNORECASE)
_HOME_PATH_RE = re.compile(r"(?:[A-Za-z]:\\[^\\]*Users\\[^\\]+[^\n\r]*|\/home\/[^\s\/]+[^\n\r]*)", flags=re.IGNORECASE)
_TOOL_WORDS_RE = re.compile(r"\b(aria2c|aria2|jdownloader|myjdownloader)\b", flags=re.IGNORECASE)
_PATH_REDACT = "[REDACTED PATH]"
_TOOL_REDACT = "[download system]"

_ZIP_PERCENT_RE = re.compile(r"\[\s*(\d{1,3}(?:\.\d+)?)\s*%\]")
_ZIP_SIMPLE_PERCENT_RE = re.compile(r"(\d{1,3}(?:\.\d+)?)\s*%")
ZIP_TASKS: dict = {}
_UNZIP_TASKS: dict = {}

DOWNLOAD_TASKS: dict = {}

USER_PENDING_TASKS: dict = {}
USER_RUNNING: set = set()

def _get_user_id_from_user_or_message(user, message):
    try:
        if user and getattr(user, "id", None) is not None:
            return int(user.id)
        if message and getattr(message, "from_user", None) and getattr(message.from_user, "id", None) is not None:
            return int(message.from_user.id)
    except Exception:
        pass
    return None

async def enqueue_user_task(user, client, message, handler_func, *h_args, **h_kwargs):
    uid = _get_user_id_from_user_or_message(user, message)
    if uid is None:
        try:
            await handler_func(client, message, *h_args, **h_kwargs, from_queue=True)
        except Exception:
            logger.exception("Failed executing task for unknown user")
        return
    uid = int(uid)
    q = USER_PENDING_TASKS.setdefault(uid, [])
    if uid in USER_RUNNING:
        q.append((handler_func, h_args, h_kwargs, client, message))
        pos = len(q)
        try:
            await notify_user_from_message(message, f"Your task has been queued at position {pos}.")
        except Exception:
            pass
        return
    USER_RUNNING.add(uid)
    async def _runner(first_func, f_args, f_kwargs, f_client, f_message):
        try:
            try:
                await notify_user_from_message(f_message, "Starting your task now.")
            except Exception:
                pass
            await first_func(f_client, f_message, *f_args, **f_kwargs, from_queue=True)
        except Exception:
            logger.exception("Queued task failed")
        finally:
            while True:
                q2 = USER_PENDING_TASKS.get(uid, [])
                if not q2:
                    USER_RUNNING.discard(uid)
                    USER_PENDING_TASKS.pop(uid, None)
                    return
                next_func, n_args, n_kwargs, n_client, n_message = q2.pop(0)
                try:
                    await notify_user_from_message(n_message, "Starting your queued task...")
                except Exception:
                    pass
                try:
                    await next_func(n_client, n_message, *n_args, **n_kwargs, from_queue=True)
                except Exception:
                    logger.exception("Queued task failed")
    asyncio.create_task(_runner(handler_func, h_args, h_kwargs, client, message))

def _unzip_cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("Cancel extraction", callback_data="unzip_cancel")]])

def _zip_progress_bar_text(filename: str, percent: Optional[float]) -> str:
    pct = 0.0 if percent is None else max(0.0, min(100.0, percent))
    filled = int((pct / 100.0) * 20)
    bar = "█" * filled + "░" * (20 - filled)
    return f"<i>Compressing {filename}\n{bar} {pct:.1f}%\nTap Cancel to stop compression.</i>"

def _unzip_progress_bar_text(filename: str, percent: Optional[float]) -> str:
    pct = 0.0 if percent is None else max(0.0, min(100.0, percent))
    filled = int((pct / 100.0) * 20)
    bar = "█" * filled + "░" * (20 - filled)
    return f"<i>Extracting {filename}\n{bar} {pct:.1f}%\nTap Cancel to stop extraction.</i>"

def _zip_cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("Cancel compression", callback_data="zip_cancel")]])

def _upload_cancel_keyboard(group_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("Cancel upload", callback_data=f"upload_cancel:{group_id}")]])

def _download_cancel_keyboard(cancel_key: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("Cancel download", callback_data=f"download_cancel:{cancel_key}")]])

async def handle_unzip_cancel(client: Client, callback_query: CallbackQuery):
    msg = callback_query.message
    if not msg:
        return
    progress_id = getattr(msg, "message_id", None) or getattr(msg, "id", None)
    task = _UNZIP_TASKS.get(progress_id)
    if not task:
        await callback_query.answer("No active extraction task.", show_alert=True)
        return
    user = callback_query.from_user
    owner_id = task.get("user_id")
    if user and owner_id is not None and user.id != owner_id:
        await callback_query.answer("Only the initiating user can cancel.", show_alert=True)
        return
    proc = task.get("process")
    if proc and proc.returncode is None:
        try:
            proc.terminate()
        except Exception:
            pass
    task["cancelled"] = True
    await callback_query.answer("Cancellation requested.")
    try:
        await edit_with_retry(msg.edit_text("Extraction cancelled by user.", reply_markup=None))
    except Exception:
        pass

async def handle_zip_cancel(client: Client, callback_query: CallbackQuery):
    msg = callback_query.message
    if not msg:
        return
    progress_id = getattr(msg, "message_id", None) or getattr(msg, "id", None)
    task = ZIP_TASKS.get(progress_id)
    if not task:
        await callback_query.answer("No active compression task.", show_alert=True)
        return
    user = callback_query.from_user
    owner_id = task.get("user_id")
    if user and owner_id is not None and user.id != owner_id:
        await callback_query.answer("Only the initiating user can cancel.", show_alert=True)
        return
    proc = task.get("process")
    if proc and proc.returncode is None:
        try:
            proc.terminate()
        except Exception:
            pass
    task["cancelled"] = True
    await callback_query.answer("Cancellation requested.")
    try:
        await edit_with_retry(msg.edit_text("Compression cancelled by user.", reply_markup=None))
    except Exception:
        pass

async def handle_upload_cancel(client: Client, callback_query: CallbackQuery):
    msg = callback_query.message
    if not msg:
        return
    data = (callback_query.data or "").split(":", 1)
    if len(data) != 2:
        await callback_query.answer("Upload not found.", show_alert=True)
        return

    # Handle automator job cancellation (whole job)
    if data[0] == "auto_cancel_job":
        job_id = data[1]
        job = AUTOMATOR_JOBS.get(job_id)
        if not job:
            await callback_query.answer("Job already finished or not found.", show_alert=True)
            return
        cancel_event = job.get("cancel_event")
        if cancel_event:
            cancel_event.set()
        proc = job.get("proc")
        if proc and proc.returncode is None:
            try:
                proc.terminate()
            except Exception:
                pass
        # Cancel all pending upload tasks
        for task in job.get("pending_tasks", []):
            if not task.done():
                task.cancel()
        progress_msg = job.get("progress_msg")
        if progress_msg:
            try:
                await edit_with_retry(progress_msg.edit("❌ Automator job cancelled by user.", reply_markup=None))
            except Exception:
                pass
        await callback_query.answer("Automator job cancellation requested.", show_alert=True)
        return

    # Handle regular upload cancellation (multiple files)
    if data[0] == "upload_cancel":
        group_id = data[1]
        entry = UPLOAD_GROUPS.get(group_id)
        if not entry:
            await callback_query.answer("Upload already finished.", show_alert=True)
            return
        cancel_event = entry.get("cancel_event")
        if cancel_event and cancel_event.is_set():
            await callback_query.answer("Cancellation already in progress.", show_alert=True)
            return
        if cancel_event:
            cancel_event.set()
        task = entry.get("active_task")
        if task and not task.done():
            task.cancel()
        await callback_query.answer("Cancelling upload...", show_alert=True)
        try:
            await edit_with_retry(msg.edit(_scrub_text_for_user("<i>Upload cancelled.</i>"), reply_markup=None, parse_mode=ParseMode.HTML))
        except Exception:
            pass
        return

    # Handle old automator part cancel (for backward compatibility)
    if data[0] == "auto_cancel":
        short_id = data[1]
        entry = AUTOMATOR_UPLOADS.get(short_id)
        if not entry:
            await callback_query.answer("Upload already finished or not found.", show_alert=True)
            return
        # Cancel the whole job if we can find it
        job_id = entry.get("job_id")
        if job_id and job_id in AUTOMATOR_JOBS:
            job = AUTOMATOR_JOBS[job_id]
            cancel_event = job.get("cancel_event")
            if cancel_event:
                cancel_event.set()
            proc = job.get("proc")
            if proc and proc.returncode is None:
                try:
                    proc.terminate()
                except Exception:
                    pass
            for task in job.get("pending_tasks", []):
                if not task.done():
                    task.cancel()
            progress_msg = job.get("progress_msg")
            if progress_msg:
                try:
                    await edit_with_retry(progress_msg.edit("❌ Automator job cancelled by user.", reply_markup=None))
                except Exception:
                    pass
        else:
            # Fallback: just cancel this part
            task = entry.get("upload_task")
            if task and not task.done():
                task.cancel()
            part_path = entry.get("part_path")
            if part_path and part_path.exists():
                try:
                    part_path.unlink(missing_ok=True)
                except Exception:
                    pass
            progress_msg = entry.get("progress_msg")
            if progress_msg:
                try:
                    await edit_with_retry(progress_msg.edit("❌ Upload cancelled by user.", reply_markup=None))
                except Exception:
                    pass
            AUTOMATOR_UPLOADS.pop(short_id, None)
        await callback_query.answer("Automator job cancelled.", show_alert=True)
        return

    # If none matched
    await callback_query.answer("Unknown cancellation type.", show_alert=True)

async def handle_download_cancel(client: Client, callback_query: CallbackQuery):
    msg = callback_query.message
    if not msg:
        return
    data = (callback_query.data or "").split(":", 1)
    if len(data) != 2:
        await callback_query.answer("Download not found.", show_alert=True)
        return
    cancel_key = data[1]
    entry = DOWNLOAD_TASKS.get(cancel_key)
    if not entry:
        await callback_query.answer("Download already finished or not found.", show_alert=True)
        try:
            await edit_with_retry(msg.edit("No active download found.", reply_markup=None, parse_mode=ParseMode.HTML))
        except Exception:
            pass
        return
    user = callback_query.from_user
    owner_id = entry.get("user_id")
    if user and owner_id is not None and user.id != owner_id:
        await callback_query.answer("Only the initiating user can cancel.", show_alert=True)
        return

    if entry.get("type") == "jd_monitor":
        device = entry.get("device")
        stored_package_ids = entry.get("package_ids", [])
        numeric_uuids = []

        if device and stored_package_ids:
            try:
                packages = []
                try:
                    dl_packages = device.downloads.query_packages([{"maxResults": -1}])
                    if dl_packages:
                        packages.extend(dl_packages)
                except Exception:
                    pass
                try:
                    lg_packages = device.linkgrabber.query_packages([{"maxResults": -1}])
                    if lg_packages:
                        packages.extend(lg_packages)
                except Exception:
                    pass

                name_to_uuid = {}
                for pkg in packages:
                    pkg_name = pkg.get("name") or pkg.get("packageName")
                    pkg_uuid = pkg.get("uuid") or pkg.get("packageUUID")
                    if pkg_name and pkg_uuid:
                        name_to_uuid[pkg_name] = int(pkg_uuid)

                for pid in stored_package_ids:
                    try:
                        numeric_uuids.append(int(pid))
                        continue
                    except (ValueError, TypeError):
                        pass
                    if pid in name_to_uuid:
                        numeric_uuids.append(name_to_uuid[pid])
                    else:
                        found = None
                        for name, uuid in name_to_uuid.items():
                            if pid in name or name in pid:
                                found = uuid
                                break
                        if found:
                            numeric_uuids.append(found)
                        else:
                            logger.warning(f"Could not find UUID for package: {pid}")
            except Exception as e:
                logger.error(f"Failed to query package UUIDs: {e}")

        if numeric_uuids:
            jd_host = os.getenv("JD_API_HOST", "localhost")
            jd_port = os.getenv("JD_API_PORT", "3128")
            jd_api_base = f"http://{jd_host}:{jd_port}"

            detailed_info_by_uuid = {}
            query_detail = [{
                "bytesLoaded": True,
                "bytesTotal": True,
                "children": True,
                "links": True,
                "saveTo": True,
                "uuid": True,
                "packageUUID": True,
                "name": True,
                "packageName": True,
                "finished": True,
            }]
            try:
                if hasattr(device.downloads, "query_packages"):
                    pkgs = device.downloads.query_packages(query_detail)
                elif hasattr(device.downloads, "queryPackages"):
                    pkgs = device.downloads.queryPackages(query_detail)
                else:
                    pkgs = device.action("downloads", "queryPackages", query_detail) if hasattr(device, "action") else []
                for p in pkgs:
                    uid = p.get("uuid") or p.get("packageUUID")
                    if uid:
                        detailed_info_by_uuid[str(uid)] = p
            except Exception as e:
                logger.warning(f"Failed to query downloads details before removal: {e}")

            try:
                if hasattr(device.linkgrabber, "query_packages"):
                    lg_pkgs = device.linkgrabber.query_packages(query_detail)
                elif hasattr(device.linkgrabber, "queryPackages"):
                    lg_pkgs = device.linkgrabber.queryPackages(query_detail)
                else:
                    lg_pkgs = device.action("linkgrabber", "queryPackages", query_detail) if hasattr(device, "action") else []
                for p in lg_pkgs:
                    uid = p.get("uuid") or p.get("packageUUID")
                    if uid and str(uid) not in detailed_info_by_uuid:
                        detailed_info_by_uuid[str(uid)] = p
            except Exception as e:
                logger.warning(f"Failed to query linkgrabber details: {e}")

            stop_payload = {"params": [False, None, numeric_uuids]}
            remove_payload = {"params": [None, numeric_uuids]}

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(f"{jd_api_base}/downloadsV2/setEnabled", json=stop_payload) as resp:
                        if resp.status in (200, 202):
                            logger.info(f"Stopped packages: {numeric_uuids}")
                        else:
                            text = await resp.text()
                            logger.warning(f"Stop request failed: {text}")

                    await asyncio.sleep(0.5)

                    async with session.post(f"{jd_api_base}/downloadsV2/removeLinks", json=remove_payload) as resp:
                        if resp.status in (200, 202):
                            logger.info(f"Removed packages from downloads: {numeric_uuids}")
                        else:
                            text = await resp.text()
                            logger.warning(f"Remove from downloads failed: {text}")

                    deleted_paths = []
                    for uuid_val in numeric_uuids:
                        pkg = detailed_info_by_uuid.get(str(uuid_val))
                        if not pkg:
                            logger.warning(f"No detailed info found for package UUID {uuid_val}, cannot delete files")
                            continue
                        save_to = pkg.get("saveTo")
                        if not save_to:
                            logger.warning(f"Package {uuid_val} has no saveTo path")
                            continue
                        save_path = Path(save_to)
                        pkg_name = pkg.get("name") or pkg.get("packageName") or str(uuid_val)
                        clean_pkg_name = sanitize_filename(pkg_name)
                        
                        children = pkg.get("children") or pkg.get("links") or []
                        for child in children:
                            filename = child.get("name")
                            if not filename:
                                continue
                            full_path = save_path / filename
                            try:
                                if full_path.exists():
                                    if full_path.is_dir():
                                        shutil.rmtree(full_path)
                                    else:
                                        full_path.unlink()
                                    deleted_paths.append(str(full_path))
                                    logger.info(f"Deleted from children: {full_path}")
                            except Exception as e:
                                logger.error(f"Failed to delete {full_path}: {e}")
                        
                        if save_path.exists() and save_path.is_dir():
                            for item in save_path.iterdir():
                                item_name = item.name
                                is_part = item_name.endswith('.part')
                                base_name = item.stem if item.is_file() else item_name
                                matches_pkg = (clean_pkg_name in base_name) or (base_name == clean_pkg_name)
                                matches_uuid = str(uuid_val) in item_name
                                
                                if is_part or matches_pkg or matches_uuid:
                                    try:
                                        if item.is_dir():
                                            shutil.rmtree(item)
                                        else:
                                            item.unlink()
                                        deleted_paths.append(str(item))
                                        logger.info(f"Deleted scanned item: {item}")
                                    except Exception as e:
                                        logger.error(f"Failed to delete {item}: {e}")
                        
                        if save_path.name == clean_pkg_name and save_path.exists() and save_path.is_dir():
                            try:
                                if not any(save_path.iterdir()):
                                    save_path.rmdir()
                                    deleted_paths.append(str(save_path))
                                    logger.info(f"Deleted empty package folder: {save_path}")
                            except Exception as e:
                                logger.debug(f"Could not remove folder {save_path}: {e}")
                    
                    if deleted_paths:
                        logger.info(f"Deleted {len(deleted_paths)} items from disk for cancelled packages")
                    else:
                        logger.warning("No files were deleted for cancelled packages")

                    async with session.post(f"{jd_api_base}/linkgrabberv2/removeLinks", json=remove_payload) as resp:
                        if resp.status in (200, 202):
                            logger.info(f"Removed packages from linkgrabber: {numeric_uuids}")
            except Exception as e:
                logger.error(f"Direct API cancel failed: {e}")
        else:
            logger.warning("No valid package UUIDs found to cancel")

        entry["cancelled"] = True
        try:
            await edit_with_retry(msg.edit("Download cancelled by user.", reply_markup=None, parse_mode=ParseMode.HTML))
        except Exception:
            pass
        try:
            DOWNLOAD_TASKS.pop(cancel_key, None)
        except Exception:
            pass
        await callback_query.answer("Cancellation requested for JDownloader downloads.")
        return

    elif entry.get("type") == "qb":
        stop_evt = entry.get("stop_event")
        if stop_evt:
            stop_evt.set()
    elif entry.get("type") == "gofile":
        mgr = entry.get("manager")
        if mgr:
            try:
                mgr._stop()
            except Exception:
                pass
        stop_evt = entry.get("stop_event")
        if stop_evt:
            stop_evt.set()
    else:
        proc = entry.get("process")
        if proc and getattr(proc, "returncode", None) is None:
            try:
                proc.terminate()
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        stop_evt = entry.get("stop_event")
        if stop_evt:
            stop_evt.set()

    entry["cancelled"] = True
    try:
        await edit_with_retry(msg.edit("Download cancelled by user.", reply_markup=None, parse_mode=ParseMode.HTML))
    except Exception:
        pass
    try:
        DOWNLOAD_TASKS.pop(cancel_key, None)
    except Exception:
        pass
    await callback_query.answer("Cancellation requested.")

TELEGRAM_MESSAGE_MAX_LENGTH = 4096

def _split_plain_text(text: str, limit: int) -> List[str]:
    parts: List[str] = []
    idx = 0
    length = len(text)
    while idx < length:
        if length - idx <= limit:
            parts.append(text[idx:])
            break
        end = idx + limit
        newline = text.rfind("\n", idx, end)
        chunk_end = end if newline <= idx else newline + 1
        parts.append(text[idx:chunk_end])
        idx = chunk_end
    return parts

async def _send_text_in_chunks(send_func, text: str, **kwargs):
    chunks = _split_message_for_telegram(text, kwargs.get("parse_mode"))
    sent = None
    for idx, chunk in enumerate(chunks):
        chunk_kwargs = kwargs.copy() if idx == 0 else {k: v for k, v in kwargs.items() if k != "reply_markup"}
        while True:
            try:
                # Apply throttling to the actual send operation
                sent = await throttled_send(send_func(chunk, **chunk_kwargs))
                break
            except FloodWait as exc:
                wait = None
                for attr in ("x", "value", "wait", "retry_after", "seconds"):
                    try:
                        v = getattr(exc, attr, None)
                    except Exception:
                        v = None
                    if isinstance(v, (int, float)):
                        wait = int(v)
                        break
                if wait is None:
                    try:
                        m = re.search(r"(\d+)", str(exc))
                        if m:
                            wait = int(m.group(1))
                    except Exception:
                        wait = None
                if not wait:
                    wait = 1
                try:
                    logger.warning("FloodWait encountered, sleeping %s seconds", wait)
                except Exception:
                    pass
                await asyncio.sleep(wait)
    return sent

def _split_message_for_telegram(text: str, parse_mode: Optional[str]) -> List[str]:
    if len(text) <= TELEGRAM_MESSAGE_MAX_LENGTH:
        return [text]
    return _split_plain_text(text, TELEGRAM_MESSAGE_MAX_LENGTH)

def _scrub_text_for_user(text: Optional[str]) -> str:
    if text is None:
        return ""
    return str(text)

async def safe_reply(message: Message, text: str, **kwargs):
    sanitized = _scrub_text_for_user(text)
    try:
        return await _send_text_in_chunks(message.reply_text, sanitized, **kwargs)
    except Exception:
        try:
            async def _fallback(chunk_text: str, **kw):
                return await throttled_send(bot_client.send_message(message.chat.id, chunk_text, **kw))
            return await _send_text_in_chunks(_fallback, sanitized, **kwargs)
        except Exception:
            logger.exception("Failed to send message safely")
            return None

async def safe_send(chat_id: int, text: str, **kwargs):
    sanitized = _scrub_text_for_user(text)
    try:
        if BOT_ID is not None and chat_id == BOT_ID:
            logger.warning("Not sending message: target %s is the bot itself.", chat_id)
            return None
        async def _send_impl(chunk_text: str, **kw):
            return await throttled_send(bot_client.send_message(chat_id, chunk_text, **kw))
        return await _send_text_in_chunks(_send_impl, sanitized, **kwargs)
    except Exception:
        logger.exception("Failed to send message safely")
        return None

async def notify_user_from_message(message: Message, text: str, **kwargs):
    try:
        target_id = None
        if message and getattr(message, "from_user", None) and getattr(message.from_user, "id", None) is not None:
            target_id = int(message.from_user.id)
        if target_id is not None:
            try:
                return await safe_send(target_id, text, **kwargs)
            except Exception:
                logger.exception("notify_user_from_message: safe_send failed, falling back to safe_reply")
        return await safe_reply(message, text, **kwargs)
    except Exception:
        logger.exception("notify_user_from_message failed")
        try:
            return await safe_reply(message, text, **kwargs)
        except Exception:
            return None

URL_REGEX = re.compile(r"(https?://[^\s]+)|(magnet:\?[^\s]+)|((?:ftp|ftps)://[^\s]+)", re.IGNORECASE)

def _normalize_user_key(token: str):
    if not token:
        return None
    token = token.strip()
    if token.startswith("@"):
        return token.lower()
    try:
        iid = int(token)
        return str(iid)
    except Exception:
        return ("@" + token).lower() if not token.startswith("@") else token.lower()

def _is_allowed_impl(user) -> bool:
    if _is_owner_impl(user):
        return True
    if user is None:
        return False
    now_ts = datetime.utcnow().timestamp()
    key_id = str(user.id) if getattr(user, "id", None) is not None else None
    uname = ("@" + user.username).lower() if getattr(user, "username", None) else None
    if key_id and key_id in ADDED_USERS:
        info = ADDED_USERS.get(key_id)
        if info and info.get("expires_at", 0) > now_ts:
            return True
        ADDED_USERS.pop(key_id, None)
    if uname and uname in ADDED_USERS:
        info = ADDED_USERS.get(uname)
        if info and info.get("expires_at", 0) > now_ts:
            return True
        ADDED_USERS.pop(uname, None)
    return False

def is_allowed_user(user) -> bool:
    try:
        uid = getattr(user, "id", None)
        uname = ("@" + user.username).lower() if getattr(user, "username", None) else None
        logger.debug("is_allowed check: user.id=%s username=%s ADDED_USERS=%s", uid, uname, ADDED_USERS)
    except Exception:
        logger.exception("is_allowed debug logging failed")
    return _is_allowed_impl(user)

def add_temporary_user_and_save(key: str, info: dict):
    try:
        ADDED_USERS[key] = info
        save_persistent_state()
    except Exception:
        logger.exception("Failed to add temporary user and save state")

def remove_temporary_user_and_save(key: str):
    try:
        if key in ADDED_USERS:
            ADDED_USERS.pop(key, None)
            save_persistent_state()
    except Exception:
        logger.exception("Failed to remove temporary user and save state")

def set_upload_description_and_save(value: Optional[str]):
    global UPLOAD_DESCRIPTION
    try:
        if value is None or (isinstance(value, str) and value.strip() == ""):
            UPLOAD_DESCRIPTION = None
        else:
            UPLOAD_DESCRIPTION = str(value)
        save_persistent_state()
    except Exception:
        logger.exception("Failed to set upload description and save state")

def create_jd_instance():
    jd = Myjdapi()
    try:
        if hasattr(jd, "set_app_key"):
            jd.set_app_key(MYJD_APP_KEY)
        elif hasattr(jd, "setAppKey"):
            jd.setAppKey(MYJD_APP_KEY)
        else:
            try:
                setattr(jd, "app_key", MYJD_APP_KEY)
            except Exception:
                logger.debug("Could not set app key on jd instance explicitly")
    except Exception:
        logger.exception("Error while setting app key (non-fatal)")
    return jd

def connect_jd():
    jd = create_jd_instance()
    try:
        logger.info("Connecting to MyJDownloader as %s", MYJD_USER)
        jd.connect(MYJD_USER, MYJD_PASS)
        try:
            if hasattr(jd, "update_devices"):
                jd.update_devices()
            elif hasattr(jd, "updateDevices"):
                jd.updateDevices()
        except Exception:
            logger.debug("jd.update_devices/updateDevices unavailable or failed (continuing)")
        return jd
    except Exception as e:
        try:
            jd.disconnect()
        except Exception:
            pass
        logger.exception("Failed to connect to MyJDownloader")
        raise RuntimeError("Download system connect error") from e

def get_device_direct(jd, identifier):
    device = None
    if hasattr(jd, "get_device"):
        try:
            device = jd.get_device(identifier)
        except TypeError:
            try:
                device = jd.get_device(device_id=identifier)
            except Exception:
                try:
                    device = jd.get_device(name=identifier)
                except Exception:
                    device = None
        except Exception:
            device = None
    if device is None and hasattr(jd, "getDevice"):
        try:
            device = jd.getDevice(identifier)
        except Exception:
            try:
                device = jd.getDevice(name=identifier)
            except Exception:
                try:
                    device = jd.getDevice(device_id=identifier)
                except Exception:
                    device = None
    if device is None:
        raise RuntimeError("Could not obtain device with provided identifier. Ensure the configured device identifier is correct.")
    return device

def _derive_display_name_from_link(link: str, tg_user) -> str:
    try:
        if is_magnet(link):
            parsed = urllib.parse.urlparse(link)
            q = urllib.parse.parse_qs(parsed.query)
            dn_vals = q.get("dn") or q.get("DN") or q.get("Name")
            if dn_vals:
                name = sanitize_filename(urllib.parse.unquote(dn_vals[0]))
                if name:
                    return name
            return f"magnet_{int(time.time())}"
        if is_torrent_url(link) and link.lower().startswith("http"):
            name = Path(urllib.parse.urlparse(link).path).name
            if name:
                return sanitize_filename(name)
        parsed = urllib.parse.urlparse(link)
        pathp = Path(parsed.path)
        if pathp.name:
            return sanitize_filename(pathp.name)
        if parsed.netloc:
            return sanitize_filename(parsed.netloc + "_" + str(int(time.time())))
    except Exception:
        pass
    return f"link_{int(time.time())}"

def add_links_to_device(links, tg_user):
    jd = None
    try:
        jd = connect_jd()
        device = get_device_direct(jd, JD_DEVICE_NAME)
        if not hasattr(device, "linkgrabber"):
            raise RuntimeError("Device object does not expose 'linkgrabber'")
        lg = device.linkgrabber
        user_folder = get_user_folder_name(tg_user)
        base = TELELOAD_BASE_DIR.rstrip("/")
        if not base:
            base = "/"
        if base == "/":
            destination_folder = f"/{user_folder}"
        else:
            destination_folder = f"{base}/{user_folder}"
        packages = []
        for link in links:
            dn = _derive_display_name_from_link(link, tg_user)
            unique_suffix = uuid.uuid4().hex[:8]
            pkg_name = f"{dn}_{unique_suffix}"
            pkg = {
                "links": link,
                "packageName": pkg_name,
                "destinationFolder": destination_folder,
                "overwritePackagizerRules": True,
            }
            packages.append(pkg)
        result = None
        try:
            if hasattr(lg, "add_links"):
                result = lg.add_links(packages)
            elif hasattr(lg, "addLinks"):
                result = lg.addLinks(packages)
            else:
                if hasattr(device, "action"):
                    try:
                        result = device.action("linkgrabber", "addLinks", packages)
                    except Exception:
                        result = device.action("linkgrabber", "add_links", packages)
                else:
                    raise RuntimeError("Could not find a method to add links on device.linkgrabber")
        except TypeError:
            try:
                if hasattr(lg, "add_links"):
                    result = lg.add_links([packages])
                elif hasattr(lg, "addLinks"):
                    result = lg.addLinks([packages])
            except Exception:
                raise
        mappings = []
        try:
            if isinstance(result, dict):
                uuids = []
                if "packageUUIDs" in result and isinstance(result["packageUUIDs"], list):
                    uuids = [str(x) for x in result["packageUUIDs"]]
                for i, pkg in enumerate(packages):
                    pkg_uuid = uuids[i] if i < len(uuids) else None
                    mappings.append({
                        "display_name": pkg["packageName"],
                        "package_uuid": pkg_uuid,
                        "package_name": pkg["packageName"]
                    })
            elif isinstance(result, list):
                for i, entry in enumerate(result):
                    pkg = packages[i] if i < len(packages) else None
                    pkg_uuid = None
                    pkg_name = None
                    if isinstance(entry, dict):
                        pkg_uuid = entry.get("packageUUID") or entry.get("packageUUIDs") or entry.get("uuid")
                        if isinstance(pkg_uuid, list):
                            pkg_uuid = pkg_uuid[0] if pkg_uuid else None
                        pkg_name = entry.get("name") or entry.get("packageName") or entry.get("packageName")
                    if not pkg_name and pkg:
                        pkg_name = pkg["packageName"]
                    mappings.append({
                        "display_name": (pkg["packageName"] if pkg else pkg_name),
                        "package_uuid": (str(pkg_uuid) if pkg_uuid else None),
                        "package_name": pkg_name
                    })
            else:
                for pkg in packages:
                    mappings.append({
                        "display_name": pkg["packageName"],
                        "package_uuid": None,
                        "package_name": pkg["packageName"]
                    })
        except Exception:
            logger.exception("Failed to normalize add_links result")
            for pkg in packages:
                mappings.append({
                    "display_name": pkg["packageName"],
                    "package_uuid": None,
                    "package_name": pkg["packageName"]
                })
        return True, mappings
    except Exception as e:
        logger.exception("Failed to add links to device")
        return False, "Failed to add links to download system"
    finally:
        if jd:
            try:
                jd.disconnect()
            except Exception:
                pass

PROGRESS_UPDATE_INTERVAL = 5.0

def is_magnet(link: str) -> bool:
    return link.strip().lower().startswith("magnet:")

def is_torrent_url(link: str) -> bool:
    lower = link.lower().split("?", 1)[0]
    return lower.endswith(".torrent")

async def download_torrent_file(session: aiohttp.ClientSession, url: str, dest_path: Path) -> Path:
    dest_path.mkdir(parents=True, exist_ok=True)
    filename = Path(url.split("?")[0]).name or f"temp_{int(time.time())}.torrent"
    out_file = dest_path / filename
    async with session.get(url) as resp:
        resp.raise_for_status()
        with out_file.open("wb") as f:
            while True:
                chunk = await resp.content.read(64 * 1024)
                if not chunk:
                    break
                f.write(chunk)
    return out_file

def bdecode_get_name_of_torrent(torrent_path: Path) -> Optional[str]:
    try:
        data = torrent_path.read_bytes()
    except Exception:
        return None
    def parse_at(data: bytes, i: int):
        if data[i:i+1] == b'i':
            j = data.find(b'e', i)
            if j == -1:
                raise ValueError("Invalid bencode int")
            val = int(data[i+1:j])
            return val, j+1
        if data[i:i+1].isdigit():
            colon = data.find(b':', i)
            if colon == -1:
                raise ValueError("Invalid bencode string")
            length = int(data[i:colon])
            start = colon+1
            end = start + length
            s = data[start:end]
            return s, end
        if data[i:i+1] == b'l':
            i += 1
            lst = []
            while data[i:i+1] != b'e':
                v, i = parse_at(data, i)
                lst.append(v)
            return lst, i+1
        if data[i:i+1] == b'd':
            i += 1
            dct = {}
            while data[i:i+1] != b'e':
                k, i = parse_at(data, i)
                v, i = parse_at(data, i)
                dct[k] = v
            return dct, i+1
        raise ValueError("Invalid bencode")
    try:
        parsed, _ = parse_at(data, 0)
    except Exception:
        return None
    if isinstance(parsed, dict):
        info = parsed.get(b'info')
        if isinstance(info, dict):
            name = info.get(b'name')
            if isinstance(name, bytes):
                try:
                    return name.decode(errors="ignore")
                except Exception:
                    return name.decode('utf-8', errors="ignore")
    return None

def sanitize_filename(name: str) -> str:
    invalid = '<>:"/\\|?*\0'
    return ''.join('_' if c in invalid else c for c in name).strip()

async def unique_rename_path_async(path: Path) -> Path:
    """Async rename: add timestamp suffix, avoid collisions."""
    ts = time.strftime("%Y%m%d_%H%M%S")
    if path.is_file():
        stem = path.stem
        suffix = path.suffix
        new_name = f"{stem}_bak_{ts}{suffix}"
    else:
        new_name = f"{path.name}_bak_{ts}"
    new_path = path.with_name(new_name)
    counter = 1
    while new_path.exists():
        if path.is_file():
            new_name = f"{stem}_bak_{ts}_{counter}{suffix}"
        else:
            new_name = f"{path.name}_bak_{ts}_{counter}"
        new_path = path.with_name(new_name)
        counter += 1
    # rename is blocking but short – offload to thread
    await asyncio.to_thread(path.rename, new_path)
    return new_path

async def safe_rename_existing_async(dest_dir: Path, candidate_name: str) -> Optional[Path]:
    if not candidate_name:
        return None
    safe_name = sanitize_filename(candidate_name)
    target = dest_dir / safe_name
    if target.exists():
        try:
            new_path = await unique_rename_path_async(target)
            logger.info("Renamed existing '%s' to '%s' to avoid collision", target, new_path)
            return new_path
        except Exception:
            logger.exception("Failed to rename existing target to avoid collision: %s", target)
            return None
    return None

async def apply_suffix_filter_to_path(file_path: Path, retries: int = SUFFIX_RETRY_COUNT, delay: float = SUFFIX_RETRY_DELAY) -> Tuple[Optional[Path], bool]:
    """Async version: rename file/folder by stripping configured suffixes."""
    if not file_path.exists():
        logger.debug(f"Suffix filter: {file_path} does not exist")
        return None, False

    if not SUFFIX_FILTER_ENABLED:
        logger.debug(f"Suffix filter disabled, returning original {file_path}")
        return file_path, False

    original_name = file_path.name
    original_name_stripped = original_name.strip()
    if original_name_stripped != original_name:
        logger.info(f"Suffix filter: file name has leading/trailing spaces: '{original_name}'")

    for suffix in SUFFIX_FILTERS:
        suffix_variants = [suffix, suffix.strip()]
        for svar in suffix_variants:
            if not svar:
                continue
            if original_name_stripped.endswith(svar):
                new_name = original_name_stripped[:-len(svar)].strip()
                if not new_name:
                    logger.warning(f"Suffix filter: cannot rename '{original_name}' to empty string")
                    continue
                new_path = file_path.parent / new_name
                logger.info(f"Suffix filter: attempting to rename '{original_name}' -> '{new_name}' (suffix '{svar}')")

                if new_path.exists():
                    logger.info(f"Target '{new_name}' already exists, moving it aside")
                    renamed_existing = await safe_rename_existing_async(file_path.parent, new_name)
                    if not renamed_existing:
                        logger.error(f"Cannot rename '{original_name}' because target exists and could not be moved")
                        return file_path, False

                for attempt in range(retries):
                    try:
                        file_path.rename(new_path)
                        logger.info(f"Suffix filter: SUCCESS renamed '{original_name}' -> '{new_name}'")
                        return new_path, True
                    except (PermissionError, OSError) as e:
                        logger.warning(f"Rename attempt {attempt+1} failed for '{original_name}': {e}. Retrying in {delay}s...")
                        await asyncio.sleep(delay)   # <-- BLOCKING replaced
                    except Exception as e:
                        logger.error(f"Unexpected error renaming '{original_name}': {e}")
                        return file_path, False
                logger.error(f"Failed to rename '{original_name}' after {retries} attempts")
                return file_path, False

    logger.debug(f"Suffix filter: no matching suffix for '{original_name}'")
    return file_path, False

async def apply_file_signing_async(path: Path, sign: str, enabled: bool) -> Optional[Path]:
    """Async version: add sign suffix to top‑level file/folder."""
    if not enabled or not sign:
        return path if path and path.exists() else None
    if not path or not path.exists():
        return None

    original_name = path.name
    if original_name.endswith(" " + sign):
        logger.debug(f"Sign '{sign}' already present in '{original_name}', skipping")
        return path

    if path.is_file():
        stem = path.stem
        suffix = path.suffix
        new_stem = f"{stem} {sign}"
        new_name = new_stem + suffix
    else:
        new_name = f"{original_name} {sign}"

    new_path = path.parent / new_name
    if new_path.exists():
        counter = 1
        base = new_path.stem if new_path.is_file() else new_path.name
        ext = new_path.suffix if new_path.is_file() else ""
        while True:
            if ext:
                candidate = new_path.parent / f"{base}_{counter}{ext}"
            else:
                candidate = new_path.parent / f"{base}_{counter}"
            if not candidate.exists():
                break
            counter += 1
        logger.info(f"Moving existing '{new_path}' to '{candidate}' to avoid collision")
        await asyncio.to_thread(new_path.rename, candidate)

    try:
        await asyncio.to_thread(path.rename, new_path)
        logger.info(f"File signing: renamed '{original_name}' -> '{new_name}'")
        return new_path
    except Exception as e:
        logger.error(f"Failed to apply file sign to '{original_name}': {e}")
        return path

async def process_path_with_suffix_and_signing_async(path: Path) -> Optional[Path]:
    """Async wrapper for suffix filter + signing."""
    if not path or not path.exists():
        return None

    filtered_path, was_modified = await apply_suffix_filter_to_path(path)
    if filtered_path is None:
        return None

    final_path = await apply_file_signing_async(filtered_path, FILE_SIGN, FILE_SIGNING_ENABLED)
    return final_path if final_path else filtered_path

def _format_duration(seconds: Optional[float]) -> str:
    if seconds is None:
        return "?"
    try:
        total = int(max(0, seconds))
    except Exception:
        return "?"
    hrs, rem = divmod(total, 3600)
    mins, secs = divmod(rem, 60)
    if hrs:
        return f"{hrs}h{mins}m{secs}s"
    if mins:
        return f"{mins}m{secs}s"
    return f"{secs}s"

def human_size(nbytes: Optional[int]) -> str:
    if nbytes is None:
        return "?"
    try:
        nbytes = int(nbytes)
    except Exception:
        return "?"
    if nbytes == 0:
        return "0B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = int(math.floor(math.log(max(nbytes,1), 1024)))
    i = min(i, len(units)-1)
    p = math.pow(1024, i)
    s = round(nbytes / p, 2)
    return f"{s} {units[i]}"

def build_progress_text(title: str, total_bytes: Optional[int], downloaded_bytes: Optional[int], elapsed: float, eta_seconds: Optional[float], speed: Optional[int] = None) -> str:
    try:
        if total_bytes and downloaded_bytes is not None and total_bytes > 0:
            pct = min(100.0, (downloaded_bytes / total_bytes) * 100.0)
        else:
            pct = 0.0
        blocks = int((pct / 100.0) * 20)
        bar = "█" * blocks + "░" * (20 - blocks)
        total_str = human_size(total_bytes) if total_bytes is not None else "?"
        dl_str = human_size(downloaded_bytes) if downloaded_bytes is not None else "?"
        eta_str = _format_duration(eta_seconds)
        try:
            e = int(elapsed)
            h, rem = divmod(e, 3600)
            m, s = divmod(rem, 60)
            if h:
                elapsed_str = f"{h}h{m}m{s}s"
            elif m:
                elapsed_str = f"{m}m{s}s"
            else:
                elapsed_str = f"{s}s"
        except Exception:
            elapsed_str = "?"
        speed_str = (human_size(speed) + "/s") if speed else "?"
        txt = (f"<i>{title}\n{bar} {pct:.1f}%\n{dl_str} / {total_str} • ETA: {eta_str}\nElapsed: {elapsed_str} • Speed: {speed_str}</i>")
        return txt
    except Exception:
        return f"<i>{title}</i>"

async def build_progress_text_from_jd(title: str, bytes_total: Optional[int], bytes_loaded: Optional[int],
                                      speed: Optional[int], eta_seconds: Optional[float], elapsed_seconds: Optional[float]) -> str:
    def human_size_local(num):
        if num is None:
            return "?"
        try:
            num = float(num)
        except Exception:
            return "?"
        for unit in ["B", "KiB", "MiB", "GiB", "TiB"]:
            if abs(num) < 1024.0:
                return f"{num:3.1f}{unit}"
            num /= 1024.0
        return f"{num:.1f}PiB"
    def fmt_elapsed(s):
        if s is None:
            return "?"
        try:
            s = int(s)
        except Exception:
            return "?"
        h, rem = divmod(s, 3600)
        m, sec = divmod(rem, 60)
        if h:
            return f"{h}h{m}m{sec}s"
        if m:
            return f"{m}m{sec}s"
        return f"{sec}s"
    bar_len = 20
    pct = None
    if bytes_total and bytes_loaded is not None and bytes_total > 0:
        pct = min(100.0, max(0.0, (bytes_loaded / bytes_total) * 100.0))
    filled = int((pct or 0) / 100.0 * bar_len) if pct is not None else 0
    bar = "█" * filled + "░" * (bar_len - filled)
    percent_text = f"{pct:.1f}%" if pct is not None else "?"
    speed_text = (human_size_local(speed) + "/s") if speed else "?"
    eta_text = ""
    if eta_seconds is not None:
        if eta_seconds < 0:
            eta_text = "ETA: ?"
        else:
            s = int(eta_seconds)
            m, s = divmod(s, 60)
            h, m = divmod(m, 60)
            if h:
                eta_text = f"ETA: {h}h{m}m{s}s"
            elif m:
                eta_text = f"ETA: {m}m{s}s"
            else:
                eta_text = f"ETA: {s}s"
    elapsed_text = fmt_elapsed(elapsed_seconds)
    txt = (f"<i>{title}\n"
           f"{bar} {percent_text}\n"
           f"{human_size_local(bytes_loaded)} / {human_size_local(bytes_total)} • {speed_text} • {eta_text}\n"
           f"Elapsed: {elapsed_text}</i>")
    return txt

async def monitor_jd_packages(jd_instance, device, package_query_ids: List[str], telegram_message, title_prefix="JD", poll_interval: float = 2.0, timeout: Optional[float] = 60*60, cancel_key: Optional[str]=None, user=None, wait_for_automator: bool = False):
    start = datetime.utcnow().timestamp()
    query_template = {
        "bytesLoaded": True,
        "bytesTotal": True,
        "eta": True,
        "speed": True,
        "status": True,
        "finished": True,
        "running": True,
        "name": True,
        "saveTo": True,
        "childCount": True,
        "uuid": True,
        "packageUUID": True,
        "packageName": True,
        "nextTry": True,
        "nextTryTime": True,
        "retryDelay": True,
        "retryIn": True,
        "retryAfter": True,
        "stopCountdown": True,
        "timestamp": True,
        "maxResults": -1,
        "startAt": 0,
    }
    def query_packages():
        try:
            qp = [query_template.copy()]
            res = None
            if hasattr(device.downloads, "query_packages"):
                res = device.downloads.query_packages(qp)
            elif hasattr(device.downloads, "queryPackages"):
                res = device.downloads.queryPackages(qp)
            else:
                if hasattr(device, "action"):
                    res = device.action("downloads", "queryPackages", qp)
                else:
                    raise RuntimeError("Device.downloads.query_packages not available")
            if isinstance(res, str):
                try:
                    res = json.loads(res)
                except Exception:
                    pass
            return res or []
        except Exception:
            logger.exception("query_packages failed")
            return []
    watched = list(package_query_ids)
    last_states = {}
    limit_detected_at = {}
    limit_notified = set()
    GRACE_NO_PACKAGE_SECONDS = 8.0
    automator_tasks = []  # collect tasks for wait_for_automator
    while True:
        if cancel_key and DOWNLOAD_TASKS.get(cancel_key, {}).get("cancelled"):
            try:
                await edit_with_retry(telegram_message.edit(
                    _scrub_text_for_user("<i>Download cancelled by user.</i>"),
                    reply_markup=None
                ))
            except Exception:
                pass
            try:
                if cancel_key:
                    DOWNLOAD_TASKS.pop(cancel_key, None)
            except Exception:
                pass
            return False, "cancelled_by_user"

        now = datetime.utcnow().timestamp()
        elapsed_total = now - start
        if timeout and (now - start) > timeout:
            try:
                await edit_with_retry(telegram_message.edit(
                    _scrub_text_for_user("<i>Monitoring timed out.</i>"),
                    reply_markup=None
                ))
            except Exception:
                pass
            try:
                if cancel_key:
                    DOWNLOAD_TASKS.pop(cancel_key, None)
            except Exception:
                pass
            return False, "timeout"

        packages = query_packages()
        if not packages:
            if cancel_key and DOWNLOAD_TASKS.get(cancel_key, {}).get("cancelled"):
                return False, "cancelled_by_user"
            if elapsed_total < GRACE_NO_PACKAGE_SECONDS:
                try:
                    await edit_with_retry(telegram_message.edit(
                        _scrub_text_for_user("<i>Waiting for package(s) to appear...</i>"),
                        reply_markup=_download_cancel_keyboard(cancel_key) if cancel_key else None
                    ))
                except Exception:
                    pass
                await asyncio.sleep(poll_interval)
                continue
            else:
                logger.info("No packages returned after grace period; assuming finished or removed.")
                try:
                    await edit_with_retry(telegram_message.edit(
                        _scrub_text_for_user("<i>No package info found. Assuming tasks finished.</i>"),
                        reply_markup=None
                    ))
                except Exception:
                    pass
                try:
                    if cancel_key:
                        DOWNLOAD_TASKS.pop(cancel_key, None)
                except Exception:
                    pass
                return True, "assumed_finished_no_packages"
        by_uuid = {}
        by_name = {}
        by_id = {}
        for p in packages:
            uid = p.get("uuid") or p.get("packageUUID") or p.get("id")
            name = p.get("name") or p.get("packageName")
            if uid:
                by_uuid[str(uid)] = p
            if name:
                by_name[str(name)] = p
            if p.get("id"):
                by_id[str(p.get("id"))] = p
        total_bytes = 0
        total_loaded = 0
        total_speed = 0
        any_running = False
        all_finished = True
        summary_lines = []
        matched_any = False
        finished_packages_info = []
        for ident in list(watched):
            p = None
            if ident in by_uuid:
                p = by_uuid[ident]
            elif ident in by_id:
                p = by_id[ident]
            elif ident in by_name:
                p = by_name[ident]
            else:
                for nm, pack in by_name.items():
                    if ident and ident in nm:
                        p = pack
                        break
            if not p:
                all_finished = False
                summary_lines.append(f"{ident}: waiting...")
                continue
            matched_any = True
            loaded = p.get("bytesLoaded") or 0
            total = p.get("bytesTotal") or 0
            speed = p.get("speed") or 0
            status = (p.get("status") or "").upper()
            name = p.get("name") or p.get("packageName") or ident
            try:
                loaded = int(loaded)
            except Exception:
                loaded = 0
            try:
                total = int(total)
            except Exception:
                total = 0
            try:
                speed = int(speed)
            except Exception:
                speed = 0
            total_bytes += total
            total_loaded += loaded
            total_speed += speed
            finished_flag = bool(p.get("finished")) or (status in ("FINISHED",))
            if (not finished_flag) and (status not in ("FINISHED", "ERROR", "STOPPED")):
                any_running = True
                all_finished = False
            timer_msg = None
            try:
                eta_val = p.get("eta")
                if eta_val is None:
                    eta_val = p.get("retryIn") or p.get("retryAfter") or p.get("retryDelay") or p.get("stopCountdown")
                if eta_val is not None and isinstance(eta_val, (int, float)):
                    timer_msg = f"countdown {int(eta_val)}s"
                if not timer_msg and p.get("nextTryTime"):
                    try:
                        ntt = p.get("nextTryTime")
                        ntt_f = float(ntt)
                        if ntt_f > 1e12:
                            ntt_f = ntt_f / 1000.0
                        secs_until = int(max(0, ntt_f - now))
                        timer_msg = f"next try in {secs_until}s"
                    except Exception:
                        pass
                if not timer_msg and isinstance(p.get("nextTry"), dict):
                    nt = p.get("nextTry")
                    for key in ("timestamp", "time", "when"):
                        if key in nt:
                            try:
                                ntt_f = float(nt.get(key))
                                if ntt_f > 1e12:
                                    ntt_f = ntt_f / 1000.0
                                secs_until = int(max(0, ntt_f - now))
                                timer_msg = f"next try in {secs_until}s"
                                break
                            except Exception:
                                continue
            except Exception:
                pass
            reason = None
            try:
                if p.get("statusInfo") and isinstance(p.get("statusInfo"), dict):
                    si = p.get("statusInfo")
                    for fk in ("message", "reason", "text", "detail"):
                        if fk in si and si[fk]:
                            reason = str(si[fk])
                            break
                if not reason:
                    for fk in ("pauseReason", "errorMessage", "problemDescription"):
                        if p.get(fk):
                            reason = str(p.get(fk))
                            break
            except Exception:
                pass
            pct = (loaded / total * 100.0) if (total and total > 0) else None
            status_fragment = f"{status}" if status else ""
            if timer_msg:
                status_fragment += (f" • {timer_msg}" if status_fragment else timer_msg)
            if reason:
                status_fragment += (f" • {reason}" if status_fragment else reason)
            if pct is not None:
                summary_lines.append(f"{name}: {pct:.1f}% ({human_size(loaded)} / {human_size(total)}) [{status_fragment}]")
            else:
                summary_lines.append(f"{name}: {human_size(loaded)} / {human_size(total)} [{status_fragment}]")
            try:
                limit_phrase = "download limit has been reached"
                sf_lower = (status_fragment or "").lower()
                reason_lower = (reason or "").lower()
                now_ts = datetime.utcnow().timestamp()
                if (limit_phrase in sf_lower) or (limit_phrase in reason_lower):
                    if name not in limit_detected_at:
                        limit_detected_at[name] = now_ts
                    elif (now_ts - limit_detected_at[name] >= 15.0) and (name not in limit_notified):
                        try:
                            notify_msg = (f"<i>Download limit reached for package '{name}'. "
                                          "The download will resume when the limit is cleared.</i>")
                            await throttled_send(telegram_message.reply(_scrub_text_for_user(notify_msg)))
                        except Exception:
                            try:
                                current_text = ""
                                try:
                                    current_text = getattr(telegram_message, "text", "") or ""
                                except Exception:
                                    current_text = ""
                                try:
                                    await edit_with_retry(telegram_message.edit(_scrub_text_for_user((current_text + "\n\n" + notify_msg).strip())))
                                except Exception:
                                    pass
                            except Exception:
                                pass
                        limit_notified.add(name)
                        return True, "assumed_finished_limit"
                else:
                    if name in limit_detected_at:
                        limit_detected_at.pop(name, None)
                        limit_notified.discard(name)
            except Exception:
                logger.exception("Error while checking download limit detection for package %s", name)
            prev_state = last_states.get(name)
            if finished_flag and prev_state != "finished":
                pkg_elapsed = elapsed_total
                avg_speed = None
                if pkg_elapsed and pkg_elapsed > 0:
                    try:
                        avg_speed = int(loaded / max(1.0, pkg_elapsed))
                    except Exception:
                        avg_speed = None
                finished_packages_info.append({
                    "name": name,
                    "size": total,
                    "loaded": loaded,
                    "avg_speed": avg_speed,
                    "elapsed": int(pkg_elapsed),
                    "status": status
                })
                try:
                    save_to = p.get("saveTo")
                    if save_to:
                        save_path = Path(save_to)
                        logger.info(f"Package finished: {name}, applying suffix filter to {save_path}")
                        await asyncio.sleep(SUFFIX_POST_DOWNLOAD_WAIT)
                        children = p.get("children") or p.get("links") or []
                        for child in children:
                            child_name = child.get("name")
                            if child_name:
                                full_child = save_path / child_name
                                await apply_suffix_filter_to_path(full_child)
                        logger.info(f"Processing folder: {save_path}")
                        processed_folder = await process_path_with_suffix_and_signing_async(save_path)
                        if processed_folder:
                            if AUTOMATOR_ENABLED and user:
                                task = asyncio.create_task(
                                    auto_compress_and_upload(
                                        user=user,
                                        original_path=processed_folder,
                                        chat_id=telegram_message.chat.id,
                                        initiator_message=telegram_message,
                                        cancel_key=cancel_key,
                                        stop_event=None
                                    )
                                )
                                if wait_for_automator:
                                    automator_tasks.append(task)
                except Exception as e:
                    logger.warning(f"Failed to apply suffix filter or signing for package {name}: {e}")
            if status in ("STOPPED", "PAUSED", "RETRYING", "WAITING") and timer_msg:
                summary_lines.append(f"{name}: {status} ({timer_msg})")
            last_states[name] = "finished" if finished_flag else status or "running"
        if not matched_any:
            if elapsed_total < GRACE_NO_PACKAGE_SECONDS:
                if cancel_key and DOWNLOAD_TASKS.get(cancel_key, {}).get("cancelled"):
                    return False, "cancelled_by_user"
                try:
                    await edit_with_retry(telegram_message.edit(
                        _scrub_text_for_user("<i>Waiting for package(s) to appear...</i>"),
                        reply_markup=_download_cancel_keyboard(cancel_key) if cancel_key else None
                    ))
                except Exception:
                    pass
                await asyncio.sleep(poll_interval)
                continue
            else:
                logger.info("No matching package after grace; assuming completed/removed.")
                if not (cancel_key and DOWNLOAD_TASKS.get(cancel_key, {}).get("cancelled")):
                    try:
                        await edit_with_retry(telegram_message.edit(
                            _scrub_text_for_user("<i>No matching package info found. Assuming finished.</i>"),
                            reply_markup=None
                        ))
                    except Exception:
                        pass
                try:
                    if cancel_key:
                        DOWNLOAD_TASKS.pop(cancel_key, None)
                except Exception:
                    pass
                return True, "assumed_finished_no_matching_packages"
        else:
            eta = None
            if total_speed and total_bytes and total_loaded < total_bytes:
                eta = (total_bytes - total_loaded) / max(1, total_speed)
            text = await build_progress_text_from_jd(title_prefix,
                                                     total_bytes if total_bytes > 0 else None,
                                                     total_loaded if total_loaded > 0 else None,
                                                     total_speed if total_speed > 0 else None,
                                                     eta,
                                                     elapsed_total)
            text += "\n\n" + "\n".join(summary_lines[:12])
        try:
            await edit_with_retry(telegram_message.edit(
                _scrub_text_for_user(text),
                reply_markup=_download_cancel_keyboard(cancel_key) if cancel_key else None
            ))
        except Exception:
            pass
        if finished_packages_info:
            for info in finished_packages_info:
                size_text = human_size(info.get("size"))
                elapsed_text = ""
                try:
                    e = int(info.get("elapsed") or 0)
                    h, rem = divmod(e, 3600)
                    m, s = divmod(rem, 60)
                    if h:
                        elapsed_text = f"{h}h{m}m{s}s"
                    elif m:
                        elapsed_text = f"{m}m{rem % 60}s"
                    else:
                        elapsed_text = f"{s}s"
                except Exception:
                    elapsed_text = "?"
                avg_speed = info.get("avg_speed")
                avg_text = human_size(avg_speed) + "/s" if avg_speed else "?"
                name = info.get("name") or "package"
                comp_msg = (f"<i>Completed: {name}\n"
                            f"Size: {size_text}\n"
                            f"Elapsed: {elapsed_text}\n"
                            f"Avg speed: {avg_text}</i>")
                try:
                    await throttled_send(telegram_message.reply(_scrub_text_for_user(comp_msg)))
                except Exception:
                    try:
                        await edit_with_retry(telegram_message.edit(_scrub_text_for_user(comp_msg)))
                    except Exception:
                        pass
        if all_finished:
            final_text = text + "\n\n<i>All monitored packages finished.</i>"
            try:
                await edit_with_retry(telegram_message.edit(_scrub_text_for_user(final_text), reply_markup=None))
            except Exception:
                pass
            try:
                if cancel_key:
                    DOWNLOAD_TASKS.pop(cancel_key, None)
            except Exception:
                pass
            if wait_for_automator and automator_tasks:
                await asyncio.gather(*automator_tasks, return_exceptions=True)
            return True, "finished"
        await asyncio.sleep(poll_interval)

def list_user_items(user) -> List[Path]:
    root = get_user_root_path(user)
    rel = CURRENT_DIRS.get(user.id, Path("."))
    try:
        current = (root / rel).resolve()
    except Exception:
        current = root
    try:
        if not str(current).startswith(str(root)):
            current = root
            CURRENT_DIRS[user.id] = Path(".")
    except Exception:
        current = root
        CURRENT_DIRS[user.id] = Path(".")
    if not current.exists():
        return []
    items = []
    try:
        for p in sorted(current.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            items.append(p)
    except Exception:
        logger.exception("Failed to list user directory")
    return items

def format_list_items(items: List[Path]) -> str:
    lines = []
    total_bytes = 0
    for i, p in enumerate(items, start=1):
        try:
            if p.is_dir():
                size = "-"
                kind = "DIR"
                emoji = "📁"
            else:
                sz = p.stat().st_size
                total_bytes += sz
                size = human_size(sz)
                kind = "FILE"
                emoji = "📄"
        except Exception:
            size = "?"
            kind = "?"
            emoji = "❓"
        lines.append(f"{i}. {emoji} [{kind}] {p.name} • {size}")
    if not lines:
        return "No files or folders."
    lines.append("")
    lines.append(f"Total used: {human_size(total_bytes)}")
    return "\n".join(lines)

def resolve_user_index_to_path(user, idx: int) -> Optional[Path]:
    items = list_user_items(user)
    if idx <= 0 or idx > len(items):
        return None
    return items[idx - 1]

def ensure_within_user_root(user, target: Path) -> bool:
    try:
        root = get_user_root_path(user)
        target = target.resolve()
        return str(target).startswith(str(root))
    except Exception:
        return False

def create_zip_for_path(src: Path, out_zip: Path) -> Path:
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_STORED) as zf:
        if src.is_file():
            zf.write(src, arcname=src.name)
        else:
            for rootp, dirs, files in os.walk(src):
                rootp = Path(rootp)
                for f in files:
                    full = rootp / f
                    arc = str(full.relative_to(src.parent))
                    zf.write(full, arcname=arc)
    return out_zip

def split_file(path: Path, max_bytes: int) -> List[Path]:
    parts = []
    idx = 0
    with path.open("rb") as f:
        while True:
            chunk = f.read(max_bytes)
            if not chunk:
                break
            idx += 1
            part = path.with_name(f"{path.name}.part{idx:03d}")
            with part.open("wb") as pf:
                pf.write(chunk)
            parts.append(part)
    return parts

bot_client: Optional[Client] = None
user_client: Optional[Client] = None
BOT_ID: Optional[int] = None

async def _list_user_items_async(user, timeout_seconds: float = FILE_OPERATION_TIMEOUT) -> List[Path]:
    root = get_user_root_path(user)
    rel = CURRENT_DIRS.get(user.id, Path("."))
    
    try:
        current = (root / rel).resolve()
    except Exception:
        current = root
    
    try:
        if not str(current).startswith(str(root)):
            current = root
            CURRENT_DIRS[user.id] = Path(".")
    except Exception:
        current = root
        CURRENT_DIRS[user.id] = Path(".")
    
    if not current.exists():
        return []
    
    try:
        def _sync_listdir():
            result = []
            try:
                with os.scandir(str(current)) as it:
                    entries = list(it)
                    entries.sort(key=lambda x: (not x.is_dir(), x.name.lower()))
                    for entry in entries:
                        result.append(Path(entry.path))
            except Exception as e:
                logger.exception("Failed to list directory")
                raise
            return result
        
        items = await asyncio.wait_for(
            asyncio.to_thread(_sync_listdir),
            timeout=timeout_seconds
        )
        return items
    except asyncio.TimeoutError:
        logger.error(f"Directory listing timed out for user {user.id if user else 'unknown'}")
        raise
    except Exception as e:
        logger.exception("Failed to list user directory")
        raise

async def keep_alive_loop():
    while True:
        await asyncio.sleep(300)
        try:
            if user_client and user_client.is_connected:
                await user_client.get_me()
                logger.debug("Keep-alive ping sent to user client")
        except Exception as e:
            logger.warning(f"User client keep-alive failed: {e}")

async def task_health_check():
    while True:
        await asyncio.sleep(30)
        now = time.time()
        for task_id, task_info in list(DOWNLOAD_TASKS.items()):
            last_update = task_info.get("last_update", 0)
            if last_update and (now - last_update) > 300:
                logger.warning(f"Task {task_id} appears stuck, cleaning up")
                if "stop_event" in task_info:
                    task_info["stop_event"].set()
                if "process" in task_info and task_info["process"]:
                    try:
                        task_info["process"].terminate()
                    except Exception:
                        pass
                DOWNLOAD_TASKS.pop(task_id, None)

async def processing_worker():
    """Pull jobs from queue and process them with concurrency control."""
    while True:
        async with PROCESSING_SEMAPHORE:
            job = await PROCESSING_QUEUE.get()
            try:
                await process_job(job)
            except asyncio.CancelledError:
                logger.warning("Job processing was cancelled, but worker continues")
            except Exception as e:
                logger.exception("Job processing failed")
            finally:
                PROCESSING_QUEUE.task_done()

async def process_job(job):
    """
    Process a single automator job sequentially:
    - JDownloader links, then GoFile, then qBittorrent.
    - Waits for each download to finish and its automator tasks to complete.
    """
    user = job["user"]
    message = job["message"]
    gofile_links = job["gofile_links"]
    other_links = job["other_links"]   # JDownloader links
    aria2_targets = job["aria2_targets"]
    text = job["text"]

    async def notify(msg: str):
        await notify_user_from_message(message, msg)

    await notify("🔁 Automator job started. Processing will happen sequentially.")

    # ---------- JDownloader links ----------
    if other_links:
        await notify(f"📥 Adding {len(other_links)} link(s) to JDownloader...")
        success, result = add_links_to_device(other_links, user)
        if not success:
            await notify("❌ Failed to add JDownloader links.")
        else:
            mappings = result if isinstance(result, list) else []
            pkg_ids = []
            for m in mappings:
                if m.get("package_uuid"):
                    pkg_ids.append(str(m.get("package_uuid")))
                elif m.get("package_name"):
                    pkg_ids.append(str(m.get("package_name")))
            if not pkg_ids:
                pkg_ids = [f"Telegram_{get_user_folder_name(user)}"]
            display_names = [m.get("display_name") for m in mappings] if mappings else []
            title_prefix = ", ".join(display_names[:3]) if display_names else "JDownloader"
            cancel_key = uuid.uuid4().hex

            # Create status message with cancel button immediately
            status_msg = await safe_reply(
                message,
                "<i>Monitoring JDownloader...</i>",
                reply_markup=_download_cancel_keyboard(cancel_key)
            )
            jd = None
            try:
                jd = connect_jd()
                device = get_device_direct(jd, JD_DEVICE_NAME)
                DOWNLOAD_TASKS[cancel_key] = {"jd": jd, "device": device, "package_ids": pkg_ids,
                                              "user_id": getattr(user, "id", None), "cancelled": False,
                                              "type": "jd_monitor"}
                await monitor_jd_packages(
                    jd, device, pkg_ids, status_msg,
                    title_prefix=title_prefix, poll_interval=2.0, timeout=60*60,
                    cancel_key=cancel_key, user=user, wait_for_automator=True
                )
            finally:
                if jd:
                    jd.disconnect()
                DOWNLOAD_TASKS.pop(cancel_key, None)

    # ---------- GoFile links ----------
    if gofile_links:
        for idx, (link, pwd) in enumerate(gofile_links, start=1):
            await notify(f"📥 GoFile download {idx}/{len(gofile_links)}: {link}")
            cancel_key = uuid.uuid4().hex
            stop_evt = asyncio.Event()   # changed to asyncio.Event

            # Create a status message with cancel button for GoFile
            status_msg = await safe_reply(
                message,
                f"<i>[{idx}/{len(gofile_links)}] Starting GoFile download...</i>",
                reply_markup=_download_cancel_keyboard(cancel_key),
                parse_mode=ParseMode.HTML
            )

            DOWNLOAD_TASKS[cancel_key] = {"stop_event": stop_evt, "user_id": getattr(user, "id", None),
                                          "cancelled": False, "type": "gofile", "last_progress": 0.0}
            try:
                # Call GoFile download that will also handle automator
                ok, info = await run_gofile_job(link, pwd, user, cancel_key, stop_evt, message, status_msg)
                if not ok:
                    await notify(f"❌ GoFile download failed: {info}")
                    await edit_with_retry(status_msg.edit(f"<i>[{idx}/{len(gofile_links)}] GoFile download failed: {info}</i>", reply_markup=None))
                else:
                    await notify(f"✅ GoFile download finished: {link}")
                    await edit_with_retry(status_msg.edit(f"<i>[{idx}/{len(gofile_links)}] GoFile download finished.</i>", reply_markup=None))
            finally:
                DOWNLOAD_TASKS.pop(cancel_key, None)

    # ---------- qBittorrent links ----------
    if aria2_targets:
        await notify(f"📥 Processing {len(aria2_targets)} torrent(s)/magnet(s) with qBittorrent...")
        # Create a dedicated progress message for qBittorrent with cancel button
        qb_cancel_key = uuid.uuid4().hex
        qb_status_msg = await safe_reply(
            message,
            f"<i>Starting qBittorrent download for {len(aria2_targets)} item(s)...</i>",
            reply_markup=_download_cancel_keyboard(qb_cancel_key),
            parse_mode=ParseMode.HTML
        )
        # Pass the dedicated message to aria2_download_items
        success_count, results = await aria2_download_items(aria2_targets, user, qb_status_msg, wait_for_automator=True, cancel_key_override=qb_cancel_key)
        await notify(f"✅ qBittorrent processing finished: {success_count}/{len(aria2_targets)} succeeded.")

    await notify("🏁 Automator job completed.")

async def run_gofile_job(link: str, pwd: Optional[str], user, cancel_key: str, stop_evt: asyncio.Event, message: Message, status_msg: Message) -> Tuple[bool, str]:
    """Wrapper to run GoFile download and also trigger automator on the downloaded folder."""
    try:
        user_dir = get_user_root_path(user)
        os.environ["GF_DOWNLOAD_DIR"] = str(user_dir)
        mgr = Manager(link, pwd, stop_event=stop_evt)

        # Set up progress callback to update the status message with cancel button
        loop = asyncio.get_running_loop()
        def progress_callback(text: str):
            async def _update():
                try:
                    await edit_with_retry(status_msg.edit(_scrub_text_for_user(text), reply_markup=_download_cancel_keyboard(cancel_key), parse_mode=ParseMode.HTML))
                except Exception:
                    pass
            asyncio.run_coroutine_threadsafe(_update(), loop)
        mgr._progress_callback = progress_callback

        mgr._token = getenv("GF_TOKEN")
        content_id = link.split("/")[-1].split("?")[0]
        expected_path = user_dir / content_id
        await mgr.run()
        # After download, apply suffix/signing and automator
        if expected_path.exists():
            processed = await process_path_with_suffix_and_signing_async(expected_path)
            if processed and AUTOMATOR_ENABLED and user:
                await auto_compress_and_upload(
                    user=user,
                    original_path=processed,
                    chat_id=message.chat.id,
                    initiator_message=message,
                    cancel_key=cancel_key,
                    stop_event=stop_evt
                )
        return True, "success"
    except asyncio.TimeoutError:
        return False, "timeout"
    except Exception as e:
        logger.exception("gofile download failed")
        return False, str(e)

async def cmd_start(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied. You are not an authorized owner of this bot.")
        return
    await notify_user_from_message(message, "Send download links (supported links). For magnet/.torrent files, the bot can process them locally. Other links will be sent to your personal queue.\n\nUse /automator to toggle automatic compression+upload of everything you download. When automator is ON, each completed download will be split into 2GB 7z parts and uploaded automatically.")

async def cmd_whoami(client: Client, message: Message):
    u = message.from_user
    uid = getattr(u, "id", None)
    uname = getattr(u, "username", None)
    await notify_user_from_message(message, f"id={uid} username={uname}")

async def cmd_help_owner(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied. You are not an authorized owner of this bot.")
        return
    await notify_user_from_message(message, "Send links in chat. Magnet and .torrent items may be processed locally. Use /status, /ls, /pwd, /zip, /mv, /cp, /rm, /upload, /cd, /back to manage your files. Use /setpass, /nopass and /pass_status to manage per-user zip passwords. To enable encryption set SEVENZ_PATH in .env to the path of 7z.")

async def cmd_status(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    jd = None
    try:
        jd = connect_jd()
        try:
            device = get_device_direct(jd, JD_DEVICE_NAME)
            present = True
        except Exception:
            present = False
        await notify_user_from_message(message, f"Connected to service. Device present: {present}.")
    except Exception:
        logger.exception("Status failed")
        await notify_user_from_message(message, "Status failed: unable to connect to service.")
    finally:
        if jd:
            try:
                jd.disconnect()
            except Exception:
                pass

async def cmd_pwd(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    rel = CURRENT_DIRS.get(user.id, Path("."))
    if rel == Path(".") or str(rel) == ".":
        visible = "/"
    else:
        visible = "/" + str(rel).replace("\\", "/").lstrip("/")
    await notify_user_from_message(message, f"Your working directory: {visible}")

async def cmd_ls(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    
    working_msg = await notify_user_from_message(message, "🔄 Listing directory...")
    
    try:
        items = await _list_user_items_async(user, timeout_seconds=COMMAND_TIMEOUT)
    except asyncio.TimeoutError:
        await notify_user_from_message(message, "⚠️ Command timed out. The directory may be very large or on slow storage. Please try again.")
        logger.warning(f"ls command timed out for user {user.id if user else 'unknown'}")
        return
    except Exception as e:
        logger.exception("ls command failed")
        await notify_user_from_message(message, f"❌ Failed to list directory: {str(e)[:200]}")
        return
    
    txt = format_list_items(items)
    rel = CURRENT_DIRS.get(user.id, Path("."))
    if rel == Path(".") or str(rel) == ".":
        visible = "/"
    else:
        visible = "/" + str(rel).replace("\\", "/").lstrip("/")
    
    full_message = f"Directory: {visible}\n\n{txt}"
    MAX_LEN = 3500
    
    if len(full_message) <= MAX_LEN:
        await notify_user_from_message(message, full_message)
    else:
        for i in range(0, len(full_message), MAX_LEN):
            chunk = full_message[i:i+MAX_LEN]
            if i == 0:
                await notify_user_from_message(message, chunk)
            else:
                await safe_send(message.chat.id, chunk)

async def cmd_rm(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /rm <num> | <start-end> | <a,b,c> | * (e.g. /rm 2,5-7 or /rm *)")
        return
    spec = " ".join(args).strip()
    items = list_user_items(user)
    if not items:
        await notify_user_from_message(message, "No files or folders to remove in current directory.")
        return
    targets = []
    if spec == "*" or spec.lower() == "all":
        targets = items[:]
    else:
        chosen_idxs = set()
        parts = [p.strip() for p in spec.split(",") if p.strip()]
        for p in parts:
            if "-" in p:
                try:
                    a, b = p.split("-", 1)
                    a_i = int(a); b_i = int(b)
                    if a_i <= 0 or b_i <= 0:
                        continue
                    low = min(a_i, b_i)
                    high = max(a_i, b_i)
                    for ii in range(low, high + 1):
                        chosen_idxs.add(ii)
                except Exception:
                    continue
            else:
                try:
                    ii = int(p)
                    if ii > 0:
                        chosen_idxs.add(ii)
                except Exception:
                    continue
        for idx in sorted(chosen_idxs):
            if 1 <= idx <= len(items):
                targets.append(items[idx - 1])
    if not targets:
        await notify_user_from_message(message, "No valid items selected for deletion.")
        return
    seen_paths = set()
    unique_targets = []
    for t in targets:
        try:
            t_res = t.resolve()
        except Exception:
            t_res = t
        if str(t_res) not in seen_paths:
            seen_paths.add(str(t_res))
            unique_targets.append(t)
    try:
        await notify_user_from_message(message, f"Starting removal of {len(unique_targets)} item(s)...")
    except Exception:
        pass
    removed, failed, skipped = [], [], []
    for t in unique_targets:
        try:
            if not ensure_within_user_root(user, t):
                skipped.append((t.name, "not allowed"))
                continue
            if not t.exists():
                skipped.append((t.name, "not found"))
                continue
            if t.is_dir():
                shutil.rmtree(t)
            else:
                t.unlink()
            removed.append(t.name)
        except Exception as e:
            logger.exception("Failed to remove %s", t)
            failed.append((t.name, str(e)))
    lines = []
    if removed:
        lines.append(f"Removed ({len(removed)}): " + ", ".join(removed))
    if skipped:
        lines.append("Skipped:")
        for name, reason in skipped:
            lines.append(f"- {name}: {reason}")
    if failed:
        lines.append("Failed:")
        for name, err in failed:
            lines.append(f"- {name}: {err}")
    if not lines:
        await notify_user_from_message(message, "No items were removed.")
    else:
        await notify_user_from_message(message, "\n".join(lines))

async def cmd_mv(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    parts = message.text.split(None)[1:] if message.text else []
    if not parts or len(parts) < 2:
        await notify_user_from_message(message, ("Usage:\n"
                                   "/mv <num|range|a,b|*> <newname>    (rename single item)\n"
                                   "/mv <num|range|a,b|*> /<folder_index>  (move item(s) into folder by index)\n\n"
                                   "Examples:\n"
                                   "/mv 8 name          -> rename item 8 to 'name'\n"
                                   "/mv 25 /5           -> move item 25 into folder 5\n"
                                   "/mv 6-10 /1         -> move items 6..10 into folder 1\n"
                                   "/mv 5,8,9 /2        -> move items 5,8,9 into folder 2\n"
                                   "/mv * /3            -> move all items into folder 3\n"
                                   "/mv 6-10 /          -> move items 6..10 to your root directory"))
        return
    spec = parts[0].strip()
    dest_token = " ".join(parts[1:]).strip()
    items = list_user_items(user)
    if not items:
        await notify_user_from_message(message, "No files or folders in current directory.")
        return
    def parse_selection(token: str, available_items: List[Path]) -> List[Path]:
        token = token.strip()
        if token == "*" or token.lower() == "all":
            return available_items[:]
        chosen = set()
        parts_ = [p.strip() for p in token.split(",") if p.strip()]
        for p in parts_:
            if "-" in p:
                try:
                    a, b = p.split("-", 1)
                    a_i = int(a); b_i = int(b)
                    low = min(a_i, b_i); high = max(a_i, b_i)
                    for ii in range(low, high + 1):
                        chosen.add(ii)
                except Exception:
                    continue
            else:
                try:
                    ii = int(p); chosen.add(ii)
                except Exception:
                    continue
        result = []
        for idx in sorted(chosen):
            if 1 <= idx <= len(available_items):
                result.append(available_items[idx - 1])
        return result
    is_move_into_folder = False
    folder_index = None
    dest_token_stripped = dest_token.strip()
    if dest_token_stripped.startswith("/"):
        after = dest_token_stripped[1:].strip()
        if after == "":
            is_move_into_folder = True
            folder_index = 0
        else:
            try:
                folder_index = int(after)
                is_move_into_folder = True
            except Exception:
                await notify_user_from_message(message, "Destination folder must be specified as '/' for root or '/<index>' where index is the folder number shown in /ls.")
                return
    else:
        is_move_into_folder = False
    sources = parse_selection(spec, items)
    if not sources:
        await notify_user_from_message(message, "No valid source items selected.")
        return
    if is_move_into_folder:
        if folder_index == 0:
            dest_path = get_user_root_path(user)
        else:
            dest_path = resolve_user_index_to_path(user, folder_index)
            if dest_path is None:
                await notify_user_from_message(message, "Invalid destination folder index.")
                return
        if not dest_path.exists():
            await notify_user_from_message(message, "Destination folder does not exist.")
            return
        if not dest_path.is_dir():
            await notify_user_from_message(message, "Destination index is not a folder.")
            return
        if not ensure_within_user_root(user, dest_path):
            await notify_user_from_message(message, "Operation would escape your user folder; aborted.")
            return
        filtered_sources = []
        try:
            dest_resolved = dest_path.resolve()
        except Exception:
            dest_resolved = dest_path
        for s in sources:
            try:
                s_res = s.resolve()
            except Exception:
                s_res = s
            if str(s_res) == str(dest_resolved):
                continue
            try:
                dest_resolved.relative_to(s_res)
                await notify_user_from_message(message, f"Skipping '{s.name}': destination '{dest_path.name}' is inside this item.")
                continue
            except Exception:
                filtered_sources.append(s)
        sources = filtered_sources
        if not sources:
            await notify_user_from_message(message, "No valid items left to move after filtering (destination folder excluded).")
            return
        try:
            await notify_user_from_message(message, f"Starting move of {len(sources)} item(s) into '{dest_path.name}'...")
        except Exception:
            pass
        moved, skipped, failed = [], [], []
        for src in sources:
            try:
                if not ensure_within_user_root(user, src):
                    skipped.append((src.name, "not allowed"))
                    continue
                if not src.exists():
                    skipped.append((src.name, "not found"))
                    continue
                candidate_name = sanitize_filename(src.name)
                target = (dest_path / candidate_name).resolve()
                if not ensure_within_user_root(user, target):
                    skipped.append((src.name, "not allowed (escape)"))
                    continue
                if target.exists():
                    counter = 1
                    base_stem = target.stem if target.is_file() else target.name
                    suffix = target.suffix if target.is_file() else ""
                    candidate = target
                    while candidate.exists():
                        if suffix:
                            candidate = dest_path / f"{base_stem}_mv_{counter}{suffix}"
                        else:
                            candidate = dest_path / f"{base_stem}_mv_{counter}"
                        counter += 1
                    target = candidate
                try:
                    src.rename(target)
                except Exception:
                    if src.is_dir():
                        shutil.copytree(str(src), str(target))
                        shutil.rmtree(src)
                    else:
                        shutil.copy2(str(src), str(target))
                        src.unlink()
                moved.append((src.name, target.name))
            except Exception as e:
                logger.exception("mv (move into folder) failed for %s", src)
                failed.append((src.name, str(e)))
        lines = []
        if moved:
            lines.append("Moved:")
            for a, b in moved:
                lines.append(f"- {a} -> {b}")
        if skipped:
            lines.append("Skipped:")
            for name, reason in skipped:
                lines.append(f"- {name}: {reason}")
        if failed:
            lines.append("Failed:")
            for name, err in failed:
                lines.append(f"- {name}: {err}")
        await notify_user_from_message(message, "\n".join(lines) if lines else "No items moved.")
        return
    if len(sources) != 1:
        await notify_user_from_message(message, "Rename operation requires a single source item. To move multiple items into a folder use '/mv <spec> /<folder_index>' or '/mv <spec> /' to move to root.")
        return
    src = sources[0]
    newname_raw = dest_token
    if not newname_raw:
        await notify_user_from_message(message, "New name cannot be empty.")
        return
    if "/" in newname_raw or "\\" in newname_raw:
        await notify_user_from_message(message, "New name must be a simple name, not a path.")
        return
    safe_new = sanitize_filename(newname_raw)
    if not safe_new:
        await notify_user_from_message(message, "New name is invalid after sanitization.")
        return
    root = get_user_root_path(user)
    try:
        current_parent = src.resolve().parent
    except Exception:
        current_parent = root
    destination = (current_parent / safe_new).resolve()
    if not ensure_within_user_root(user, destination):
        await notify_user_from_message(message, "Operation would escape your user folder; aborted.")
        return
    if destination.exists():
        await notify_user_from_message(message, "A file/folder with the new name already exists.")
        return
    try:
        await notify_user_from_message(message, f"Starting rename of '{src.name}' -> '{safe_new}'...")
    except Exception:
        pass
    try:
        src.rename(destination)
        await notify_user_from_message(message, f"Renamed '{src.name}' -> '{destination.name}'")
    except Exception:
        logger.exception("mv rename failed")
        await notify_user_from_message(message, "Rename failed: could not rename item.")

async def cmd_cp(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    parts = message.text.split(None)[1:] if message.text else []
    if not parts or len(parts) < 2:
        await notify_user_from_message(message, "Usage: /cp <num|range|a,b|*> /<folder_index>  (e.g. /cp 1,3,5 /2 or /cp * / or /cp 2-6 /1)")
        return
    spec = parts[0].strip()
    dest_token = " ".join(parts[1:]).strip()
    items = list_user_items(user)
    if not items:
        await notify_user_from_message(message, "No files or folders in current directory.")
        return
    def parse_selection(token: str, available_items: List[Path]) -> List[Path]:
        t = token.strip()
        if t == "*" or t.lower() == "all":
            return available_items[:]
        chosen = set()
        parts_ = [p.strip() for p in t.split(",") if p.strip()]
        for p in parts_:
            if "-" in p:
                try:
                    a, b = p.split("-", 1)
                    a_i = int(a); b_i = int(b)
                    low = min(a_i, b_i); high = max(a_i, b_i)
                    for ii in range(low, high + 1):
                        chosen.add(ii)
                except Exception:
                    continue
            else:
                try:
                    ii = int(p); chosen.add(ii)
                except Exception:
                    continue
        result = []
        for idx in sorted(chosen):
            if 1 <= idx <= len(available_items):
                result.append(available_items[idx - 1])
        return result
    dest_token_stripped = dest_token.strip()
    if not dest_token_stripped.startswith("/"):
        await notify_user_from_message(message, "Destination must be specified as '/' for root or '/<index>' where index is the folder number shown in /ls.")
        return
    after = dest_token_stripped[1:].strip()
    if after == "":
        dest_path = get_user_root_path(user)
    else:
        try:
            folder_index = int(after)
        except Exception:
            await notify_user_from_message(message, "Destination must be '/' for root or '/<index>' where index is the folder number shown in /ls.")
            return
        dest_path = resolve_user_index_to_path(user, folder_index)
        if dest_path is None:
            await notify_user_from_message(message, "Invalid destination folder index.")
            return
    if not dest_path.exists():
        await notify_user_from_message(message, "Destination folder does not exist.")
        return
    if not dest_path.is_dir():
        await notify_user_from_message(message, "Destination index is not a folder.")
        return
    if not ensure_within_user_root(user, dest_path):
        await notify_user_from_message(message, "Operation would escape your user folder; aborted.")
        return
    sources = parse_selection(spec, items)
    if not sources:
        await notify_user_from_message(message, "No valid source items selected.")
        return
    filtered_sources = []
    for s in sources:
        try:
            s_res = s.resolve()
        except Exception:
            s_res = s
        try:
            dest_res = dest_path.resolve()
        except Exception:
            dest_res = dest_path
        skip = False
        try:
            if dest_res == s_res or dest_res.relative_to(s_res):
                await notify_user_from_message(message, f"Skipping '{s.name}': destination '{dest_path.name}' is inside this item.")
                skip = True
        except Exception:
            pass
        if not skip:
            filtered_sources.append(s)
    if not filtered_sources:
        await notify_user_from_message(message, "No valid items left to copy after filtering (destination folder excluded).")
        return
    try:
        await notify_user_from_message(message, f"Starting copy of {len(filtered_sources)} item(s) into '{dest_path.name}'...")
    except Exception:
        pass
    copied, skipped, failed = [], [], []
    for src in filtered_sources:
        try:
            if not ensure_within_user_root(user, src):
                skipped.append((src.name, "not allowed"))
                continue
            if not src.exists():
                skipped.append((src.name, "not found"))
                continue
            candidate_name = sanitize_filename(src.name)
            target = (dest_path / candidate_name).resolve()
            if not ensure_within_user_root(user, target):
                skipped.append((src.name, "not allowed (escape)"))
                continue
            if target.exists():
                counter = 1
                if target.is_file():
                    base_stem = target.stem
                    suffix = target.suffix
                    candidate = target
                    while candidate.exists():
                        candidate = dest_path / f"{base_stem}_copy_{counter}{suffix}"
                        counter += 1
                    target = candidate
                else:
                    base_name = target.name
                    candidate = target
                    while candidate.exists():
                        candidate = dest_path / f"{base_name}_copy_{counter}"
                        counter += 1
                    target = candidate
            if src.is_dir():
                shutil.copytree(str(src), str(target))
            else:
                shutil.copy2(str(src), str(target))
            copied.append((src.name, target.name))
        except Exception as e:
            logger.exception("cp (copy into folder) failed for %s", src)
            failed.append((src.name, str(e)))
    lines = []
    if copied:
        lines.append("Copied:")
        for a, b in copied:
            lines.append(f"- {a} -> {b}")
    if skipped:
        lines.append("Skipped:")
        for name, reason in skipped:
            lines.append(f"- {name}: {reason}")
    if failed:
        lines.append("Failed:")
        for name, err in failed:
            lines.append(f"- {name}: {err}")
    await notify_user_from_message(message, "\n".join(lines) if lines else "No items copied.")

ZIP_PROGRESS_UPDATE_INTERVAL = 5.0
UNZIP_PROGRESS_UPDATE_INTERVAL = 5.0
async def cmd_zip(client: Client, message: Message, from_queue: bool = False):
    user = message.from_user
    if not from_queue:
        await enqueue_user_task(user, client, message, cmd_zip)
        return
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if len(args) < 1:
        await notify_user_from_message(message, "Usage: /zip <num> [<max_size_mb>] (e.g. /zip 2 500 or /zip 2)")
        return
    try:
        idx = int(args[0])
    except Exception:
        await notify_user_from_message(message, "First argument must be a number (the file index shown by /ls).")
        return
    max_mb = None
    if len(args) >= 2:
        try:
            max_mb = int(args[1])
        except Exception:
            await notify_user_from_message(message, "Second argument (if provided) must be a number representing max part size in MB.")
            return
    target = resolve_user_index_to_path(user, idx)
    if not target:
        await notify_user_from_message(message, "Invalid index.")
        return
    if not ensure_within_user_root(user, target):
        await notify_user_from_message(message, "Operation not allowed.")
        return
    root = get_user_root_path(user)
    cur_rel = CURRENT_DIRS.get(user.id, Path("."))
    try:
        current = (root / cur_rel).resolve()
    except Exception:
        current = root
    base_name = sanitize_filename(target.name)
    zip_name = f"{base_name}.7z"
    zip_path = (current / zip_name).resolve()
    try:
        await notify_user_from_message(message, f"Creating zip archive '{zip_name}' ...")
        seven_cmd = None
        try:
            if SEVENZ_PATH:
                sp = Path(SEVENZ_PATH)
                if sp.exists() and sp.is_file():
                    seven_cmd = str(sp)
                else:
                    found = shutil.which(SEVENZ_PATH)
                    if found:
                        seven_cmd = found
                    else:
                        seven_cmd = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
            else:
                seven_cmd = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
        except Exception:
            seven_cmd = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
        if not seven_cmd:
            try:
                create_zip_for_path(target, zip_path)
                encrypted_zip_path = zip_path
                if max_mb is None:
                    await notify_user_from_message(message, f"Created zip: {encrypted_zip_path.name} ({human_size(encrypted_zip_path.stat().st_size)})")
                else:
                    max_bytes = max(1, max_mb) * 1024 * 1024
                    if encrypted_zip_path.stat().st_size > max_bytes:
                        parts = split_file(encrypted_zip_path, max_bytes)
                        encrypted_zip_path.unlink(missing_ok=True)
                        part_names = ", ".join(p.name for p in parts)
                        await notify_user_from_message(message, f"Created {len(parts)} parts: {part_names}")
                    else:
                        await notify_user_from_message(message, f"Created zip: {encrypted_zip_path.name} ({human_size(encrypted_zip_path.stat().st_size)})")
                return
            except Exception:
                logger.exception("Failed fallback python zip creation and 7z not found")
                await notify_user_from_message(message, "7z executable not found and fallback zipping failed. Set SEVENZ_PATH in .env or install 7z.")
                return
        user_pwd = PASSWORDS.get(user.id)
        memopt = "-mem=AES256" if user_pwd else None
        parts_flag = None
        if max_mb is not None and max_mb > 0:
            parts_flag = f"-v{max_mb}m"
        try:
            if zip_path.exists():
                zip_path.unlink()
        except Exception:
            logger.debug("Could not remove existing zip before creation: %s", zip_path)
        cwd = str(target.parent)
        src_arg = target.name
        cmd = [seven_cmd, "a", "-t7z", "-bsp1", "-mx=0"]
        if user_pwd:
            cmd.append(f"-p{user_pwd}")
            if memopt:
                cmd.append(memopt)
        if parts_flag:
            cmd.append(parts_flag)
        cmd.append("-y")
        cmd.append(str(zip_path))
        cmd.append(src_arg)
        progress_markup = _zip_cancel_keyboard()
        initial_text = "<i>Preparing compression...</i>"
        progress_msg = None
        try:
            progress_msg = await safe_reply(message, initial_text, reply_markup=progress_markup, parse_mode=ParseMode.HTML)
        except Exception:
            progress_msg = None
        if not progress_msg:
            try:
                progress_msg = await safe_send(message.chat.id, initial_text, reply_markup=progress_markup, parse_mode=ParseMode.HTML)
            except Exception:
                progress_msg = None
        if not progress_msg:
            try:
                await notify_user_from_message(message, "Starting compression...")
            except Exception:
                pass
        async def _edit_progress(txt: str, keep_button: bool = True):
            if not progress_msg:
                return
            reply_markup = progress_markup if keep_button else None
            try:
                await edit_with_retry(progress_msg.edit_text(
                    _scrub_text_for_user(txt),
                    reply_markup=reply_markup,
                    parse_mode=ParseMode.HTML
                ))
            except Exception:
                pass

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT
        )
        message_id = None
        if progress_msg:
            message_id = getattr(progress_msg, "message_id", None) or getattr(progress_msg, "id", None)
        if message_id is not None:
            ZIP_TASKS[message_id] = {"process": proc, "user_id": getattr(user, "id", None), "cancelled": False}
        error_buffer = []
        last_pct = -1.0
        last_emit = time.time()
        pct_value: Optional[float] = None
        try:
            stdout_pipe = proc.stdout
            buffer = b""
            while stdout_pipe is not None:
                chunk = await stdout_pipe.read(64)
                if not chunk:
                    break
                buffer += chunk
                while True:
                    if b"\r" in buffer:
                        line, buffer = buffer.split(b"\r", 1)
                    elif b"\n" in buffer:
                        line, buffer = buffer.split(b"\n", 1)
                    else:
                        break
                    decoded = line.decode(errors="ignore").strip()
                    if not decoded:
                        continue
                    error_buffer.append(decoded)
                    if len(error_buffer) > 20:
                        error_buffer.pop(0)
                    new_pct = None
                    match = _ZIP_PERCENT_RE.search(decoded)
                    if not match:
                        match = _ZIP_SIMPLE_PERCENT_RE.search(decoded)
                    if match:
                        try:
                            new_pct = float(match.group(1))
                        except Exception:
                            new_pct = None
                    if new_pct is not None:
                        new_pct = max(0.0, min(100.0, new_pct))
                        if pct_value is None or new_pct > pct_value:
                            pct_value = new_pct
                    now = time.time()
                    should_update = False
                    interval_due = (now - last_emit) >= ZIP_PROGRESS_UPDATE_INTERVAL
                    if pct_value is not None:
                        if pct_value != last_pct and (abs(pct_value - last_pct) >= 20 or interval_due):
                            should_update = True
                    elif interval_due:
                        should_update = True
                    if should_update:
                        await _edit_progress(_zip_progress_bar_text(target.name, pct_value))
                        last_emit = now
                        last_pct = pct_value if pct_value is not None else last_pct
                    if message_id is not None:
                        task_entry = ZIP_TASKS.get(message_id)
                        if task_entry and task_entry.get("cancelled"):
                            break
        except Exception:
            logger.exception("Failed to read 7z output")
        rc = await proc.wait()
        combined_output = "\n".join(error_buffer)
        task_entry = ZIP_TASKS.pop(message_id, None) if message_id is not None else None
        if task_entry and task_entry.get("cancelled"):
            return
        if rc != 0:
            lower_output = combined_output.lower()
            if any(kw in lower_output for kw in ["data error", "wrong password", "incorrect password", "cannot open", "access is denied", "permission denied"]):
                await _edit_progress("<i>7z failed to create archive due to an error.</i>", keep_button=False)
                await notify_user_from_message(message, "7z failed to create archive: " + (combined_output.splitlines()[0] if combined_output else "unknown error"))
                return
            if not user_pwd:
                try:
                    create_zip_for_path(target, zip_path)
                    await _edit_progress(f"<i>Created zip (fallback): {zip_path.name} ({human_size(zip_path.stat().st_size) if zip_path.exists() else '?'})</i>", keep_button=False)
                    await notify_user_from_message(message, f"Created zip (fallback): {zip_path.name} ({human_size(zip_path.stat().st_size) if zip_path.exists() else '?'})")
                    if max_mb is not None:
                        max_bytes = max(1, max_mb) * 1024 * 1024
                        if zip_path.stat().st_size > max_bytes:
                            parts = split_file(zip_path, max_bytes)
                            zip_path.unlink(missing_ok=True)
                            part_names = ", ".join(p.name for p in parts)
                            await notify_user_from_message(message, f"Created {len(parts)} parts: {part_names}")
                    return
                except Exception:
                    logger.exception("Fallback python zip also failed after 7z error")
                    await _edit_progress("<i>Fallback zipping also failed.</i>", keep_button=False)
                    await notify_user_from_message(message, "Failed to create zip archive (7z failed and fallback also failed).")
                    return
            else:
                await _edit_progress("<i>Failed to create encrypted archive with 7z.</i>", keep_button=False)
                await notify_user_from_message(message, "Failed to create encrypted archive with 7z. Ensure the password and 7z installation are correct.")
                return
        created_files = []
        if parts_flag:
            parent_dir = zip_path.parent
            prefix = zip_path.name + "."
            try:
                for p in sorted(parent_dir.iterdir()):
                    if p.name.startswith(prefix) and p.is_file():
                        created_files.append(p.name)
            except Exception:
                logger.exception("Failed to enumerate split parts for %s", zip_path)
            if not created_files:
                try:
                    for p in sorted(parent_dir.iterdir()):
                        if p.name.startswith(base_name) and p.is_file() and (p.name.endswith(".001") or re.search(r"\.z\d{2}$", p.name)):
                            created_files.append(p.name)
                except Exception:
                    pass
        else:
            if zip_path.exists():
                created_files.append(zip_path.name)
            else:
                try:
                    alt = Path(cwd) / zip_path.name
                    if alt.exists():
                        created_files.append(alt.name)
                except Exception:
                    pass
        if not created_files:
            try:
                size_str = human_size(zip_path.stat().st_size) if zip_path.exists() else "?"
            except Exception:
                size_str = "?"
            msg = f"Created zip: {zip_path.name} ({size_str})"
            await _edit_progress(f"<i>{msg}</i>", keep_button=False)
            await notify_user_from_message(message, msg)
            return
        if len(created_files) == 1:
            try:
                file_path = zip_path if zip_path.exists() else (Path(cwd) / created_files[0])
                size_str = human_size(file_path.stat().st_size) if file_path.exists() else "?"
            except Exception:
                size_str = "?"
            msg = f"Created zip: {created_files[0]} ({size_str})"
            await _edit_progress(f"<i>{msg}</i>", keep_button=False)
            await notify_user_from_message(message, msg)
        else:
            msg = f"Created {len(created_files)} parts: {', '.join(created_files)}"
            await _edit_progress(f"<i>{msg}</i>", keep_button=False)
            await notify_user_from_message(message, msg)
    except Exception:
        logger.exception("zip failed")
        await notify_user_from_message(message, "Zip failed: an internal error occurred while creating the archive.")

async def cmd_set_description(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /set_description <text>")
        return
    global UPLOAD_DESCRIPTION
    UPLOAD_DESCRIPTION = " ".join(args).strip()
    if UPLOAD_DESCRIPTION == "":
        set_upload_description_and_save(None)
        await notify_user_from_message(message, "Description cleared.")
    else:
        set_upload_description_and_save(UPLOAD_DESCRIPTION)
        await notify_user_from_message(message, "Upload description set.")

async def cmd_description(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    if UPLOAD_DESCRIPTION:
        display = UPLOAD_DESCRIPTION if len(UPLOAD_DESCRIPTION) <= 3500 else UPLOAD_DESCRIPTION[:3496] + "..."
        await notify_user_from_message(message, f"Current upload description:\n\n{display}")
    else:
        await notify_user_from_message(message, "No upload description is set.")

async def cmd_no_description(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    set_upload_description_and_save(None)
    await notify_user_from_message(message, "Upload description disabled.")

async def upload_with_retry(upload_client, send_kwargs, max_retries=3):
    """Upload a document with retries on network errors and a global timeout."""
    for attempt in range(max_retries):
        try:
            # Overall timeout of UPLOAD_TIMEOUT seconds per upload part
            return await asyncio.wait_for(
                upload_client.send_document(**send_kwargs),
                timeout=UPLOAD_TIMEOUT
            )
        except (asyncio.TimeoutError, aiohttp.ClientError, ConnectionError, OSError) as e:
            logger.warning(f"Upload attempt {attempt+1} failed: {e}")
            if attempt == max_retries - 1:
                raise
            await asyncio.sleep(UPLOAD_RETRY_DELAY * (attempt + 1))  # exponential backoff
            # Re-validate network connectivity
            if not upload_client.is_connected:
                logger.warning("Client disconnected, attempting to reconnect...")
                await upload_client.reconnect()
    raise Exception("All upload retries failed")

async def cmd_upload(client: Client, message: Message, from_queue: bool = False):
    user = message.from_user
    if not from_queue:
        await enqueue_user_task(user, client, message, cmd_upload)
        return
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return

    initiator_id = None
    try:
        if message.from_user and getattr(message.from_user, "id", None) is not None:
            initiator_id = int(message.from_user.id)
    except Exception:
        initiator_id = None

    async def notify(text: str, reply_message: Optional[Message] = None):
        if initiator_id is not None:
            try:
                await safe_send(initiator_id, text)
                return
            except Exception:
                pass
        try:
            if reply_message:
                await safe_reply(reply_message, text)
            else:
                await safe_reply(message, text)
        except Exception:
            logger.exception("notify fallback failed")

    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify("Usage: /upload * OR /upload 2,4,5")
        return
    spec = " ".join(args).strip()
    root = get_user_root_path(user)
    items = list_user_items(user)
    to_upload: List[Path] = []
    if spec == "*" or spec.lower() == "all":
        to_upload = items
    else:
        chosen = set()
        parts = spec.split(",")
        for p in parts:
            p = p.strip()
            if not p:
                continue
            if "-" in p:
                try:
                    a, b = p.split("-", 1)
                    a_i = int(a); b_i = int(b)
                    for ii in range(a_i, b_i + 1):
                        chosen.add(ii)
                except Exception:
                    pass
            else:
                try:
                    chosen.add(int(p))
                except Exception:
                    pass
        for idx in sorted(chosen):
            item = resolve_user_index_to_path(user, idx)
            if item:
                to_upload.append(item)
    if not to_upload:
        await notify("No items selected for upload.")
        return

    upload_group_id = uuid.uuid4().hex
    cancel_event = asyncio.Event()
    UPLOAD_GROUPS[upload_group_id] = {"cancel_event": cancel_event, "active_task": None}

    chat_id = message.chat.id

    async def _edit_progress_safe(msg: Message, new_text: str, keep_button: bool = True):
        if not msg:
            return
        try:
            reply_markup = _upload_cancel_keyboard(upload_group_id) if keep_button else None
            await edit_with_retry(msg.edit(_scrub_text_for_user(new_text), reply_markup=reply_markup, parse_mode=ParseMode.HTML))
        except Exception:
            pass

    def build_caption_with_description(filename: str) -> str:
        if UPLOAD_DESCRIPTION:
            safe_desc = UPLOAD_DESCRIPTION
            return f"<i>{filename}</i>\n\n<i>{safe_desc}</i>"
        else:
            return f"<i>{filename}</i>"

    try:
        for p in to_upload:
            if cancel_event.is_set():
                break
            try:
                if not ensure_within_user_root(user, p):
                    await notify(f"Skipping {p.name}: not allowed.")
                    continue
                if p.is_dir():
                    await notify(f"'{p.name}' is a folder. Uploading folders is not supported. Please upload individual files.")
                    continue
                if not p.exists() or not p.is_file():
                    await notify(f"File not found: {p.name}")
                    continue

                try:
                    total_size = int(p.stat().st_size)
                except Exception:
                    total_size = None

                start_time = time.time()
                initial_text = build_progress_text(p.name, total_size, 0, 0.0, None)
                progress_markup = _upload_cancel_keyboard(upload_group_id)
                try:
                    progress_msg = await safe_reply(message, initial_text, reply_markup=progress_markup)
                except Exception:
                    progress_msg = await safe_reply(message, "Starting upload...", reply_markup=progress_markup)

                if progress_msg is None:
                    logger.error("Failed to create progress message for upload")
                    class DummyMsg:
                        async def edit(self, text, **kwargs):
                            pass
                    progress_msg = DummyMsg()

                caption_html = build_caption_with_description(p.name)
                group_info = UPLOAD_GROUPS.get(upload_group_id)

                thumb_path = None
                if THUMBNAIL_PATH and THUMBNAIL_PATH.exists():
                    validated_thumb = validate_and_fix_thumbnail(THUMBNAIL_PATH)
                    if validated_thumb and validated_thumb.exists():
                        thumb_path = str(validated_thumb)
                        logger.info(f"Using thumbnail for upload: {thumb_path}")
                    else:
                        logger.warning(f"Thumbnail validation failed, proceeding without thumbnail")
                
                # ---------- UPLOAD CLIENT SELECTION (with new FORCE_USER_UPLOADS) ----------
                if FORCE_USER_UPLOADS:
                    use_bot = False
                elif FORCE_BOT_UPLOADS:
                    use_bot = True
                else:
                    use_bot = (total_size and total_size > LARGE_FILE_THRESHOLD)
                
                # Fallback to bot client if user client is not available and use_bot is False
                if not use_bot and user_client is None:
                    logger.warning("User client not available, falling back to bot client")
                    use_bot = True

                upload_client = bot_client if use_bot else user_client
                client_name = "bot" if use_bot else "user"
                # ------------------------------------------------------------

                try:
                    try:
                        await edit_with_retry(progress_msg.edit(_scrub_text_for_user(f"<i>Uploading via {client_name} API...</i>"), reply_markup=progress_markup, parse_mode=ParseMode.HTML))
                    except Exception:
                        pass

                    progress_handler = OptimizedProgress(
                        p.name, total_size, progress_msg, start_time,
                        update_interval=5.0,
                        reply_markup=progress_markup
                    )

                    send_kwargs = {
                        "chat_id": chat_id,
                        "document": str(p),
                        "caption": _scrub_text_for_user(caption_html),
                        "parse_mode": ParseMode.HTML,
                        "progress": progress_handler,
                    }
                    if thumb_path:
                        send_kwargs["thumb"] = thumb_path

                    # Use robust upload_with_retry
                    task = asyncio.current_task()
                    if group_info:
                        group_info["active_task"] = task

                    sent_doc = await upload_with_retry(upload_client, send_kwargs)
                    
                    total_elapsed = time.time() - start_time
                    try:
                        avg_speed = None
                        try:
                            avg_speed = int((total_size or 0) / max(1.0, total_elapsed))
                            speed_mbps = (avg_speed * 8) / (1024 * 1024)
                            await notify(f"Upload finished: {p.name} ({human_size(total_size)}) at {speed_mbps:.2f} Mbps", reply_message=progress_msg)
                        except Exception:
                            await notify(f"Upload finished: {p.name} ({human_size(total_size)})", reply_message=progress_msg)
                    except Exception:
                        pass
                    
                    final_text = build_progress_text(p.name, total_size, total_size or 0, total_elapsed, 0, speed=avg_speed if 'avg_speed' in locals() else None)
                    if 'avg_speed' in locals() and avg_speed:
                        speed_mbps = (avg_speed * 8) / (1024 * 1024)
                        final_text += f"\n\n<i>Final speed: {speed_mbps:.2f} Mbps</i>"
                    try:
                        await _edit_progress_safe(progress_msg, final_text, keep_button=False)
                    except Exception:
                        pass
                        
                except asyncio.CancelledError:
                    if progress_msg:
                        await _edit_progress_safe(progress_msg, "<i>Upload cancelled.</i>", keep_button=False)
                    break
                except Exception as e:
                    logger.exception(f"{client_name} upload failed")
                    try:
                        await _edit_progress_safe(progress_msg, _scrub_text_for_user(f"<i>Upload failed: {str(e)[:100]}</i>"), keep_button=False)
                    except Exception:
                        pass
                finally:
                    if group_info:
                        group_info["active_task"] = None
            except Exception:
                logger.exception("upload_cmd outer error")
                try:
                    await notify("Unexpected error while uploading a file.")
                except Exception:
                    pass
    finally:
        UPLOAD_GROUPS.pop(upload_group_id, None)

async def handle_incoming_message(client: Client, message: Message, from_queue: bool = False):
    user = message.from_user
    if not from_queue:
        await enqueue_user_task(user, client, message, handle_incoming_message)
        return
    if not is_allowed_user(user):
        await notify_user_from_message(message, "Access denied. You are not authorized to use this bot.")
        return
    msg = message
    if msg is None:
        return
    media_file = None
    filename = None
    mime_type = None
    if msg.document:
        media_file = msg.document
        filename = getattr(msg.document, "file_name", None)
        mime_type = getattr(msg.document, "mime_type", None)
    elif msg.video:
        media_file = msg.video
        filename = getattr(msg.video, "file_name", None)
        mime_type = getattr(msg.video, "mime_type", None)
    elif msg.photo:
        photo = msg.photo
        if isinstance(photo, list):
            photo = photo[-1]
        media_file = photo
        mime_type = "image/jpeg"
        filename = f"photo_{getattr(photo, 'file_unique_id', str(uuid.uuid4()))}.jpg"
    elif msg.sticker:
        media_file = msg.sticker
        filename = getattr(msg.sticker, "file_name", None) or f"sticker_{getattr(msg.sticker, 'file_unique_id', str(uuid.uuid4()))}.webp"
        mime_type = getattr(msg.sticker, "mime_type", None)
    elif msg.voice:
        media_file = msg.voice
        filename = getattr(msg.voice, "file_name", None) or f"voice_{getattr(msg.voice, 'file_unique_id', str(uuid.uuid4()))}.ogg"
        mime_type = getattr(msg.voice, "mime_type", "audio/ogg")
    elif msg.audio:
        media_file = msg.audio
        filename = getattr(msg.audio, "file_name", None) or f"audio_{getattr(msg.audio, 'file_unique_id', str(uuid.uuid4()))}.mp3"
        mime_type = getattr(msg.audio, "mime_type", None)

    text = (msg.text or "") + ("\n" + (msg.caption or "")) if (msg.caption or msg.text) else (msg.text or "")
    matches = URL_REGEX.findall(text)
    extracted = []
    for tup in matches:
        for part in tup:
            if part:
                extracted.append(part)

    if media_file:
        try:
            user_folder = get_user_folder_name(user)
            base = TELELOAD_BASE_DIR.rstrip("/") or "/"
            if base == "/":
                dest_base = Path.cwd()
            else:
                dest_base = Path(base)
            dest_dir = dest_base / user_folder
            dest_dir.mkdir(parents=True, exist_ok=True)
            out_name = filename or f"{getattr(media_file, 'file_unique_id', str(uuid.uuid4()))}"
            out_name = sanitize_filename(out_name)
            out_path = dest_dir / out_name
            if out_path.exists():
                counter = 1
                candidate = out_path
                while candidate.exists():
                    candidate = dest_dir / f"{out_path.stem}_{counter}{out_path.suffix}"
                    counter += 1
                out_path = candidate
            total_size = None
            try:
                total_size = int(getattr(media_file, "file_size", None) or 0) or None
            except Exception:
                total_size = None
            start_time = time.time()
            initial_text = build_progress_text(out_path.name, total_size, 0, 0.0, None)
            try:
                progress_msg = await safe_reply(message, initial_text)
            except Exception:
                progress_msg = await safe_reply(message, "Starting download...")
            if user_client is None:
                try:
                    await edit_with_retry(progress_msg.edit(_scrub_text_for_user("<i>Internal error: Transfer client not initialized.</i>")))
                except Exception:
                    pass
            else:
                try:
                    main_loop = asyncio.get_running_loop()
                except RuntimeError:
                    main_loop = None

                def pyro_progress(current, total):
                    if main_loop is None or main_loop.is_closed():
                        return
                    asyncio.run_coroutine_threadsafe(_pyro_progress_async(current, total), main_loop)

                async def _pyro_progress_async(current, total):
                    nonlocal start_time, total_size, progress_msg, out_path
                    try:
                        now = time.time()
                        if not hasattr(_pyro_progress_async, "_last_update"):
                            _pyro_progress_async._last_update = 0.0
                        if now - _pyro_progress_async._last_update < 6.0:
                            return
                        _pyro_progress_async._last_update = now

                        elapsed = now - start_time
                        total_b = total if total and total > 0 else total_size
                        speed = None
                        try:
                            speed = int(current / max(1.0, elapsed))
                        except Exception:
                            speed = None
                        eta = None
                        if total_b and speed and speed > 0:
                            remaining = max(0, total_b - current)
                            eta = remaining / speed
                        textp = build_progress_text(out_path.name, total_b, current, elapsed, eta, speed=speed)
                        if speed is not None:
                            textp += f"\n\n<i>Speed: {human_size(speed)}/s</i>"
                        await edit_with_retry(progress_msg.edit(_scrub_text_for_user(textp)))
                    except Exception:
                        logger.exception("pyro progress callback failed")

                user_msg_for_download = None
                try:
                    chat_id = message.chat.id
                    msg_id = message.message_id
                    try:
                        user_msg_for_download = await user_client.get_messages(chat_id, msg_id)
                    except Exception:
                        user_msg_for_download = None
                except Exception:
                    user_msg_for_download = None

                try:
                    if user_msg_for_download:
                        await user_client.download_media(user_msg_for_download, file_name=str(out_path), progress=pyro_progress)
                    else:
                        await bot_client.download_media(message, file_name=str(out_path), progress=pyro_progress)
                    final_bytes = None
                    try:
                        final_bytes = int(out_path.stat().st_size) if out_path.exists() else None
                    except Exception:
                        final_bytes = None
                    total_elapsed = time.time() - start_time
                    final_text = build_progress_text(out_path.name, final_bytes or total_size, final_bytes, total_elapsed, 0, speed=int((final_bytes or total_size or 0)/max(1.0, total_elapsed)) if total_elapsed > 0 else None)
                    try:
                        avg_speed = None
                        try:
                            avg_speed = int((final_bytes or total_size or 0) / max(1.0, total_elapsed))
                        except Exception:
                            avg_speed = None
                        if avg_speed is not None:
                            final_text += f"\n\n<i>Speed: {human_size(avg_speed)}/s</i>"
                        await edit_with_retry(progress_msg.edit(_scrub_text_for_user(final_text)))
                    except Exception:
                        pass
                    processed_path = await process_path_with_suffix_and_signing_async(out_path)
                    if processed_path and AUTOMATOR_ENABLED:
                        asyncio.create_task(
                            auto_compress_and_upload(
                                user=user,
                                original_path=processed_path,
                                chat_id=message.chat.id,
                                initiator_message=message,
                                cancel_key=None,
                                stop_event=None
                            )
                        )
                except Exception:
                    logger.exception("Download (user_client or bot_client) failed")
                    try:
                        await edit_with_retry(progress_msg.edit(_scrub_text_for_user("<i>Download failed via transfer client.</i>")))
                    except Exception:
                        pass

            try:
                final_bytes = None
                try:
                    final_bytes = int(out_path.stat().st_size) if out_path.exists() else None
                except Exception:
                    final_bytes = None
                if out_path.suffix.lower() == ".torrent":
                    try:
                        aria_msg = await safe_reply(message, "<i>Starting local processing for the provided torrent file...</i>")
                    except Exception:
                        aria_msg = progress_msg
                    success_count, results = await aria2_download_items([str(out_path)], user, aria_msg)
                    lines = [f"Processing summary: {success_count}/1 succeeded"]
                    for link, ok, info in results:
                        status = "OK" if ok else "FAILED"
                        lines.append(f"- {status}: {link}")
                    try:
                        await edit_with_retry(aria_msg.edit(_scrub_text_for_user("\n".join(lines))))
                    except Exception:
                        pass
                    await notify_user_from_message(message, f"Torrent processing finished: {success_count}/1 succeeded\n" + "\n".join(lines))
                else:
                    try:
                        size_text = human_size(final_bytes) if final_bytes is not None else "?"
                        await notify_user_from_message(message, f"Saved media to your folder ({size_text})")
                    except Exception:
                        pass
            except Exception:
                logger.exception("Post-download processing failed")
        except Exception:
            logger.exception("Failed to download media via transfer client/fallback")
            await notify_user_from_message(message, "Unable to access the media. Ensure the transfer client account can access the chat and try again.")
    if extracted:
        seen = set()
        links = []
        for l in extracted:
            s = l.strip()
            if s and s not in seen:
                seen.add(s)
                links.append(s)
        aria2_targets = []
        other_links = []
        for l in links:
            if is_magnet(l) or is_torrent_url(l):
                aria2_targets.append(l)
            else:
                other_links.append(l)
        bot_msg = await safe_reply(message, f"Processing links. {len(other_links)} queued, {len(aria2_targets)} local items.")
        jd_result_text = ""

        def find_gofile_password_for_url(msg_text: str, url: str) -> Optional[str]:
            try:
                idx = msg_text.find(url)
                if idx == -1:
                    return None
                rem = msg_text[idx+len(url):].strip()
                if not rem:
                    return None
                first = rem.split()[0]
                if first.startswith("http"):
                    return None
                if URL_REGEX.search(first):
                    return None
                return first
            except Exception:
                return None

        gofile_links = []
        other_links_remaining = []
        for l in other_links:
            m = re.match(r"https?://(?:www\.)?gofile\.io/d/([A-Za-z0-9_-]+)", l.strip())
            if m:
                pwd = find_gofile_password_for_url(text or "", l)
                gofile_links.append((l, pwd))
            else:
                other_links_remaining.append(l)

        # ---------- If automator enabled, use the queue ----------
        if AUTOMATOR_ENABLED and (gofile_links or other_links_remaining or aria2_targets):
            job = {
                "user": user,
                "message": message,
                "gofile_links": gofile_links,
                "other_links": other_links_remaining,
                "aria2_targets": aria2_targets,
                "text": text or "",
            }
            queue_position = PROCESSING_QUEUE.qsize() + 1
            await notify_user_from_message(message, f"⚙️ Automator mode: your request has been queued (position {queue_position}). Processing will start when capacity is available.")
            await PROCESSING_QUEUE.put(job)
            return   # Do not process further in this function
        # ---------- Non-automator mode (original behaviour) ----------
        if other_links_remaining:
            success, result = add_links_to_device(other_links_remaining, user)
            if success:
                mappings = result if isinstance(result, list) else []
                if not mappings:
                    jd_result_text = f"Added {len(other_links_remaining)} link(s) to your queue."
                else:
                    try:
                        jd_result_text = "Added links to your queue:\n" + "\n".join(
                            (f"- {m.get('display_name')}" for m in mappings)
                        )
                    except Exception:
                        jd_result_text = f"Added {len(mappings)} link(s) to your queue."
            else:
                jd_result_text = f"Failed to add some links to your queue."
            try:
                await edit_with_retry(bot_msg.edit(_scrub_text_for_user(f"<i>{jd_result_text}</i>")))
            except Exception:
                pass
            if success:
                pkg_ids = []
                mappings = result if isinstance(result, list) else []
                for m in mappings:
                    if m.get("package_uuid"):
                        pkg_ids.append(str(m.get("package_uuid")))
                    elif m.get("package_name"):
                        pkg_ids.append(str(m.get("package_name")))
                if not pkg_ids:
                    pkg_ids = [f"Telegram_{get_user_folder_name(user)}"]
                try:
                    display_names = [m.get("display_name") for m in mappings] if mappings else []
                    if not display_names:
                        display_names = [f"Telegram_{get_user_folder_name(user)}"]
                    try:
                        status_msg = await safe_reply(message, "<i>Starting transfers...</i>")
                    except Exception:
                        status_msg = bot_msg
                    jd = None
                    try:
                        jd = connect_jd()
                        device = get_device_direct(jd, JD_DEVICE_NAME)
                        title_prefix = "Transfers"
                        if display_names:
                            title_prefix = ", ".join(display_names[:3]) if len(display_names) <= 3 else (", ".join(display_names[:3]) + "...")
                        cancel_key = uuid.uuid4().hex
                        try:
                            await edit_with_retry(status_msg.edit(_scrub_text_for_user("<i>Starting transfers...</i>"), reply_markup=_download_cancel_keyboard(cancel_key), parse_mode=ParseMode.HTML))
                        except Exception:
                            pass
                        try:
                            DOWNLOAD_TASKS[cancel_key] = {"jd": jd, "device": device, "package_ids": pkg_ids, "user_id": getattr(user, "id", None), "cancelled": False, "type": "jd_monitor"}
                        except Exception:
                            pass
                        await monitor_jd_packages(jd, device, pkg_ids, status_msg, title_prefix=title_prefix, poll_interval=2.0, timeout=60*60, cancel_key=cancel_key, user=user)
                    except Exception:
                        logger.exception("Failed to start monitoring")
                        try:
                            await edit_with_retry(status_msg.edit(_scrub_text_for_user("<i>Failed to monitor transfers.</i>")))
                        except Exception:
                            pass
                    finally:
                        if jd:
                            try:
                                jd.disconnect()
                            except Exception:
                                pass
                except Exception:
                    logger.exception("Error while preparing monitoring")

        if gofile_links:
            for idx, (link, pwd) in enumerate(gofile_links, start=1):
                try:
                    status_msg = await safe_reply(message, f"<i>[{idx}/{len(gofile_links)}] Starting GoFile download...</i>", parse_mode=ParseMode.HTML)
                except Exception:
                    status_msg = bot_msg
                loop = asyncio.get_running_loop()
                cancel_key = uuid.uuid4().hex
                stop_evt = asyncio.Event()
                DOWNLOAD_TASKS[cancel_key] = {"stop_event": stop_evt, "user_id": getattr(user, "id", None), "cancelled": False, "type": "gofile", "last_progress": 0.0}
                def thread_progress_cb(text: str):
                    now = time.time()
                    entry = DOWNLOAD_TASKS.get(cancel_key)
                    if entry:
                        last = entry.get("last_progress", 0.0)
                        if now - last < 4.0:
                            return
                        entry["last_progress"] = now
                    async def _edit():
                        try:
                            await edit_with_retry(status_msg.edit(_scrub_text_for_user(text), reply_markup=_download_cancel_keyboard(cancel_key), parse_mode=ParseMode.HTML))
                        except Exception:
                            pass
                    try:
                        loop.call_soon_threadsafe(asyncio.create_task, _edit())
                    except Exception:
                        pass
                async def _run_gofile_download_blocking_async(url_b, password_b, user_b, progress_cb, stop_evt_b, cancel_key_b):
                    try:
                        user_dir = get_user_root_path(user_b)
                        os.environ["GF_DOWNLOAD_DIR"] = str(user_dir)
                        mgr = Manager(url_b, password_b, progress_callback=progress_cb, stop_event=stop_evt_b)
                        try:
                            DOWNLOAD_TASKS[cancel_key_b]["manager"] = mgr
                        except Exception:
                            pass
                        try:
                            mgr._token = getenv("GF_TOKEN")
                        except Exception:
                            pass
                        await asyncio.wait_for(mgr._parse_url_or_file(), timeout=3600)
                        return True, None
                    except asyncio.TimeoutError:
                        return False, "timeout"
                    except Exception as e:
                        logger.exception("gofile download failed for %s", url_b)
                        return False, str(e)
                try:
                    result = await asyncio.wait_for(_run_gofile_download_blocking_async(link, pwd, user, thread_progress_cb, stop_evt, cancel_key), timeout=3700)
                    ok, info = result if isinstance(result, tuple) else (False, "unknown")
                    try:
                        DOWNLOAD_TASKS.pop(cancel_key, None)
                    except Exception:
                        pass
                    if ok:
                        try:
                            await edit_with_retry(status_msg.edit(_scrub_text_for_user(f"<i>[{idx}/{len(gofile_links)}] GoFile download finished.</i>"), parse_mode=ParseMode.HTML))
                        except Exception:
                            pass
                        try:
                            await notify_user_from_message(message, f"GoFile download finished for {link}")
                        except Exception:
                            pass
                    else:
                        try:
                            await edit_with_retry(status_msg.edit(_scrub_text_for_user(f"<i>[{idx}/{len(gofile_links)}] GoFile download failed: {info}</i>"), parse_mode=ParseMode.HTML))
                        except Exception:
                            pass
                        try:
                            await notify_user_from_message(message, f"GoFile download failed for {link}")
                        except Exception:
                            pass
                except asyncio.TimeoutError:
                    logger.error("GoFile download timeout for %s", link)
                    try:
                        await edit_with_retry(status_msg.edit(_scrub_text_for_user(f"<i>[{idx}/{len(gofile_links)}] GoFile download timed out.</i>"), parse_mode=ParseMode.HTML))
                    except Exception:
                        pass
                    try:
                        DOWNLOAD_TASKS.pop(cancel_key, None)
                    except Exception:
                        pass
                except Exception:
                    logger.exception("Failed to execute gofile download")
                    try:
                        await edit_with_retry(status_msg.edit(_scrub_text_for_user(f"<i>[{idx}/{len(gofile_links)}] GoFile download failed to start.</i>"), parse_mode=ParseMode.HTML))
                    except Exception:
                        pass

        if aria2_targets:
            aria2_found = True
            progress_msg = await safe_reply(message, f"Starting local downloads for {len(aria2_targets)} item(s)...")
            try:
                success_count, results = await aria2_download_items(aria2_targets, user, progress_msg)
                lines = [f"Processing summary: {success_count}/{len(aria2_targets)} succeeded"]
                for link, ok, info in results:
                    status = "OK" if ok else "FAILED"
                    if info == "file_exists":
                        lines.append(f"- {status}: {link}\n  A file/folder already exists. Remove or rename it to download this item.")
                    else:
                        lines.append(f"- {status}: {link}")
                summary = "\n".join(lines)
                try:
                    await edit_with_retry(progress_msg.edit(_scrub_text_for_user(summary)))
                except Exception:
                    pass
            except Exception:
                logger.exception("local download handling failed")
                try:
                    await edit_with_retry(progress_msg.edit(_scrub_text_for_user("Local processing failed.")))
                except Exception:
                    pass
    if not media_file and not extracted:
        await notify_user_from_message(message, "No links or supported media detected in your message.")

async def cmd_cd(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /cd <num> (use the index from /ls).")
        return
    try:
        idx = int(args[0])
    except Exception:
        await notify_user_from_message(message, "Argument must be a number (the directory index shown by /ls).")
        return
    target = resolve_user_index_to_path(user, idx)
    if not target:
        await notify_user_from_message(message, "Invalid index.")
        return
    if not target.is_dir():
        await notify_user_from_message(message, "Target is not a directory.")
        return
    if not ensure_within_user_root(user, target):
        await notify_user_from_message(message, "Operation not allowed.")
        return
    root = get_user_root_path(user)
    try:
        rel = target.resolve().relative_to(root.resolve())
    except Exception:
        await notify_user_from_message(message, "Failed to change directory (internal error).")
        return
    CURRENT_DIRS[user.id] = Path(rel)
    visible = "/" if str(rel) == "." else "/" + str(rel).replace("\\", "/").lstrip("/")
    await notify_user_from_message(message, f"Changed directory to: {visible}")

async def cmd_back(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    root = get_user_root_path(user)
    cur_rel = CURRENT_DIRS.get(user.id, Path("."))
    try:
        if cur_rel == Path(".") or str(cur_rel) == ".":
            await notify_user_from_message(message, "Already at root directory (/).")
            return
        new_rel = (cur_rel).parent
        if str(new_rel) == "." or new_rel == Path("."):
            CURRENT_DIRS[user.id] = Path(".")
            await notify_user_from_message(message, "Moved to root (/).")
            return
        CURRENT_DIRS[user.id] = new_rel
        visible = "/" + str(new_rel).replace("\\", "/").lstrip("/")
        await notify_user_from_message(message, f"Moved to: {visible}")
    except Exception:
        CURRENT_DIRS[user.id] = Path(".")
        await notify_user_from_message(message, "Moved to root (/).")

async def cmd_mkdir(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /mkdir <folder_name>")
        return
    raw_name = " ".join(args).strip()
    if not raw_name:
        await notify_user_from_message(message, "Folder name cannot be empty.")
        return
    if raw_name == "*" or raw_name in (".", ".."):
        await notify_user_from_message(message, "Invalid folder name.")
        return
    forbidden = set('<>:"/\\|?*\0')
    if any((c in forbidden) for c in raw_name):
        await notify_user_from_message(message, "Folder name contains characters not allowed on Windows. Avoid <> : \" / \\ | ? * and control characters.")
        return
    if all(ch == "." for ch in raw_name) or raw_name.strip() == "":
        await notify_user_from_message(message, "Invalid folder name.")
        return
    safe_name = sanitize_filename(raw_name)
    if safe_name != raw_name:
        await notify_user_from_message(message, "Folder name contains characters that are not allowed on Windows; please choose a different name.")
        return
    root = get_user_root_path(user)
    rel = CURRENT_DIRS.get(user.id, Path("."))
    try:
        current = (root / rel).resolve()
    except Exception:
        current = root
    try:
        if not str(current).startswith(str(root)):
            current = root
            CURRENT_DIRS[user.id] = Path(".")
    except Exception:
        current = root
        CURRENT_DIRS[user.id] = Path(".")
    target = (current / safe_name).resolve()
    if not ensure_within_user_root(user, target):
        await notify_user_from_message(message, "Operation would escape your user folder; aborted.")
        return
    if safe_name == "*":
        await notify_user_from_message(message, "The name '*' is not allowed.")
        return
    if target.exists():
        await notify_user_from_message(message, "A file or folder with that name already exists.")
        return
    try:
        target.mkdir(parents=False, exist_ok=False)
        await notify_user_from_message(message, f"Created folder: {safe_name}")
    except FileExistsError:
        await notify_user_from_message(message, "A file or folder with that name already exists.")
    except PermissionError:
        await notify_user_from_message(message, "Permission denied: cannot create folder here.")
    except Exception:
        logger.exception("mkdir failed")
        await notify_user_from_message(message, "Failed to create folder.")

async def cmd_setpass(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /setpass <password>")
        return
    pwd = " ".join(args).strip()
    if not pwd:
        await notify_user_from_message(message, "Password cannot be empty.")
        return
    PASSWORDS[user.id] = pwd
    await notify_user_from_message(message, "Password saved for your /zip operations. (Stored in memory; will be lost if the bot restarts.)")

async def cmd_nopass(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    if user.id in PASSWORDS:
        PASSWORDS.pop(user.id, None)
        await notify_user_from_message(message, "Password removed. Future /zip commands will create unencrypted zip archives.")
    else:
        await notify_user_from_message(message, "No password was set for you.")

async def cmd_pass_status(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    pwd = PASSWORDS.get(user.id)
    if pwd:
        await notify_user_from_message(message, f"You have a password set for zips: {pwd}\n(Stored in memory; will be lost if the bot restarts.)")
    else:
        await notify_user_from_message(message, "No password set for your /zip operations.")

async def cmd_unzip(client: Client, message: Message, from_queue: bool = False):
    user = message.from_user
    if not from_queue:
        await enqueue_user_task(user, client, message, cmd_unzip)
        return
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /unzip <num|a,b,range|*> [password]\nExamples:\n/unzip 5,6,8\n/unzip 5 mypassword")
        return
    sel_token = args[0].strip()
    password = None
    if len(args) >= 2:
        password = " ".join(args[1:]).strip()
        if password == "":
            password = None
    items = list_user_items(user)
    if not items:
        await notify_user_from_message(message, "No files or folders in current directory.")
        return
    def parse_selection(token: str, available_items: List[Path]) -> List[Path]:
        t = token.strip()
        if t == "*" or t.lower() == "all":
            return available_items[:]
        chosen = set()
        parts_ = [p.strip() for p in t.split(",") if p.strip()]
        for p in parts_:
            if "-" in p:
                try:
                    a, b = p.split("-", 1)
                    a_i = int(a); b_i = int(b)
                    low = min(a_i, b_i); high = max(a_i, b_i)
                    for ii in range(low, high + 1):
                        chosen.add(ii)
                except Exception:
                    continue
            else:
                try:
                    ii = int(p); chosen.add(ii)
                except Exception:
                    continue
        result = []
        for idx in sorted(chosen):
            if 1 <= idx <= len(available_items):
                result.append(available_items[idx - 1])
        return result
    sources = parse_selection(sel_token, items)
    if not sources:
        await notify_user_from_message(message, "No valid items selected.")
        return
    try:
        await notify_user_from_message(message, f"Starting extraction of {len(sources)} archive(s)...")
    except Exception:
        pass
    seven_cmd = None
    try:
        if SEVENZ_PATH:
            sp = Path(SEVENZ_PATH)
            if sp.exists() and sp.is_file():
                seven_cmd = str(sp)
            else:
                found = shutil.which(SEVENZ_PATH)
                if found:
                    seven_cmd = found
                else:
                    found2 = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
                    if found2:
                        seven_cmd = found2
        else:
            seven_cmd = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
    except Exception:
        seven_cmd = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
    if not seven_cmd:
        await notify_user_from_message(message, "7z executable not found. Set SEVENZ_PATH in .env or ensure '7z' is in PATH.")
        return

    root = get_user_root_path(user)
    cur_rel = CURRENT_DIRS.get(user.id, Path("."))
    try:
        current = (root / cur_rel).resolve()
    except Exception:
        current = root

    responses = []
    for src in sources:
        try:
            if not ensure_within_user_root(user, src):
                responses.append(f"{src.name}: skipped (not allowed).")
                continue
            if not src.exists() or not src.is_file():
                responses.append(f"{src.name}: skipped (not a file).")
                continue
            name_for_folder = src.name
            if re.search(r"\.(?:\d{1,3})$", src.name) or re.search(r"\.part\d{1,3}$", src.name, flags=re.IGNORECASE) or re.search(r"\.zip\.\d{3}$", src.name, flags=re.IGNORECASE):
                parts = src.name.split(".")
                if len(parts) > 1:
                    name_for_folder = ".".join(parts[:-1])
                else:
                    name_for_folder = src.stem

            out_dir_name = sanitize_filename(f"{name_for_folder}_extracted")
            out_dir = (current / out_dir_name).resolve()

            if not ensure_within_user_root(user, out_dir):
                responses.append(f"{src.name}: skipped (would escape user root).")
                continue
            out_dir.mkdir(parents=True, exist_ok=True)

            cmd = [seven_cmd, "x", "-y", f"-o{str(out_dir)}", str(src), "-bsp1"]
            if password:
                cmd.insert(-1, f"-p{password}")
            progress_msg = None
            try:
                progress_msg = await safe_reply(
                    message,
                    "<i>Preparing extraction...</i>",
                    reply_markup=_unzip_cancel_keyboard(),
                    parse_mode=ParseMode.HTML,
                )
            except Exception:
                progress_msg = None

            async def _edit_unzip_progress(txt: str, keep_button: bool = True):
                if not progress_msg:
                    return
                reply_markup = _unzip_cancel_keyboard() if keep_button else None
                try:
                    await edit_with_retry(progress_msg.edit_text(
                        _scrub_text_for_user(txt),
                        reply_markup=reply_markup,
                        parse_mode=ParseMode.HTML,
                    ))
                except Exception:
                    pass

            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                    cwd=str(out_dir),
                )
            except Exception:
                responses.append(f"{src.name}: extraction failed to start.")
                continue

            message_id = getattr(progress_msg, "message_id", None) or getattr(progress_msg, "id", None)
            if message_id is not None:
                _UNZIP_TASKS[message_id] = {
                    "process": proc,
                    "user_id": getattr(user, "id", None),
                    "cancelled": False,
                }

            buffer = b""
            pct_value = None
            last_emit = time.time()
            last_pct = -1.0
            task_entry = None
            try:
                assert proc.stdout is not None
                while True:
                    chunk = await proc.stdout.read(64)
                    if not chunk:
                        break
                    buffer += chunk
                    while True:
                        if b"\r" in buffer:
                            line, buffer = buffer.split(b"\r", 1)
                        elif b"\n" in buffer:
                            line, buffer = buffer.split(b"\n", 1)
                        else:
                            break
                        decoded = line.decode(errors="ignore").strip()
                        match = _ZIP_PERCENT_RE.search(decoded) or _ZIP_SIMPLE_PERCENT_RE.search(decoded)
                        if match:
                            try:
                                new_pct = float(match.group(1))
                            except Exception:
                                new_pct = None
                            if new_pct is not None:
                                pct_value = max(0.0, min(100.0, new_pct))
                        now = time.time()
                        interval_due = (now - last_emit) >= UNZIP_PROGRESS_UPDATE_INTERVAL
                        if pct_value is not None and (pct_value != last_pct and (abs(pct_value - last_pct) >= 20 or interval_due)):
                            await _edit_unzip_progress(_unzip_progress_bar_text(src.name, pct_value))
                            last_pct = pct_value
                            last_emit = now
                        elif interval_due:
                            await _edit_unzip_progress(_unzip_progress_bar_text(src.name, pct_value))
                            last_emit = now
                    if message_id is not None and _UNZIP_TASKS.get(message_id, {}).get("cancelled"):
                        break
            except Exception:
                logger.exception("Failed to read 7z output")
            rc = await proc.wait()
            if message_id is not None:
                task_entry = _UNZIP_TASKS.pop(message_id, None)
            if task_entry and task_entry.get("cancelled"):
                responses.append(f"{src.name}: cancelled.")
                continue
            if rc != 0:
                responses.append(f"{src.name}: extraction failed.")
                continue
            await _edit_unzip_progress(f"<i>{src.name} extraction finished.</i>", keep_button=False)
            responses.append(f"{src.name}: extraction finished successfully.")
        except Exception:
            logger.exception("unzip failed for %s", src)
            responses.append(f"{src.name}: unexpected error.")
    if responses:
        out_text = "\n".join(responses)
        MAX = 3500
        if len(out_text) <= MAX:
            await notify_user_from_message(message, out_text)
        else:
            lines = out_text.splitlines()
            buf = []
            for ln in lines:
                if sum(len(x) for x in buf) + len(ln) + len(buf) > MAX:
                    await notify_user_from_message(message, "\n".join(buf))
                    buf = [ln]
                else:
                    buf.append(ln)
            if buf:
                await notify_user_from_message(message, "\n".join(buf))
    else:
        await notify_user_from_message(message, "No output from unzip operation.")

async def cmd_set_thumb(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    reply = message.reply_to_message
    photo_msg = None
    if reply and (reply.photo or reply.document):
        photo_msg = reply
    elif message.photo or message.document:
        photo_msg = message
    else:
        await notify_user_from_message(message, "Usage: reply to a photo with /set_thumb or send a photo with the command. This command requires a photo.")
        return
    file_id = None
    try:
        if photo_msg.photo:
            file_id = photo_msg.photo[-1].file_id if isinstance(photo_msg.photo, list) else photo_msg.photo.file_id
        elif photo_msg.document:
            mim = getattr(photo_msg.document, "mime_type", "") or ""
            if mim.startswith("image/"):
                file_id = photo_msg.document.file_id
            else:
                await notify_user_from_message(message, "The replied document is not an image. Please reply to an image/photo.")
                return
        else:
            await notify_user_from_message(message, "No photo found in the replied message.")
            return
    except Exception:
        await notify_user_from_message(message, "Failed to detect photo in the replied message.")
        return
    if not file_id:
        await notify_user_from_message(message, "Failed to determine the file to use as thumbnail.")
        return
    try:
        file = await bot_client.download_media(file_id, file_name=str(Path.cwd() / THUMBNAIL_FILENAME))
        dest_path = Path(file).resolve()
        
        validated_thumb = validate_and_fix_thumbnail(dest_path)
        if validated_thumb:
            global THUMBNAIL_PATH
            THUMBNAIL_PATH = validated_thumb
            await notify_user_from_message(message, "Thumbnail saved, validated, and will be used for future uploads.")
            logger.info("Thumbnail set by owner %s and validated", user.id)
        else:
            await notify_user_from_message(message, "Failed to validate thumbnail. Please ensure it's a valid image.")
    except Exception:
        logger.exception("Failed to save thumbnail")
        await notify_user_from_message(message, "Failed to save thumbnail.")

async def cmd_thumb(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    global THUMBNAIL_PATH
    if THUMBNAIL_PATH and THUMBNAIL_PATH.exists():
        info_parts = [f"Path: {THUMBNAIL_PATH.name}"]
        if PIL_AVAILABLE:
            try:
                with Image.open(THUMBNAIL_PATH) as img:
                    dimensions = f"{img.width}x{img.height}"
                    mode = img.mode
                    info_parts.append(f"Dimensions: {dimensions}")
                    info_parts.append(f"Mode: {mode}")
                    size = THUMBNAIL_PATH.stat().st_size
                    info_parts.append(f"Size: {human_size(size)}")
            except Exception as e:
                info_parts.append(f"Info: Could not read image metadata ({e})")
        
        info = "\n".join(info_parts)
        await notify_user_from_message(message, f"Current configured thumbnail:\n{info}")
        
        try:
            await throttled_send(bot_client.send_photo(message.chat.id, photo=str(THUMBNAIL_PATH), caption="Current configured thumbnail"))
        except Exception:
            try:
                await throttled_send(bot_client.send_document(message.chat.id, document=str(THUMBNAIL_PATH), caption="Current configured thumbnail (sent as file)"))
            except Exception:
                logger.exception("Failed to send thumbnail")
                await notify_user_from_message(message, "Thumbnail is configured but failed to send.")
    else:
        await notify_user_from_message(message, "No thumbnail is currently configured.")

async def cmd_del_thumb(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    global THUMBNAIL_PATH
    if not THUMBNAIL_PATH or not THUMBNAIL_PATH.exists():
        THUMBNAIL_PATH = None
        await notify_user_from_message(message, "No thumbnail was configured.")
        return
    try:
        THUMBNAIL_PATH.unlink(missing_ok=True)
    except Exception:
        logger.exception("Failed to delete thumbnail file")
        await notify_user_from_message(message, "Failed to delete thumbnail.")
        return
    THUMBNAIL_PATH = None
    await notify_user_from_message(message, "Thumbnail deleted.")

async def cmd_adduser(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if len(args) < 2:
        await notify_user_from_message(message, "Usage: /adduser -d <days> <@username|userid>  OR  /adduser -m <minutes> <@username|userid>")
        return
    flag = args[0]
    if flag not in ("-d", "-m"):
        await notify_user_from_message(message, "Invalid flag. Use -d for days or -m for minutes.")
        return
    try:
        num = int(args[1])
        if num <= 0:
            raise ValueError()
    except Exception:
        await notify_user_from_message(message, "Invalid duration. Provide a positive integer after -d/-m.")
        return
    if len(args) < 3:
        await notify_user_from_message(message, "Provide the target user as @username or numeric user id.")
        return
    target_token = args[2]
    key = _normalize_user_key(target_token)
    if not key:
        await notify_user_from_message(message, "Invalid user token.")
        return
    now = datetime.utcnow()
    if flag == "-d":
        expires = now + timedelta(days=num)
    else:
        expires = now + timedelta(minutes=num)
    ADDED_USERS[key] = {"id": int(key) if key.isdigit() else None, "username": None if key.isdigit() else key, "expires_at": expires.timestamp()}
    add_temporary_user_and_save(key, ADDED_USERS[key])
    pretty = key
    await notify_user_from_message(message, f"Added user {pretty} until {expires.isoformat()} UTC.")

async def cmd_lsusers(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    now_ts = datetime.utcnow().timestamp()
    if args:
        key = _normalize_user_key(args[0])
        if not key:
            await notify_user_from_message(message, "Invalid user token.")
            return
        info = ADDED_USERS.get(key)
        if not info:
            await notify_user_from_message(message, "User not found in temporary list.")
            return
        if info.get("expires_at", 0) <= now_ts:
            ADDED_USERS.pop(key, None)
            save_persistent_state()
            await notify_user_from_message(message, "User entry expired and has been removed.")
            return
        rem = int(info["expires_at"] - now_ts)
        hrs, remr = divmod(rem, 3600)
        mins, secs = divmod(remr, 60)
        human = f"{hrs}h{mins}m{secs}s" if hrs else (f"{mins}m{secs}s" if mins else f"{secs}s")
        await notify_user_from_message(message, f"{key}: remaining {human}")
        return
    lines = []
    for k, info in list(ADDED_USERS.items()):
        if info.get("expires_at", 0) <= now_ts:
            ADDED_USERS.pop(k, None)
            continue
        rem = int(info["expires_at"] - now_ts)
        hrs, remr = divmod(rem, 3600)
        mins, secs = divmod(remr, 60)
        human = f"{hrs}h{mins}m{secs}s" if hrs else (f"{mins}m{secs}s" if mins else f"{secs}s")
        lines.append(f"{k}: {human}")
    if not lines:
        await notify_user_from_message(message, "No temporary users are currently added.")
    else:
        await notify_user_from_message(message, "Temporary users:\n" + "\n".join(lines))

async def cmd_deluser(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /deluser <@username|userid>")
        return
    key = _normalize_user_key(args[0])
    if not key:
        await notify_user_from_message(message, "Invalid user token.")
        return
    if key in ADDED_USERS:
        ADDED_USERS.pop(key, None)
        remove_temporary_user_and_save(key)
        await notify_user_from_message(message, f"Removed temporary user {key}.")
    else:
        await notify_user_from_message(message, "User not found in temporary list.")

async def cmd_list_suffix_filter(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    if not SUFFIX_FILTERS:
        await notify_user_from_message(message, "No suffix filters configured.")
    else:
        lines = ["Configured suffixes:"]
        for s in SUFFIX_FILTERS:
            lines.append(f"- `{s}`")
        await notify_user_from_message(message, "\n".join(lines))

async def cmd_add_suffix_filter(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /add_suffix_filter <suffix>")
        return
    suffix = " ".join(args).strip()
    if not suffix:
        await notify_user_from_message(message, "Suffix cannot be empty.")
        return
    if suffix in SUFFIX_FILTERS:
        await notify_user_from_message(message, f"Suffix '{suffix}' already exists.")
        return
    SUFFIX_FILTERS.append(suffix)
    save_persistent_state()
    await notify_user_from_message(message, f"Added suffix filter: '{suffix}'")

async def cmd_delete_suffix_filter(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /delete_suffix_filter <suffix>")
        return
    suffix = " ".join(args).strip()
    if suffix not in SUFFIX_FILTERS:
        await notify_user_from_message(message, f"Suffix '{suffix}' not found.")
        return
    SUFFIX_FILTERS.remove(suffix)
    save_persistent_state()
    await notify_user_from_message(message, f"Removed suffix filter: '{suffix}'")

async def cmd_enable_suffix_filter(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    global SUFFIX_FILTER_ENABLED
    if not SUFFIX_FILTERS:
        await notify_user_from_message(message, "No suffix filters configured. Add some first.")
        return
    SUFFIX_FILTER_ENABLED = True
    save_persistent_state()
    await notify_user_from_message(message, "Suffix filter enabled.")

async def cmd_disable_suffix_filter(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    global SUFFIX_FILTER_ENABLED
    SUFFIX_FILTER_ENABLED = False
    save_persistent_state()
    await notify_user_from_message(message, "Suffix filter disabled.")

async def cmd_suffix_filter_status(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    status = "enabled" if SUFFIX_FILTER_ENABLED else "disabled"
    if SUFFIX_FILTERS:
        filters = ", ".join(f"`{s}`" for s in SUFFIX_FILTERS)
        await notify_user_from_message(message, f"Suffix filter is {status}.\nConfigured suffixes: {filters}")
    else:
        await notify_user_from_message(message, f"Suffix filter is {status}.\nNo suffixes configured.")

async def cmd_rename_suffix_folders(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    
    root = get_user_root_path(user)
    rel = CURRENT_DIRS.get(user.id, Path("."))
    try:
        current = (root / rel).resolve()
    except Exception:
        current = root
    
    if not current.exists():
        await notify_user_from_message(message, "Current directory does not exist.")
        return
    
    if not SUFFIX_FILTER_ENABLED:
        await notify_user_from_message(message, "Suffix filter is disabled. Enable it with /enable_suffix_filter first.")
        return
    
    if not SUFFIX_FILTERS:
        await notify_user_from_message(message, "No suffix filters configured. Add some with /add_suffix_filter.")
        return
    
    renamed = []
    failed = []
    for item in current.iterdir():
        if item.is_dir():
            original = item.name
            filtered_path, was_modified = await apply_suffix_filter_to_path(item)
            if filtered_path and was_modified:
                renamed.append(f"{original} -> {filtered_path.name}")
            else:
                for suffix in SUFFIX_FILTERS:
                    if original.endswith(suffix):
                        failed.append(f"{original} (still has '{suffix}')")
                        break
    
    if renamed:
        await notify_user_from_message(message, f"Renamed folders:\n" + "\n".join(renamed))
    if failed:
        await notify_user_from_message(message, f"Failed to rename:\n" + "\n".join(failed))
    if not renamed and not failed:
        await notify_user_from_message(message, "No folders found with configured suffixes in current directory.")

async def cmd_enable_file_signing(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    global FILE_SIGNING_ENABLED
    if not FILE_SIGN:
        await notify_user_from_message(message, "No sign string is set. Use /set_sign <sign> first.")
        return
    FILE_SIGNING_ENABLED = True
    save_persistent_state()
    await notify_user_from_message(message, f"File signing enabled. Sign: '{FILE_SIGN}'")

async def cmd_disable_file_signing(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    global FILE_SIGNING_ENABLED
    FILE_SIGNING_ENABLED = False
    save_persistent_state()
    await notify_user_from_message(message, "File signing disabled.")

async def cmd_set_sign(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /set_sign <sign>")
        return
    sign = " ".join(args).strip()
    if not sign:
        await notify_user_from_message(message, "Sign cannot be empty.")
        return
    global FILE_SIGN
    FILE_SIGN = sign
    save_persistent_state()
    await notify_user_from_message(message, f"Sign set to: '{sign}'")

async def cmd_list_sign(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    status = "enabled" if FILE_SIGNING_ENABLED else "disabled"
    sign = FILE_SIGN if FILE_SIGN else "(not set)"
    await notify_user_from_message(message, f"File signing is {status}.\nCurrent sign: '{sign}'")

async def cmd_sign_current_dir(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    if not FILE_SIGNING_ENABLED:
        await notify_user_from_message(message, "File signing is disabled. Enable it first.")
        return
    root = get_user_root_path(user)
    rel = CURRENT_DIRS.get(user.id, Path("."))
    try:
        current = (root / rel).resolve()
    except Exception:
        current = root
    if not current.exists():
        await notify_user_from_message(message, "Directory does not exist.")
        return
    renamed = 0
    for item in current.iterdir():
        signed_path = await apply_file_signing_async(item, FILE_SIGN, True)
        if signed_path and signed_path.name != item.name:
            renamed += 1
    await notify_user_from_message(message, f"Signed {renamed} item(s) in current directory.")

async def cmd_automator(client: Client, message: Message):
    user = message.from_user
    if not (is_owner(user) or is_allowed_user(user)):
        await notify_user_from_message(message, "Access denied.")
        return
    global AUTOMATOR_ENABLED
    AUTOMATOR_ENABLED = not AUTOMATOR_ENABLED
    save_persistent_state()
    status = "enabled" if AUTOMATOR_ENABLED else "disabled"
    await notify_user_from_message(
        message,
        f"⚙️ Automator mode {status}.\n"
        "When enabled: any link you send will be downloaded, suffix-filtered, signed, "
        "compressed into 2GB parts, and each part uploaded automatically."
    )

async def cmd_set_automator_concurrency(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    args = message.text.split(None)[1:] if message.text else []
    if not args:
        await notify_user_from_message(message, "Usage: /set_automator_concurrency <number> (>=1)")
        return
    try:
        new_limit = int(args[0])
        if new_limit < 1:
            raise ValueError
    except ValueError:
        await notify_user_from_message(message, "Invalid number. Must be an integer >= 1.")
        return

    global AUTOMATOR_CONCURRENCY, AUTOMATOR_SEMAPHORE, PROCESSING_SEMAPHORE, PROCESSING_WORKERS
    AUTOMATOR_CONCURRENCY = new_limit
    # Recreate semaphore with new limit
    AUTOMATOR_SEMAPHORE = asyncio.Semaphore(AUTOMATOR_CONCURRENCY)
    # Stop existing workers
    for w in PROCESSING_WORKERS:
        w.cancel()
    await asyncio.gather(*PROCESSING_WORKERS, return_exceptions=True)
    # Create new semaphore and workers
    PROCESSING_SEMAPHORE = asyncio.Semaphore(AUTOMATOR_CONCURRENCY)
    PROCESSING_WORKERS.clear()
    for _ in range(AUTOMATOR_CONCURRENCY):
        worker = asyncio.create_task(processing_worker())
        PROCESSING_WORKERS.append(worker)
    save_persistent_state()
    await notify_user_from_message(message, f"Automator concurrency set to {AUTOMATOR_CONCURRENCY}.\nActive tasks: {AUTOMATOR_ACTIVE_COUNT}")

async def cmd_automator_concurrency(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied.")
        return
    await notify_user_from_message(
        message,
        f"⚙️ Automator concurrency limit: {AUTOMATOR_CONCURRENCY}\n"
        f"Active compression/upload tasks: {AUTOMATOR_ACTIVE_COUNT}"
    )

async def cmd_public_help(client: Client, message: Message):
    user = message.from_user
    if not is_allowed_user(user):
        await notify_user_from_message(message, "Access denied. You are not authorized to use this bot.")
        return
    lines = [
        "Available commands for users:",
        "",
        "/ls       — List files and folders in your current working directory",
        "/pwd      — Show your current working directory (relative to your user root)",
        "/zip      — Create a zip archive of a file/folder and optionally split into parts (usage: /zip <num> [max_mb])",
        "/mv       — Move or rename items (usage in-bot; supports ranges and moving into folder indexes) ex: /mv * /1 or /mv 4-9 /",
        "/cp       — Copy items into a folder (usage: /cp <spec> /<folder_index>) ex: /cp * /1 or /cp 4-9 /1",
        "/rm       — Remove files/folders (supports ranges, lists and '*')",
        "/upload   — Upload files from your folder to the chat (usage: /upload * or /upload 2,4 or /upload 1-9)",
        "/cd       — Change directory to a folder index shown by /ls",
        "/back     — Go up one directory level",
        "/mkdir    — Create a new folder in the current working directory",
        "/setpass  — Set a per-user password for /zip encrypted archives",
        "/nopass   — Remove the per-user password used for /zip",
        "/pass_status — Show whether you have a password set for /zip",
        "/unzip    — Extract archives stored in your folder (usage: /unzip <indexes> [password])",
        "/automator — Toggle automatic compression+upload of downloaded content into 2GB 7z parts",
        "",
        "Notes:",
        "- Many operations are restricted to your own user folder for safety.",
    ]
    await notify_user_from_message(message, "\n".join(lines))

async def cmd_admincmd(client: Client, message: Message):
    user = message.from_user
    if not is_owner(user):
        await notify_user_from_message(message, "Access denied. Owners only.")
        return
    lines = [
        "All bot commands (owners and added users):",
        "",
        "# Commands available to added users (also shown in /help):",
        "/ls, /pwd, /zip, /mv, /cp, /rm, /upload, /cd, /back, /mkdir,",
        "/setpass, /nopass, /pass_status, /unzip, /automator",
        "",
        "# Owner / admin commands:",
        "/start       — (owner) Initialize/start instructions for owners",
        "/help        — (owner) Legacy owner-only help (kept for backward compatibility)",
        "/status      — Check connectivity/status with the download service",
        "/set_thumb   — Set bot-wide thumbnail by replying to a photo",
        "/thumb       — Show configured thumbnail",
        "/del_thumb   — Delete configured thumbnail",
        "/set_description  — Set a global upload description applied to /upload",
        "/description       — Show current upload description",
        "/no_description    — Clear the upload description",
        "/adduser     — Add a temporary user: /adduser -d <days> <@username|id> or -m <minutes> <@username|id>",
        "/lsusers     — List temporary users and remaining time",
        "/deluser     — Remove a temporary user",
        "/list_suffix_filter — List configured suffix filters",
        "/add_suffix_filter <suffix> — Add a suffix to be stripped from downloaded files and folders",
        "/delete_suffix_filter <suffix> — Remove a suffix from the filter list",
        "/enable_suffix_filter — Enable automatic suffix stripping",
        "/disable_suffix_filter — Disable automatic suffix stripping",
        "/suffix_filter_status — Show filter status and configured suffixes",
        "/rename_suffix_folders — Manually rename any folder in current directory that ends with a configured suffix",
        "/enable_file_signing — Enable automatic file/folder signing after download (adds configured sign to name)",
        "/disable_file_signing — Disable automatic signing",
        "/set_sign <sign> — Set the sign string (e.g. '[Team]')",
        "/list_sign — Show current sign and status",
        "/sign_current_dir — Manually apply signing to all items in the current working directory",
        "/set_automator_concurrency <num> — Set maximum parallel automator compression+upload tasks",
        "/automator_concurrency — Show current automator concurrency limit and active tasks",
        "",
        "Other details:",
        "- /upload supports using a configured thumbnail and will apply the upload description if set.",
        "- /zip can produce encrypted archives if a password is set with /setpass and 7z is available.",
        "- Temporary users are managed in-memory and persisted to disk for expiry; owners control them.",
        "- Suffix filter automatically renames downloaded files AND folders by removing configured suffixes (e.g. ' [FitGirl Repack]') and trims extra spaces.",
        "- File signing adds a custom sign (with space) to the end of top-level downloaded files/folders after suffix filter.",
        "- Automator: when enabled, every successfully downloaded item is automatically compressed into 2GB 7z parts and uploaded, then deleted.",
        "- Automator concurrency controls how many compression+upload tasks run in parallel. Default=1.",
    ]
    full = "\n".join(lines)
    MAX = 3500
    if len(full) <= MAX:
        await notify_user_from_message(message, full)
    else:
        parts = []
        cur = []
        cur_len = 0
        for ln in lines:
            ln_len = len(ln) + 1
            if cur_len + ln_len > MAX:
                parts.append("\n".join(cur))
                cur = [ln]
                cur_len = ln_len
            else:
                cur.append(ln)
                cur_len += ln_len
        if cur:
            parts.append("\n".join(cur))
        for p in parts:
            await notify_user_from_message(message, p)

def register_handlers(app_bot: Client):
    app_bot.add_handler(MessageHandler(cmd_start, filters.command("start")))
    app_bot.add_handler(MessageHandler(cmd_whoami, filters.command("whoami")))
    app_bot.add_handler(MessageHandler(cmd_public_help, filters.command("help")))
    app_bot.add_handler(MessageHandler(cmd_status, filters.command("status")))
    app_bot.add_handler(MessageHandler(cmd_ls, filters.command("ls")))
    app_bot.add_handler(MessageHandler(cmd_pwd, filters.command("pwd")))
    app_bot.add_handler(MessageHandler(cmd_zip, filters.command("zip")))
    app_bot.add_handler(MessageHandler(cmd_mv, filters.command("mv")))
    app_bot.add_handler(MessageHandler(cmd_cp, filters.command("cp")))
    app_bot.add_handler(MessageHandler(cmd_rm, filters.command("rm")))
    app_bot.add_handler(MessageHandler(cmd_upload, filters.command("upload")))
    app_bot.add_handler(MessageHandler(cmd_cd, filters.command("cd")))
    app_bot.add_handler(MessageHandler(cmd_back, filters.command("back")))
    app_bot.add_handler(MessageHandler(cmd_mkdir, filters.command("mkdir")))
    app_bot.add_handler(MessageHandler(cmd_setpass, filters.command("setpass")))
    app_bot.add_handler(MessageHandler(cmd_nopass, filters.command("nopass")))
    app_bot.add_handler(MessageHandler(cmd_pass_status, filters.command("pass_status")))
    app_bot.add_handler(MessageHandler(cmd_unzip, filters.command("unzip")))
    app_bot.add_handler(MessageHandler(cmd_set_thumb, filters.command("set_thumb")))
    app_bot.add_handler(MessageHandler(cmd_thumb, filters.command("thumb")))
    app_bot.add_handler(MessageHandler(cmd_del_thumb, filters.command("del_thumb")))
    app_bot.add_handler(MessageHandler(cmd_set_description, filters.command("set_description")))
    app_bot.add_handler(MessageHandler(cmd_description, filters.command("description")))
    app_bot.add_handler(MessageHandler(cmd_no_description, filters.command("no_description")))
    app_bot.add_handler(MessageHandler(cmd_adduser, filters.command("adduser")))
    app_bot.add_handler(MessageHandler(cmd_lsusers, filters.command("lsusers")))
    app_bot.add_handler(MessageHandler(cmd_deluser, filters.command("deluser")))
    app_bot.add_handler(MessageHandler(cmd_admincmd, filters.command("admincmd")))
    app_bot.add_handler(MessageHandler(cmd_list_suffix_filter, filters.command("list_suffix_filter")))
    app_bot.add_handler(MessageHandler(cmd_add_suffix_filter, filters.command("add_suffix_filter")))
    app_bot.add_handler(MessageHandler(cmd_delete_suffix_filter, filters.command("delete_suffix_filter")))
    app_bot.add_handler(MessageHandler(cmd_enable_suffix_filter, filters.command("enable_suffix_filter")))
    app_bot.add_handler(MessageHandler(cmd_disable_suffix_filter, filters.command("disable_suffix_filter")))
    app_bot.add_handler(MessageHandler(cmd_suffix_filter_status, filters.command("suffix_filter_status")))
    app_bot.add_handler(MessageHandler(cmd_rename_suffix_folders, filters.command("rename_suffix_folders")))
    app_bot.add_handler(MessageHandler(cmd_enable_file_signing, filters.command("enable_file_signing")))
    app_bot.add_handler(MessageHandler(cmd_disable_file_signing, filters.command("disable_file_signing")))
    app_bot.add_handler(MessageHandler(cmd_set_sign, filters.command("set_sign")))
    app_bot.add_handler(MessageHandler(cmd_list_sign, filters.command("list_sign")))
    app_bot.add_handler(MessageHandler(cmd_sign_current_dir, filters.command("sign_current_dir")))
    app_bot.add_handler(MessageHandler(cmd_automator, filters.command("automator")))
    app_bot.add_handler(MessageHandler(cmd_set_automator_concurrency, filters.command("set_automator_concurrency")))
    app_bot.add_handler(MessageHandler(cmd_automator_concurrency, filters.command("automator_concurrency")))

    app_bot.add_handler(CallbackQueryHandler(handle_zip_cancel, filters.regex(r"^zip_cancel$")))
    app_bot.add_handler(CallbackQueryHandler(handle_unzip_cancel, filters.regex(r"^unzip_cancel$")))
    app_bot.add_handler(CallbackQueryHandler(handle_upload_cancel, filters.regex(r"^(upload_cancel:|auto_cancel:|auto_cancel_job:)")))
    app_bot.add_handler(CallbackQueryHandler(handle_download_cancel, filters.regex(r"^download_cancel:")))

    app_bot.add_handler(MessageHandler(handle_incoming_message, filters.private & ~filters.regex(r"^/")))

# ----- Automator core functions -----
async def auto_compress_and_upload(
    user,
    original_path: Path,
    chat_id: int,
    initiator_message: Optional[Message] = None,
    cancel_key: Optional[str] = None,
    stop_event: Optional[asyncio.Event] = None
) -> bool:
    if not AUTOMATOR_ENABLED:
        logger.debug("Automator disabled, skipping compression/upload")
        return False

    global AUTOMATOR_ACTIVE_COUNT, AUTOMATOR_JOBS
    async with AUTOMATOR_SEMAPHORE:
        async with _AUTOMATOR_COUNT_LOCK:
            AUTOMATOR_ACTIVE_COUNT += 1

        job_id = uuid.uuid4().hex
        job_cancel_event = asyncio.Event()
        pending_upload_tasks = []
        proc = None
        progress_msg = None

        AUTOMATOR_JOBS[job_id] = {
            "cancel_event": job_cancel_event,
            "proc": None,
            "pending_tasks": pending_upload_tasks,
            "progress_msg": None,
            "original_path": original_path,
            "chat_id": chat_id,
        }

        try:
            if not original_path.exists():
                await safe_send(chat_id, f"❌ Automator: path {original_path.name} does not exist.")
                return False

            seven_cmd = None
            try:
                if SEVENZ_PATH:
                    sp = Path(SEVENZ_PATH)
                    if sp.exists() and sp.is_file():
                        seven_cmd = str(sp)
                    else:
                        seven_cmd = shutil.which(SEVENZ_PATH) or shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
                else:
                    seven_cmd = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")
            except Exception:
                seven_cmd = shutil.which("7z") or shutil.which("7za") or shutil.which("7zr")

            if not seven_cmd:
                await safe_send(chat_id, "❌ Automator: 7z not found. Install 7z or set SEVENZ_PATH.")
                return False

            out_dir = original_path.parent
            base_name = sanitize_filename(original_path.stem if original_path.is_file() else original_path.name)
            archive_base = out_dir / f"{base_name}.7z"

            # Remove any existing old parts
            for old in out_dir.glob(f"{archive_base.name}.*"):
                try:
                    old.unlink()
                except Exception:
                    pass

            cmd = [
                seven_cmd, "a", "-t7z", "-bsp1",
                "-mx=0",
                f"-v{2000}m",
                "-y",
                str(archive_base),
                str(original_path)
            ]

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=str(out_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT
            )
            AUTOMATOR_JOBS[job_id]["proc"] = proc

            # Regex to match part files like "name.7z.001", "name.7z.002", etc.
            part_pattern = re.compile(rf"{re.escape(archive_base.name)}\.([0-9]+)$")

            # Progress message
            async def update_status(text: str):
                nonlocal progress_msg
                if progress_msg is None:
                    progress_msg = await safe_send(chat_id, text, parse_mode=ParseMode.HTML)
                    AUTOMATOR_JOBS[job_id]["progress_msg"] = progress_msg
                else:
                    try:
                        await edit_with_retry(progress_msg.edit_text(_scrub_text_for_user(text), parse_mode=ParseMode.HTML))
                    except Exception:
                        pass

            await update_status(f"🔄 Automator: compressing {original_path.name} into 2GB parts...")

            # Read 7z output in background (just to keep pipe from filling)
            read_task = asyncio.create_task(_read_7z_output(proc, update_status))

            uploaded_parts = set()
            expected_part = 1
            pending_parts = {}  # part_num -> Path for out-of-order parts (should not happen with 7z but safe)

            try:
                start_time_total = time.time()
                max_duration = 3600 * 6  # 6 hours max

                while True:
                    # Check overall timeout
                    if time.time() - start_time_total > max_duration:
                        await update_status("❌ Automator: job exceeded maximum duration, cancelling.")
                        if proc and proc.returncode is None:
                            proc.terminate()
                        break

                    # Check for cancellation
                    if job_cancel_event.is_set():
                        logger.info(f"Automator job {job_id} cancelled by user")
                        await update_status("❌ Automator job cancelled by user.")
                        # Cancel the 7z process
                        if proc.returncode is None:
                            try:
                                proc.terminate()
                            except Exception:
                                pass
                        break

                    # Always yield control
                    await asyncio.sleep(0.1)

                    # Look for newly created part files
                    for candidate in out_dir.iterdir():
                        if not candidate.is_file():
                            continue
                        if candidate.name in uploaded_parts:
                            continue
                        m = part_pattern.search(candidate.name)
                        if not m:
                            continue
                        part_num = int(m.group(1))

                        # Ensure file is stable (no longer being written)
                        stable = False
                        try:
                            size1 = candidate.stat().st_size
                            await asyncio.sleep(0.5)
                            size2 = candidate.stat().st_size
                            if size1 == size2 and size1 > 0:
                                stable = True
                        except Exception:
                            pass
                        if not stable:
                            continue

                        uploaded_parts.add(candidate.name)

                        # Store part for later use (handles out-of-order)
                        if part_num not in pending_parts:
                            pending_parts[part_num] = candidate

                        # Upload parts in order, starting from expected_part
                        while expected_part in pending_parts:
                            part_path = pending_parts.pop(expected_part)
                            await update_status(f"📤 Uploading part {expected_part}: {part_path.name}")

                            # Upload this part (sequential)
                            cancel_data = f"auto_cancel_job:{job_id}"
                            progress_markup = InlineKeyboardMarkup(
                                [[InlineKeyboardButton("Cancel job", callback_data=cancel_data)]]
                            )

                            # Determine total size for progress
                            total_size = part_path.stat().st_size

                            # ---------- UPLOAD CLIENT SELECTION (same as cmd_upload) ----------
                            if FORCE_USER_UPLOADS:
                                use_bot = False
                            elif FORCE_BOT_UPLOADS:
                                use_bot = True
                            else:
                                use_bot = (total_size > LARGE_FILE_THRESHOLD)
                            
                            # Fallback to bot client if user client is not available and use_bot is False
                            if not use_bot and user_client is None:
                                logger.warning("Automator: user client not available, falling back to bot client")
                                use_bot = True

                            upload_client = bot_client if use_bot else user_client
                            # ------------------------------------------------------------

                            try:
                                start_time = time.time()
                                upload_msg = await safe_send(
                                    chat_id,
                                    "<i>Preparing upload...</i>",
                                    reply_markup=progress_markup
                                )

                                # Increased update interval for automator to 10 seconds
                                progress_handler = OptimizedProgress(
                                    part_path.name, total_size, upload_msg, start_time,
                                    update_interval=10.0, reply_markup=progress_markup
                                )

                                caption = f"<i>{part_path.name}</i>\n<i>@GamesDarkCloud</i>"
                                thumb_path = THUMBNAIL_PATH if THUMBNAIL_PATH and THUMBNAIL_PATH.exists() else None
                                send_kwargs = {
                                    "chat_id": chat_id,
                                    "document": str(part_path),
                                    "caption": caption,
                                    "parse_mode": ParseMode.HTML,
                                    "progress": progress_handler,
                                    "reply_markup": progress_markup,
                                }
                                if thumb_path:
                                    send_kwargs["thumb"] = str(thumb_path)

                                task = asyncio.current_task()
                                pending_upload_tasks.append(task)

                                sent_doc = await upload_with_retry(upload_client, send_kwargs)

                                # Remove cancel button after successful upload
                                try:
                                    await edit_with_retry(sent_doc.edit_caption(
                                        caption=sent_doc.caption.html if sent_doc.caption else caption,
                                        reply_markup=None
                                    ))
                                except Exception:
                                    pass
                                await edit_with_retry(upload_msg.edit(f"<i>✅ Uploaded {part_path.name}</i>", reply_markup=None))
                                part_path.unlink(missing_ok=True)  # delete part after upload

                                # Extra cooldown between parts to avoid flood waits
                                await asyncio.sleep(2.0)

                            except asyncio.CancelledError:
                                await safe_send(chat_id, f"❌ Upload of {part_path.name} was cancelled.")
                                part_path.unlink(missing_ok=True)
                                raise
                            except Exception as e:
                                logger.exception(f"Failed to upload part {part_path.name}")
                                await safe_send(chat_id, f"❌ Automator: failed to upload {part_path.name}: {str(e)[:100]}")
                            finally:
                                if task in pending_upload_tasks:
                                    pending_upload_tasks.remove(task)

                            expected_part += 1
                            # After incrementing, check again if any more parts are available

                    # If 7z process has finished and no more parts are pending, break
                    if proc.returncode is not None and not pending_parts:
                        # Wait a short time for any last part to appear
                        await asyncio.sleep(1)
                        # Final check for parts
                        for candidate in out_dir.iterdir():
                            if not candidate.is_file():
                                continue
                            if candidate.name in uploaded_parts:
                                continue
                            m = part_pattern.search(candidate.name)
                            if m:
                                part_num = int(m.group(1))
                                if part_num not in pending_parts:
                                    pending_parts[part_num] = candidate
                        if not pending_parts:
                            break

                # Cleanup after loop (either finished or cancelled)
                if job_cancel_event.is_set():
                    # Delete any remaining partial part files
                    for f in out_dir.glob(f"{archive_base.name}.*"):
                        try:
                            f.unlink()
                        except Exception:
                            pass
                    return False

                # Normal completion: wait for read task to finish
                await read_task

                if proc.returncode == 0:
                    # Delete original downloaded item
                    try:
                        if original_path.is_dir():
                            shutil.rmtree(original_path)
                        else:
                            original_path.unlink()
                    except Exception as e:
                        logger.warning(f"Automator: could not delete original {original_path}: {e}")
                    await update_status("✅ Automator: compression and upload completed. Original deleted.")
                    return True
                else:
                    await update_status(f"❌ Automator: compression failed with code {proc.returncode}")
                    return False

            except asyncio.CancelledError:
                if proc and proc.returncode is None:
                    proc.terminate()
                raise
            finally:
                if read_task and not read_task.done():
                    read_task.cancel()
                AUTOMATOR_JOBS.pop(job_id, None)

        finally:
            async with _AUTOMATOR_COUNT_LOCK:
                AUTOMATOR_ACTIVE_COUNT -= 1

async def _read_7z_output(proc: asyncio.subprocess.Process, status_callback):
    try:
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            decoded = line.decode(errors="ignore").strip()
            # Optionally parse percent from 7z output (not needed for core functionality)
    except Exception:
        pass

async def _qb_login(session: aiohttp.ClientSession, base_url: str) -> bool:
    if not QBT_USER and not QBT_PASS:
        return True
    login_url = f"{base_url}/api/v2/auth/login"
    data = {"username": QBT_USER or "", "password": QBT_PASS or ""}
    try:
        async with session.post(login_url, data=data, timeout=10) as resp:
            return resp.status == 200
    except Exception:
        return False

async def _qb_add_torrent_file(session: aiohttp.ClientSession, base_url: str, file_path: str, savepath: str) -> bool:
    add_url = f"{base_url}/api/v2/torrents/add"
    try:
        with open(file_path, "rb") as fp:
            form = aiohttp.FormData()
            form.add_field("torrents", fp, filename=Path(file_path).name, content_type="application/x-bittorrent")
            form.add_field("savepath", str(savepath))
            async with session.post(add_url, data=form, timeout=30) as resp:
                return resp.status in (200, 201, 202)
    except Exception:
        return False

async def _qb_add_magnet(session: aiohttp.ClientSession, base_url: str, magnet: str, savepath: str) -> bool:
    add_url = f"{base_url}/api/v2/torrents/add"
    data = {"urls": magnet, "savepath": str(savepath)}
    try:
        async with session.post(add_url, data=data, timeout=10) as resp:
            return resp.status in (200, 201, 202)
    except Exception:
        return False

async def _qb_find_torrent_by_name_and_path(session: aiohttp.ClientSession, base_url: str, name: str, savepath: str, timeout_seconds: float = 30.0):
    info_url = f"{base_url}/api/v2/torrents/info"
    end = time.time() + timeout_seconds
    while time.time() < end:
        try:
            async with session.get(info_url, timeout=10) as resp:
                if resp.status != 200:
                    await asyncio.sleep(0.5)
                    continue
                data = await resp.json()
                for t in data:
                    try:
                        tname = t.get("name") or ""
                        tpath = t.get("save_path") or ""
                        if tname == name and os.path.normpath(tpath) == os.path.normpath(str(savepath)):
                            return t.get("hash")
                    except Exception:
                        continue
        except Exception:
            pass
        await asyncio.sleep(0.7)
    return None

async def _qb_get_torrent_info(session: aiohttp.ClientSession, base_url: str, torrent_hash: str):
    info_url = f"{base_url}/api/v2/torrents/info"
    params = {"hashes": torrent_hash}
    try:
        async with session.get(info_url, params=params, timeout=10) as resp:
            if resp.status != 200:
                return None
            data = await resp.json()
            if isinstance(data, list) and data:
                return data[0]
            return None
    except Exception:
        return None

async def _qb_remove_torrent(session: aiohttp.ClientSession, base_url: str, torrent_hash: str, delete_files: bool = False) -> bool:
    delete_url = f"{base_url}/api/v2/torrents/delete"
    data = {"hashes": torrent_hash, "deleteFiles": "true" if delete_files else "false"}
    try:
        async with session.post(delete_url, data=data, timeout=10) as resp:
            return resp.status in (200, 202)
    except Exception as e:
        logger.warning(f"Failed to remove torrent {torrent_hash} (keep files: {not delete_files}): {e}")
        return False

async def aria2_download_items(links: List[str], tg_user, telegram_message, wait_for_automator: bool = False, cancel_key_override: Optional[str] = None) -> Tuple[int, List[Tuple[str, bool, str]]]:
    user_folder = get_user_folder_name(tg_user)
    base = TELELOAD_BASE_DIR.rstrip("/")
    if not base:
        base = "/"
    if base == "/":
        dest_base = Path.cwd().anchor
        dest_dir = Path(dest_base) / user_folder
    else:
        dest_dir = Path(base) / user_folder
    try:
        dest_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        try:
            await edit_with_retry(telegram_message.edit(_scrub_text_for_user("Failed to create destination folder for downloads.")))
        except Exception:
            pass
        return 0, [(l, False, "mkdir failed") for l in links]

    base_url = f"http://{QBT_HOST}:{QBT_PORT}"
    results = []

    if cancel_key_override:
        cancel_key = cancel_key_override
    else:
        cancel_key = uuid.uuid4().hex
    stop_evt = asyncio.Event()
    try:
        DOWNLOAD_TASKS[cancel_key] = {"stop_event": stop_evt, "user_id": getattr(tg_user, "id", None), "cancelled": False, "type": "qb"}
        try:
            await edit_with_retry(telegram_message.edit(_scrub_text_for_user(await telegram_message.text if getattr(telegram_message, "text", None) else ""), reply_markup=_download_cancel_keyboard(cancel_key), parse_mode=ParseMode.HTML))
        except Exception:
            pass

        async with aiohttp.ClientSession() as session:
            logged = await _qb_login(session, base_url)
            if not logged:
                return 0, [(l, False, "qBittorrent login failed") for l in links]
            automator_tasks_local = []
            for idx, link in enumerate(links, start=1):
                if stop_evt.is_set() or DOWNLOAD_TASKS.get(cancel_key, {}).get("cancelled"):
                    results.append((link, False, "cancelled_by_user"))
                    break

                link = link.strip()
                item_for_qb = link
                temp_torrent_path = None
                downloaded_temp = False
                candidate_name_for_conflict = None

                # --- FIX: use os.path.isfile to avoid Path() on magnet links ---
                if path.isfile(link) and link.lower().endswith(".torrent"):
                    p = Path(link)
                    temp_torrent_path = str(p)
                    item_for_qb = temp_torrent_path
                    try:
                        tname = bdecode_get_name_of_torrent(p)
                        if tname:
                            candidate_name_for_conflict = sanitize_filename(tname)
                    except Exception:
                        candidate_name_for_conflict = None
                elif is_torrent_url(link) and link.lower().startswith("http"):
                    try:
                        try:
                            await edit_with_retry(telegram_message.edit(_scrub_text_for_user(f"<i>[{idx}/{len(links)}] Downloading torrent file from URL...</i>")))
                        except Exception:
                            pass
                        tmp = await download_torrent_file(session, link, dest_dir)
                        temp_torrent_path = str(tmp)
                        downloaded_temp = True
                        item_for_qb = temp_torrent_path
                        tname = bdecode_get_name_of_torrent(Path(temp_torrent_path))
                        if tname:
                            candidate_name_for_conflict = sanitize_filename(tname)
                    except Exception:
                        results.append((link, False, "Failed to download .torrent"))
                        continue
                elif is_magnet(link):
                    try:
                        parsed = urllib.parse.urlparse(link)
                        q = urllib.parse.parse_qs(parsed.query)
                        dn_vals = q.get("dn") or q.get("DN") or q.get("Name")
                        if dn_vals:
                            dn = dn_vals[0]
                            candidate_name_for_conflict = sanitize_filename(urllib.parse.unquote(dn))
                    except Exception:
                        candidate_name_for_conflict = None
                else:
                    results.append((link, False, "unsupported"))
                    continue

                if candidate_name_for_conflict:
                    try:
                        renamed = await safe_rename_existing_async(dest_dir, candidate_name_for_conflict)
                        if renamed:
                            try:
                                await edit_with_retry(telegram_message.edit(_scrub_text_for_user(f"<i>[{idx}/{len(links)}] Found existing '{candidate_name_for_conflict}'. Renamed existing to avoid overwrite.</i>")))
                            except Exception:
                                pass
                    except Exception:
                        pass

                try:
                    await edit_with_retry(telegram_message.edit(_scrub_text_for_user(f"<i>[{idx}/{len(links)}] Adding to qBittorrent...</i>"), reply_markup=_download_cancel_keyboard(cancel_key), parse_mode=ParseMode.HTML))
                except Exception:
                    pass

                added = False
                if temp_torrent_path:
                    added = await _qb_add_torrent_file(session, base_url, temp_torrent_path, dest_dir)
                else:
                    if is_magnet(link):
                        added = await _qb_add_magnet(session, base_url, link, dest_dir)

                if not added:
                    results.append((link, False, "add_failed"))
                    if temp_torrent_path and downloaded_temp:
                        try:
                            Path(temp_torrent_path).unlink(missing_ok=True)
                        except Exception:
                            pass
                    continue

                name_to_find = candidate_name_for_conflict or _derive_display_name_from_link(link, tg_user)
                torrent_hash = await _qb_find_torrent_by_name_and_path(session, base_url, name_to_find, dest_dir, timeout_seconds=25.0)
                if not torrent_hash:
                    info_url = f"{base_url}/api/v2/torrents/info"
                    try:
                        async with session.get(info_url, timeout=10) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                found = None
                                for t in data:
                                    try:
                                        if os.path.normpath(t.get("save_path", "")) == os.path.normpath(str(dest_dir)):
                                            found = t.get("hash")
                                            break
                                    except Exception:
                                        continue
                                torrent_hash = found
                    except Exception:
                        torrent_hash = None

                if not torrent_hash:
                    results.append((link, False, "could_not_identify"))
                    if temp_torrent_path and downloaded_temp:
                        try:
                            Path(temp_torrent_path).unlink(missing_ok=True)
                        except Exception:
                            pass
                    continue

                start_time = time.time()
                last_update = 0.0
                success = False
                info_text = ""
                try:
                    last_title = name_to_find
                    last_seen_time = time.time()
                    while True:
                        if stop_evt.is_set() or DOWNLOAD_TASKS.get(cancel_key, {}).get("cancelled"):
                            try:
                                await _qb_remove_torrent(session, base_url, torrent_hash, delete_files=True)
                            except Exception:
                                pass
                            success = False
                            info_text = "cancelled_by_user"
                            try:
                                await edit_with_retry(telegram_message.edit(_scrub_text_for_user(f"<i>{last_title}\n\nCancelled by user.</i>")))
                            except Exception:
                                pass
                            break

                        tinfo = await _qb_get_torrent_info(session, base_url, torrent_hash)
                        now = time.time()
                        if not tinfo:
                            if now - last_seen_time > 5:
                                success = True
                                info_text = "assumed_finished_removed"
                                try:
                                    await edit_with_retry(telegram_message.edit(_scrub_text_for_user(f"<i>{last_title}\n\nNo info in qBittorrent; assuming download finished.</i>")))
                                except Exception:
                                    pass
                                break
                            await asyncio.sleep(1.0)
                            continue
                        last_seen_time = now
                        total = int(tinfo.get("total_size") or 0)
                        prog = float(tinfo.get("progress", 0.0) or 0.0)
                        loaded = int(prog * total) if total else None
                        elapsed = time.time() - start_time
                        rate = int(tinfo.get("dlspeed", 0) or 0)
                        eta = None
                        try:
                            if total and loaded is not None and rate and rate > 0:
                                eta = (total - loaded) / rate
                        except Exception:
                            eta = None
                        title = tinfo.get("name") or last_title
                        last_title = title
                        txt = build_progress_text(title, total if total > 0 else None, loaded if loaded is not None else None, elapsed, eta, speed=rate if rate else None)
                        now2 = time.time()
                        if (now2 - last_update) >= PROGRESS_UPDATE_INTERVAL:
                            try:
                                await edit_with_retry(telegram_message.edit(_scrub_text_for_user(txt), reply_markup=_download_cancel_keyboard(cancel_key), parse_mode=ParseMode.HTML))
                            except Exception:
                                pass
                            last_update = now2
                        prog_val = tinfo.get("progress", 0.0)
                        if prog_val is not None and float(prog_val) >= 0.9999:
                            success = True
                            info_text = "Download finished"

                            # Wait for disk to settle
                            await asyncio.sleep(SUFFIX_POST_DOWNLOAD_WAIT)

                            final_processed = None
                            # Determine if this is a single-file torrent (no subfolder)
                            try:
                                items_in_dest = list(dest_dir.iterdir())
                                # If only one item and it is a file -> single file
                                if len(items_in_dest) == 1 and items_in_dest[0].is_file():
                                    final_processed = await process_path_with_suffix_and_signing_async(items_in_dest[0])
                                    logger.info(f"Single-file torrent detected: {final_processed}")
                                else:
                                    # Multi-file torrent – look for the folder named after the torrent title
                                    folder_path = dest_dir / title
                                    if folder_path.exists() and folder_path.is_dir():
                                        logger.info(f"Processing torrent folder: {folder_path}")
                                        final_processed = await process_path_with_suffix_and_signing_async(folder_path)
                                    else:
                                        # Fallback: scan for any folder
                                        logger.info(f"Torrent folder '{title}' not found directly, scanning for any folder")
                                        for item in dest_dir.iterdir():
                                            if item.is_dir():
                                                logger.info(f"Checking folder: {item.name}")
                                                final_processed = await process_path_with_suffix_and_signing_async(item)
                                                if final_processed:
                                                    break
                            except Exception as e:
                                logger.warning(f"Failed to apply suffix filter/signing to torrent item(s) in {dest_dir}: {e}")

                            # Trigger automator on the final processed item (file or folder)
                            if AUTOMATOR_ENABLED and final_processed and final_processed.exists():
                                task = asyncio.create_task(
                                    auto_compress_and_upload(
                                        user=tg_user,
                                        original_path=final_processed,
                                        chat_id=telegram_message.chat.id,
                                        initiator_message=telegram_message,
                                        cancel_key=cancel_key,
                                        stop_event=stop_evt
                                    )
                                )
                                if wait_for_automator:
                                    automator_tasks_local.append(task)

                            try:
                                removed = await _qb_remove_torrent(session, base_url, torrent_hash, delete_files=False)
                                if removed:
                                    logger.info(f"Removed completed torrent {torrent_hash} from qBittorrent (files kept)")
                                else:
                                    logger.warning(f"Failed to remove torrent {torrent_hash} after completion")
                            except Exception as e:
                                logger.exception(f"Error removing torrent {torrent_hash}: {e}")

                            try:
                                await edit_with_retry(telegram_message.edit(_scrub_text_for_user(txt + "\n\n<i>Download finished (removed from client)</i>")))
                            except Exception:
                                pass
                            break
                        state = (tinfo.get("state") or "").lower()
                        if state in ("error", "pauseddl", "missingfiles"):
                            success = False
                            info_text = f"state:{state}"
                            break
                        await asyncio.sleep(1.0)
                except Exception as e:
                    success = False
                    info_text = str(e)
                results.append((link, success, info_text))
                if temp_torrent_path and downloaded_temp:
                    try:
                        Path(temp_torrent_path).unlink(missing_ok=True)
                    except Exception:
                        pass
                await asyncio.sleep(0.3)
            if wait_for_automator and automator_tasks_local:
                await asyncio.gather(*automator_tasks_local, return_exceptions=True)
    finally:
        try:
            DOWNLOAD_TASKS.pop(cancel_key, None)
        except Exception:
            pass

    success_count = sum(1 for _, ok, _ in results if ok)
    return success_count, results

async def graceful_shutdown(signum=None, frame=None):
    logger.info("Received shutdown signal, cleaning up...")
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    for task in tasks:
        task.cancel()
    try:
        await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True), timeout=5.0)
    except asyncio.TimeoutError:
        logger.warning("Some tasks didn't cancel within timeout")
    except Exception:
        pass
    if bot_client and bot_client.is_connected:
        try:
            await asyncio.wait_for(bot_client.stop(), timeout=3.0)
        except Exception:
            pass
    if user_client and user_client.is_connected:
        try:
            await asyncio.wait_for(user_client.stop(), timeout=3.0)
        except Exception:
            pass
    logger.info("Shutdown complete")
    loop = asyncio.get_event_loop()
    loop.stop()
    await asyncio.sleep(0.5)

def enable_asyncio_debug():
    """Enable asyncio debug mode to catch blocking calls."""
    loop = asyncio.get_event_loop()
    loop.set_debug(True)
    loop.slow_callback_duration = 0.5  # Warn on callbacks > 500ms

    def blocker_handler(loop, context):
        msg = context.get('message', 'Unknown')
        if 'blocking' in msg.lower() or 'slow' in msg.lower():
            logger.error(f"ASYNC BLOCKER DETECTED: {msg}")
            import traceback
            traceback.print_stack(context.get('future', None))

    loop.set_exception_handler(blocker_handler)

async def event_loop_health_check():
    """Periodically check if event loop is responding."""
    last_heartbeat = time.time()

    async def heartbeat():
        nonlocal last_heartbeat
        while True:
            await asyncio.sleep(5)
            last_heartbeat = time.time()

    asyncio.create_task(heartbeat())

    while True:
        await asyncio.sleep(15)
        if time.time() - last_heartbeat > 30:
            logger.critical("Event loop appears frozen! No heartbeat for 30 seconds")
            # Force restart
            os._exit(1)

async def start_clients_and_run():
    global bot_client, user_client, BOT_ID, AUTOMATOR_SEMAPHORE, _AUTOMATOR_COUNT_LOCK
    global PROCESSING_QUEUE, PROCESSING_SEMAPHORE, PROCESSING_WORKERS

    # Enable asyncio debug if environment variable set
    if os.getenv("ASYNCIO_DEBUG", "false").lower() == "true":
        enable_asyncio_debug()
        logger.warning("ASYNCIO_DEBUG enabled - performance may be reduced")

    connection_retry_count = 0
    max_connection_retries = 3

    try:
        api_id_val = int(PYRO_API_ID)
    except Exception:
        api_id_val = PYRO_API_ID

    bot_client = Client(
        "pyro_bot",
        bot_token=TELEGRAM_TOKEN,
        api_id=api_id_val,
        api_hash=PYRO_API_HASH,
        workers=WORKER_COUNT,
        max_concurrent_transmissions=MAX_CONCURRENT_UPLOADS,
        sleep_threshold=60,
        parse_mode=ParseMode.HTML,
    )
    user_client = Client(
        "pyro_user",
        api_id=api_id_val,
        api_hash=PYRO_API_HASH,
        workers=WORKER_COUNT,
        max_concurrent_transmissions=MAX_CONCURRENT_UPLOADS,
        sleep_threshold=60,
        parse_mode=ParseMode.HTML,
    )

    for attempt in range(max_connection_retries):
        try:
            await bot_client.start()
            me = await bot_client.get_me()
            BOT_ID = getattr(me, "id", None)
            await user_client.start()
            connection_retry_count = 0
            logger.info(f"Bot client and user client started. Bot ID: {BOT_ID}")
            logger.info(f"Optimized settings: workers={WORKER_COUNT}, max_concurrent={MAX_CONCURRENT_UPLOADS}")

            _AUTOMATOR_COUNT_LOCK = asyncio.Lock()
            AUTOMATOR_SEMAPHORE = asyncio.Semaphore(AUTOMATOR_CONCURRENCY)

            # Initialise automator processing queue
            PROCESSING_QUEUE = asyncio.Queue()
            PROCESSING_SEMAPHORE = asyncio.Semaphore(AUTOMATOR_CONCURRENCY)
            PROCESSING_WORKERS.clear()
            for _ in range(AUTOMATOR_CONCURRENCY):
                worker = asyncio.create_task(processing_worker())
                PROCESSING_WORKERS.append(worker)

            break
        except Exception as e:
            connection_retry_count += 1
            logger.error(f"Failed to start clients (attempt {attempt+1}/{max_connection_retries}): {e}")
            if attempt < max_connection_retries - 1:
                await asyncio.sleep(CONNECTION_RETRY_DELAY)
            else:
                raise

    asyncio.create_task(keep_alive_loop())
    asyncio.create_task(task_health_check())
    asyncio.create_task(event_loop_health_check())

    async def connection_health_check():
        while True:
            await asyncio.sleep(60)
            try:
                if user_client and user_client.is_connected:
                    await asyncio.wait_for(user_client.get_me(), timeout=10)
                else:
                    logger.warning("User client disconnected, attempting to reconnect...")
                    try:
                        await user_client.reconnect()
                        logger.info("User client reconnected successfully")
                    except Exception as e:
                        logger.error(f"Failed to reconnect user client: {e}")
            except asyncio.TimeoutError:
                logger.warning("Connection health check timed out, client may be frozen")
                try:
                    if user_client:
                        await user_client.stop()
                        await user_client.start()
                        logger.info("User client restarted")
                except Exception as e:
                    logger.error(f"Failed to restart user client: {e}")
            except Exception as e:
                logger.warning(f"Connection health check failed: {e}")

    asyncio.create_task(connection_health_check())

    register_handlers(bot_client)
    try:
        logger.info("Bot is running. Press Ctrl+C to stop.")
        await idle()
    finally:
        await graceful_shutdown()

def main():
    def handle_shutdown(signum, frame):
        logger.info(f"Received signal {signum}, shutting down...")
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(graceful_shutdown(signum, frame))
            else:
                os._exit(0)
        except Exception:
            os._exit(0)

    signal_module.signal(signal_module.SIGINT, handle_shutdown)
    signal_module.signal(signal_module.SIGTERM, handle_shutdown)

    try:
        signal_module.signal(signal_module.SIGPIPE, signal_module.SIG_IGN)
    except AttributeError:
        pass

    try:
        asyncio.run(start_clients_and_run())
    except KeyboardInterrupt:
        logger.info("KeyboardInterrupt received")
    except asyncio.CancelledError:
        logger.info("Cancelled")
    except Exception as e:
        logger.exception(f"Unhandled exception: {e}")
    finally:
        logger.info("Exiting...")
        os._exit(0)

if __name__ == "__main__":
    main()